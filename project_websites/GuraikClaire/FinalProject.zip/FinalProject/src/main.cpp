/*
CPE/CSC 471 Lab base code Wood/Dunn/Eckhardt
*/

#include <iostream>
#include <glad/glad.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "GLSL.h"
#include "Program.h"
#include "MatrixStack.h"

#include "WindowManager.h"
#include "Shape.h"
// value_ptr for glm
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>
using namespace std;
using namespace glm;
shared_ptr<Shape> cylinder, cube, sphere, cone;


double get_last_elapsed_time()
{
	static double lasttime = glfwGetTime();
	double actualtime =glfwGetTime();
	double difference = actualtime- lasttime;
	lasttime = actualtime;
	return difference;
}
class camera
{
public:
	glm::vec3 pos, rot;
	int w, a, s, d;
	camera()
	{
		w = a = s = d = 0;
		rot = glm::vec3(0, 0.7, 0);
		pos = glm::vec3(-1, -1, -22);
	}
	glm::mat4 process(double ftime)
	{
		float speed = 0;
		if (w == 1)
		{
			speed = 1*ftime*15;
		}
		else if (s == 1)
		{
			speed = -1*ftime*15;
		}
		float yangle=0;
		if (a == 1)
			yangle = -1*ftime*5;
		else if(d==1)
			yangle = 1*ftime*5;
		rot.y += yangle;
		glm::mat4 R = glm::rotate(glm::mat4(1), rot.y, glm::vec3(0, 1, 0));
		glm::vec4 dir = glm::vec4(0, 0, speed,1);
		dir = dir*R;
		pos += glm::vec3(dir.x, dir.y, dir.z);
		glm::mat4 T = glm::translate(glm::mat4(1), pos);
		return R*T;
	}
};

camera mycam;

class Application : public EventCallbacks
{

public:

	WindowManager * windowManager = nullptr;

	// Our shader program
	std::shared_ptr<Program> prog, progFramebuffer, progSand, progRoad, progPebbles, progSkybox,
	progPRock, progPRockA, 
	progSHouse, progSHouseN, progSHouseD, progSHouseW,
	progPine, progPineD, progLeaf, progPineW, progPineDP, 
	progWGlass,
	progSquid, progSquidS, progSquidE, progSquidM,
	progPat, progPatE, progPatF, progPatS, progPatL,
	progJellyFields, progJelly, progStick, progLoop, progNet,
	progBob, progUA, progL, progNA, progNT, progNAsphere, progE, progP, progS, progScube, progC,
	progKK, progKKC, progKKB, progKKDB, progKKGlass;

	// Contains vertex information for OpenGL
	GLuint VertexArrayID, VertexArrayIDSquare;

	// Data necessary to give our box to OpenGL
	GLuint VertexBufferID, VertexColorIDBox,
	MeshPosID, MeshTexID, IndexBufferIDBox, 
	VertexBufferIDSquare, VertexNormalIDSquare, VertexTextureIDSquare, IndexBufferIDSquare, InstanceBufferSand;

	//texture data
	GLuint Texture;
	GLuint Texture2;
	GLuint Texture3;
	GLuint Texture4;
	GLuint HeightTexture;
	GLuint Texture6;
	GLuint Texture7;
	GLuint Texture8;
	GLuint Texture9;
	//Frame Buffer
	GLuint FBOtex, FrameBufferObj, depth_rb;
	GLuint VertexArrayIDRect, VertexBufferIDRect, VertexBufferTexRect;

	float w = 0.0f, ww = 0.0f;
	int moveRockUp = 0, moveRockDown = 0, movePatrickDown = 0, movePatrickUp = 0;
	glm::vec3 movePatrick = glm::vec3(0.0f, 0.0f, 0.0f);
	int setUnderwater = 0;

	void keyCallback(GLFWwindow *window, int key, int scancode, int action, int mods)
	{
		if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		{
			glfwSetWindowShouldClose(window, GL_TRUE);
		}
		
		if (key == GLFW_KEY_W && action == GLFW_PRESS)
		{
			mycam.w = 1;
		}
		if (key == GLFW_KEY_W && action == GLFW_RELEASE)
		{
			mycam.w = 0;
		}
		if (key == GLFW_KEY_S && action == GLFW_PRESS)
		{
			mycam.s = 1;
		}
		if (key == GLFW_KEY_S && action == GLFW_RELEASE)
		{
			mycam.s = 0;
		}
		if (key == GLFW_KEY_A && action == GLFW_PRESS)
		{
			mycam.a = 1;
		}
		if (key == GLFW_KEY_A && action == GLFW_RELEASE)
		{
			mycam.a = 0;
		}
		if (key == GLFW_KEY_D && action == GLFW_PRESS)
		{
			mycam.d = 1;
		}
		if (key == GLFW_KEY_D && action == GLFW_RELEASE)
		{
			mycam.d = 0;
		}
		if (key == GLFW_KEY_P && action == GLFW_PRESS)
		{
			if (w == 0.0f) {
				moveRockDown = 0;
				moveRockUp = 1;
			}
			else {
				if (moveRockUp == 0) {
					if (movePatrickDown == 0) {
						moveRockUp = 0;
						movePatrickUp = 1;
					}
				}
			}
		}
		if (key == GLFW_KEY_O && action == GLFW_PRESS)
		{
			if (setUnderwater == 0) {
				setUnderwater = 1;
			}
			else {
				setUnderwater = 0;
			}
		}
	}

	// callback for the mouse when clicked move the triangle when helper functions
	// written
	void mouseCallback(GLFWwindow *window, int button, int action, int mods)
	{
		double posX, posY;
		float newPt[2];
		if (action == GLFW_PRESS)
		{
			glfwGetCursorPos(window, &posX, &posY);
			std::cout << "Pos X " << posX <<  " Pos Y " << posY << std::endl;

			//change this to be the points converted to WORLD
			//THIS IS BROKEN< YOU GET TO FIX IT - yay!
			newPt[0] = 0;
			newPt[1] = 0;

			std::cout << "converted:" << newPt[0] << " " << newPt[1] << std::endl;
			glBindBuffer(GL_ARRAY_BUFFER, VertexBufferID);
			//update the vertex array with the updated points
			glBufferSubData(GL_ARRAY_BUFFER, sizeof(float)*6, sizeof(float)*2, newPt);
			glBindBuffer(GL_ARRAY_BUFFER, 0);
		}
	}

	//if the window is resized, capture the new size and reset the viewport
	void resizeCallback(GLFWwindow *window, int in_width, int in_height)
	{
		//get the window size - may be different then pixels for retina
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);
	}

	#define MESHSIZE 60
	void init_mesh()
	{
		//generate the VAO
		glGenVertexArrays(1, &VertexArrayID);
		glBindVertexArray(VertexArrayID);

		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &MeshPosID);
		glBindBuffer(GL_ARRAY_BUFFER, MeshPosID);
		vec3 vertices[MESHSIZE * MESHSIZE * 4];
		for (int x = 0; x < MESHSIZE; x++)
			for (int z = 0; z < MESHSIZE; z++)
			{
				vertices[x * 4 + z * MESHSIZE * 4 + 0] = vec3(0.0, 0.0, 0.0) + vec3(x, 0, z);
				vertices[x * 4 + z * MESHSIZE * 4 + 1] = vec3(1.0, 0.0, 0.0) + vec3(x, 0, z);
				vertices[x * 4 + z * MESHSIZE * 4 + 2] = vec3(1.0, 0.0, 1.0) + vec3(x, 0, z);
				vertices[x * 4 + z * MESHSIZE * 4 + 3] = vec3(0.0, 0.0, 1.0) + vec3(x, 0, z);
			}
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec3) * MESHSIZE * MESHSIZE * 4, vertices, GL_DYNAMIC_DRAW);
		glEnableVertexAttribArray(0);
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
		//tex coords
		float t = 1. / 60.;
		vec2 tex[MESHSIZE * MESHSIZE * 4];
		for (int x = 0; x < MESHSIZE; x++)
			for (int y = 0; y < MESHSIZE; y++)
			{
				tex[x * 4 + y * MESHSIZE * 4 + 0] = vec2(0.0, 0.0) + vec2(x, y)*t;
				tex[x * 4 + y * MESHSIZE * 4 + 1] = vec2(t, 0.0) + vec2(x, y)*t;
				tex[x * 4 + y * MESHSIZE * 4 + 2] = vec2(t, t) + vec2(x, y)*t;
				tex[x * 4 + y * MESHSIZE * 4 + 3] = vec2(0.0, t) + vec2(x, y)*t;
			}
		glGenBuffers(1, &MeshTexID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, MeshTexID);
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec2) * MESHSIZE * MESHSIZE * 4, tex, GL_STATIC_DRAW);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

		glGenBuffers(1, &IndexBufferIDBox);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox);
		GLushort elements[MESHSIZE * MESHSIZE * 6];
		int ind = 0;
		for (int i = 0; i<MESHSIZE * MESHSIZE * 6; i += 6, ind += 4)
		{
			elements[i + 0] = ind + 0;
			elements[i + 1] = ind + 1;
			elements[i + 2] = ind + 2;
			elements[i + 3] = ind + 0;
			elements[i + 4] = ind + 2;
			elements[i + 5] = ind + 3;
		}
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLushort)*MESHSIZE * MESHSIZE * 6, elements, GL_STATIC_DRAW);
		glBindVertexArray(0);
	}

	/*Note that any gl calls must always happen after a GL state is initialized */
	void initGeom()
	{
		glGenVertexArrays(1, &VertexArrayIDRect);
		glBindVertexArray(VertexArrayIDRect);

		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &VertexBufferIDRect);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexBufferIDRect);

		GLfloat *ver = new GLfloat[18];
		// front
		int verc = 0;

		ver[verc++] = -1.0, ver[verc++] = -1.0, ver[verc++] = 0.0;
		ver[verc++] = 1.0, ver[verc++] = -1.0, ver[verc++] = 0.0;
		ver[verc++] = -1.0, ver[verc++] = 1.0, ver[verc++] = 0.0;
		ver[verc++] = 1.0, ver[verc++] = -1.0, ver[verc++] = 0.0;
		ver[verc++] = 1.0, ver[verc++] = 1.0, ver[verc++] = 0.0;
		ver[verc++] = -1.0, ver[verc++] = 1.0, ver[verc++] = 0.0;


		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, 18 * sizeof(float), ver, GL_STATIC_DRAW);
		//we need to set up the vertex array
		glEnableVertexAttribArray(0);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);


		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &VertexBufferTexRect);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexBufferTexRect);

		float t = 1. / 100.;
		GLfloat *cube_tex = new GLfloat[12];
		int texc = 0;

		cube_tex[texc++] = 0, cube_tex[texc++] = 0;
		cube_tex[texc++] = 1, cube_tex[texc++] = 0;
		cube_tex[texc++] = 0, cube_tex[texc++] = 1;
		cube_tex[texc++] = 1, cube_tex[texc++] = 0;
		cube_tex[texc++] = 1, cube_tex[texc++] = 1;
		cube_tex[texc++] = 0, cube_tex[texc++] = 1;

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, 12 * sizeof(float), cube_tex, GL_STATIC_DRAW);
		//we need to set up the vertex array
		glEnableVertexAttribArray(1);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

		string resourceDirectory = "../resources" ;
		// Initialize mesh.
		cylinder = make_shared<Shape>();
		cylinder->loadMesh(resourceDirectory + "/cylinder.obj");
		cylinder->resize();
		cylinder->init();

		// Initialize mesh.
		cube = make_shared<Shape>();
		cube->loadMesh(resourceDirectory + "/cube.obj");
		cube->resize();
		cube->init();

		// Initialize mesh.
		sphere = make_shared<Shape>();
		sphere->loadMesh(resourceDirectory + "/sphere.obj");
		sphere->resize();
		sphere->init();

		// Initialize mesh.
		cone = make_shared<Shape>();
		cone->loadMesh(resourceDirectory + "/cone.obj");
		cone->resize();
		cone->init();

		init_mesh();

		//generate the VAO
		glGenVertexArrays(1, &VertexArrayIDSquare);
		glBindVertexArray(VertexArrayIDSquare);

		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &VertexBufferIDSquare);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexBufferIDSquare);

		GLfloat square_vertices[] = {
			-1.0, -1.0,  1.0,//LD
			1.0, -1.0,  1.0,//RD
			1.0,  1.0,  1.0,//RU
			-1.0,  1.0,  1.0,//LU
		};
		//for (int i = 0; i < 12; i++)
		//	square_vertices[i] *= 0.5;
		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(square_vertices), square_vertices, GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(0);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//normals
		GLfloat square_normals[] = {
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,

		};
		glGenBuffers(1, &VertexNormalIDSquare);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexNormalIDSquare);
		glBufferData(GL_ARRAY_BUFFER, sizeof(square_normals), square_normals, GL_STATIC_DRAW);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//textures
		glm::vec2 square_textures[] = {
			glm::vec2(0.0, 1.0),
			glm::vec2(1.0, 1.0),
			glm::vec2(1.0, 0.0),
			glm::vec2(0.0, 0.0),

		};
		glGenBuffers(1, &VertexTextureIDSquare);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexTextureIDSquare);
		glBufferData(GL_ARRAY_BUFFER, sizeof(square_textures), square_textures, GL_STATIC_DRAW);
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

		glGenBuffers(1, &IndexBufferIDSquare);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDSquare);
		GLushort square_elements[] = {
			0, 1, 2,
			2, 3, 0,
		};
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(square_elements), square_elements, GL_STATIC_DRAW);

		
		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &InstanceBufferSand);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, InstanceBufferSand);
		glm::vec4 *positions = new glm::vec4[3540];
		int i = 0;
		for (int x = 0; x < 59; x++) {
			for (int z = -40; z < 20; z++) {
				positions[i++] = glm::vec4(x, -0.5f, z, 0);
			}
		}
		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, 3540 * sizeof(glm::vec4), positions, GL_STATIC_DRAW);
		int position_loc = glGetAttribLocation(progSand->pid, "InstancePosition");
		for (int i = 0; i < 3540; i++)
		{
			// Set up the vertex attribute
			glVertexAttribPointer(position_loc + i,              // Location
				4, GL_FLOAT, GL_FALSE,       // vec4
				sizeof(vec4),                // Stride
				(void *)(sizeof(vec4) * i)); // Start offset
											 // Enable it
			glEnableVertexAttribArray(position_loc + i);
			// Make it instanced
			glVertexAttribDivisor(position_loc + i, 1);
		}

		glBindVertexArray(0);
		
		int width, height, channels;
		char filepath[1000];

		//texture 1
		string str = resourceDirectory + "/sbsand.jpg";
		strcpy(filepath, str.c_str());
		unsigned char* data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 2
		str = resourceDirectory + "/pineapple.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture2);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, Texture2);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 3
		str = resourceDirectory + "/sbroad.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture3);
		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D, Texture3);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 4
		str = resourceDirectory + "/skybox.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture4);
		glActiveTexture(GL_TEXTURE3);
		glBindTexture(GL_TEXTURE_2D, Texture4);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 5 (height)
		str = resourceDirectory + "/hills.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &HeightTexture);
		glActiveTexture(GL_TEXTURE4);
		glBindTexture(GL_TEXTURE_2D, HeightTexture);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 6
		str = resourceDirectory + "/grass.jpg";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture6);
		glActiveTexture(GL_TEXTURE5);
		glBindTexture(GL_TEXTURE_2D, Texture6);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 7
		str = resourceDirectory + "/grass.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture7);
		glActiveTexture(GL_TEXTURE6);
		glBindTexture(GL_TEXTURE_2D, Texture7);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 8
		str = resourceDirectory + "/jellyfish.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture8);
		glActiveTexture(GL_TEXTURE7);
		glBindTexture(GL_TEXTURE_2D, Texture8);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//texture 8
		str = resourceDirectory + "/krustykrab.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture9);
		glActiveTexture(GL_TEXTURE8);
		glBindTexture(GL_TEXTURE_2D, Texture9);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
		//[TWOTEXTURES]
		//set the 2 textures to the correct samplers in the fragment shader:
		GLuint Tex1Location = glGetUniformLocation(progSand->pid, "tex");//tex, tex2... sampler in the fragment shader
		GLuint Tex2Location = glGetUniformLocation(progPine->pid, "tex2");
		GLuint Tex3Location = glGetUniformLocation(progRoad->pid, "tex3");
		GLuint Tex4Location = glGetUniformLocation(progSkybox->pid, "tex4");
		GLuint HeightTexLocation = glGetUniformLocation(progJellyFields->pid, "tex5");
		GLuint GrassTexLocation = glGetUniformLocation(progJellyFields->pid, "tex6");
		GLuint Grass2TexLocation = glGetUniformLocation(progJellyFields->pid, "tex7");
		GLuint JellyTexLocation = glGetUniformLocation(progJelly->pid, "texJelly");
		GLuint KKTexLocation = glGetUniformLocation(progKK->pid, "texKK");
		GLuint KKCTexLocation = glGetUniformLocation(progKKC->pid, "texKK");
		GLuint KKBTexLocation = glGetUniformLocation(progKKB->pid, "texKK");
		GLuint KKDBTexLocation = glGetUniformLocation(progKKDB->pid, "texKK");
		// Then bind the uniform samplers to texture units:
		glUseProgram(progSand->pid);
		glUniform1i(Tex1Location, 0);
		
		glUseProgram(progPine->pid);
		glUniform1i(Tex2Location, 0);
		
		glUseProgram(progRoad->pid);
		glUniform1i(Tex3Location, 0);
		
		glUseProgram(progSkybox->pid);
		glUniform1i(Tex4Location, 0);
		
		glUseProgram(progJellyFields->pid);
		glUniform1i(HeightTexLocation, 0);
		glUniform1i(GrassTexLocation, 1);
		glUniform1i(Grass2TexLocation, 2);
		
		glUseProgram(progJelly->pid);
		glUniform1i(JellyTexLocation, 0);

		glUseProgram(progKK->pid);
		glUniform1i(KKTexLocation, 0);

		glUseProgram(progKKC->pid);
		glUniform1i(KKCTexLocation, 0);
		
		glUseProgram(progKKB->pid);
		glUniform1i(KKBTexLocation, 0);

		glUseProgram(progKKDB->pid);
		glUniform1i(KKDBTexLocation, 0);
		

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		//Frame Buffer Object
		glfwGetFramebufferSize(windowManager->getHandle(), &width, &height);
		//RGBA8 2D texture, 24 bit depth texture, 256x256
		glGenTextures(1, &FBOtex);
		glBindTexture(GL_TEXTURE_2D, FBOtex);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		//NULL means reserve texture memory, but texels are undefined
		//**** Tell OpenGL to reserve level 0
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_BGRA, GL_UNSIGNED_BYTE, NULL);
		//You must reserve memory for other mipmaps levels as well either by making a series of calls to
		//glTexImage2D or use glGenerateMipmapEXT(GL_TEXTURE_2D).
		//Here, we'll use :
		glGenerateMipmap(GL_TEXTURE_2D);
		//-------------------------
		glGenFramebuffers(1, &FrameBufferObj);
		glBindFramebuffer(GL_FRAMEBUFFER, FrameBufferObj);
		//Attach 2D texture to this FBO
		glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, FBOtex, 0);
		//-------------------------
		glGenRenderbuffers(1, &depth_rb);
		glBindRenderbuffer(GL_RENDERBUFFER, depth_rb);
		glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, width, height);
		//-------------------------
		//Attach depth buffer to FBO
		glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, depth_rb);
		//-------------------------
		//Does the GPU support current FBO configuration?
		GLenum status;
		status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
		switch (status)
		{
		case GL_FRAMEBUFFER_COMPLETE:
			cout << "status framebuffer: good";
			break;
		default:
			cout << "status framebuffer: bad!!!!!!!!!!!!!!!!!!!!!!!!!";
		}
		glBindFramebuffer(GL_FRAMEBUFFER, 0);

		GLuint TexFBLocation = glGetUniformLocation(progFramebuffer->pid, "texFB");
		glUseProgram(progFramebuffer->pid);
		glUniform1i(TexFBLocation, 0);
	}

	//General OGL initialization - set OGL state here
	void init(const std::string& resourceDirectory)
	{
		GLSL::checkVersion();

		// Set background color.
		glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
		// Enable z-buffer test.
		glEnable(GL_DEPTH_TEST);

		// Initialize the GLSL program.
		prog = std::make_shared<Program>();
		prog->setVerbose(true);
		prog->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment.glsl");
		if (!prog->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog->addUniform("P");
		prog->addUniform("V");
		prog->addUniform("M");
		prog->addUniform("campos");
		prog->addAttribute("vertPos");
		prog->addAttribute("vertNor");
		prog->addAttribute("vertTex");

		// Initialize the GLSL program.
		progFramebuffer = make_shared<Program>();
		progFramebuffer->setVerbose(true);
		progFramebuffer->setShaderNames(resourceDirectory + "/shader_vertex_framebuffer.glsl", resourceDirectory + "/shader_fragment_framebuffer.glsl");
		if (!progFramebuffer->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progFramebuffer->init();
		progFramebuffer->addAttribute("vertPos");
		progFramebuffer->addAttribute("vertTex");
		progFramebuffer->addUniform("underwater");

		// Initialize the GLSL program.
		progSkybox = std::make_shared<Program>();
		progSkybox->setVerbose(true);
		progSkybox->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_skybox.glsl");
		if (!progSkybox->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSkybox->addUniform("P");
		progSkybox->addUniform("V");
		progSkybox->addUniform("M");
		progSkybox->addUniform("campos");
		progSkybox->addAttribute("vertPos");
		progSkybox->addAttribute("vertNor");
		progSkybox->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSand = std::make_shared<Program>();
		progSand->setVerbose(true);
		progSand->setShaderNames(resourceDirectory + "/shader_vertex_instance.glsl", resourceDirectory + "/shader_fragment_sand.glsl");
		if (!progSand->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSand->addUniform("P");
		progSand->addUniform("V");
		progSand->addUniform("M");
		progSand->addUniform("campos");
		progSand->addAttribute("vertPos");
		progSand->addAttribute("vertNor");
		progSand->addAttribute("vertTex");
		progSand->addAttribute("InstancePosition");

		// Initialize the GLSL program.
		progRoad = std::make_shared<Program>();
		progRoad->setVerbose(true);
		progRoad->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_road.glsl");
		if (!progRoad->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progRoad->addUniform("P");
		progRoad->addUniform("V");
		progRoad->addUniform("M");
		progRoad->addUniform("campos");
		progRoad->addAttribute("vertPos");
		progRoad->addAttribute("vertNor");
		progRoad->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPebbles = std::make_shared<Program>();
		progPebbles->setVerbose(true);
		progPebbles->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_pebbles.glsl");
		if (!progPebbles->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPebbles->addUniform("P");
		progPebbles->addUniform("V");
		progPebbles->addUniform("M");
		progPebbles->addUniform("campos");
		progPebbles->addAttribute("vertPos");
		progPebbles->addAttribute("vertNor");
		progPebbles->addAttribute("vertTex");

		// Initialize the GLSL program.
		progJellyFields = std::make_shared<Program>();
		progJellyFields->setVerbose(true);
		progJellyFields->setShaderNames(resourceDirectory + "/shader_vertex_jellyfields.glsl", resourceDirectory + "/shader_fragment_jellyfields.glsl");
		if (!progJellyFields->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progJellyFields->addUniform("P");
		progJellyFields->addUniform("V");
		progJellyFields->addUniform("M");
		progJellyFields->addUniform("campos");
		progJellyFields->addUniform("camoff");
		progJellyFields->addAttribute("vertPos");
		progJellyFields->addAttribute("vertNor");
		progJellyFields->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPRock = std::make_shared<Program>();
		progPRock->setVerbose(true);
		progPRock->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_prock.glsl");
		if (!progPRock->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPRock->addUniform("P");
		progPRock->addUniform("V");
		progPRock->addUniform("M");
		progPRock->addUniform("campos");
		progPRock->addAttribute("vertPos");
		progPRock->addAttribute("vertNor");
		progPRock->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPRockA = std::make_shared<Program>();
		progPRockA->setVerbose(true);
		progPRockA->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_prockArrow.glsl");
		if (!progPRockA->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPRockA->addUniform("P");
		progPRockA->addUniform("V");
		progPRockA->addUniform("M");
		progPRockA->addUniform("campos");
		progPRockA->addAttribute("vertPos");
		progPRockA->addAttribute("vertNor");
		progPRockA->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSHouse = std::make_shared<Program>();
		progSHouse->setVerbose(true);
		progSHouse->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_shouse.glsl");
		if (!progSHouse->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSHouse->addUniform("P");
		progSHouse->addUniform("V");
		progSHouse->addUniform("M");
		progSHouse->addUniform("campos");
		progSHouse->addAttribute("vertPos");
		progSHouse->addAttribute("vertNor");
		progSHouse->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSHouseN = std::make_shared<Program>();
		progSHouseN->setVerbose(true);
		progSHouseN->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_shouseNose.glsl");
		if (!progSHouseN->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSHouseN->addUniform("P");
		progSHouseN->addUniform("V");
		progSHouseN->addUniform("M");
		progSHouseN->addUniform("campos");
		progSHouseN->addAttribute("vertPos");
		progSHouseN->addAttribute("vertNor");
		progSHouseN->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSHouseD = std::make_shared<Program>();
		progSHouseD->setVerbose(true);
		progSHouseD->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_shouseDoor.glsl");
		if (!progSHouseD->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSHouseD->addUniform("P");
		progSHouseD->addUniform("V");
		progSHouseD->addUniform("M");
		progSHouseD->addUniform("campos");
		progSHouseD->addAttribute("vertPos");
		progSHouseD->addAttribute("vertNor");
		progSHouseD->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSHouseW = std::make_shared<Program>();
		progSHouseW->setVerbose(true);
		progSHouseW->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_shouseWindow.glsl");
		if (!progSHouseW->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSHouseW->addUniform("P");
		progSHouseW->addUniform("V");
		progSHouseW->addUniform("M");
		progSHouseW->addUniform("campos");
		progSHouseW->addAttribute("vertPos");
		progSHouseW->addAttribute("vertNor");
		progSHouseW->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPine = std::make_shared<Program>();
		progPine->setVerbose(true);
		progPine->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_pineapple.glsl");
		if (!progPine->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPine->addUniform("P");
		progPine->addUniform("V");
		progPine->addUniform("M");
		progPine->addUniform("campos");
		progPine->addAttribute("vertPos");
		progPine->addAttribute("vertNor");
		progPine->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPineD = std::make_shared<Program>();
		progPineD->setVerbose(true);
		progPineD->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_pineappleDoor.glsl");
		if (!progPineD->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPineD->addUniform("P");
		progPineD->addUniform("V");
		progPineD->addUniform("M");
		progPineD->addUniform("campos");
		progPineD->addAttribute("vertPos");
		progPineD->addAttribute("vertNor");
		progPineD->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPineDP = std::make_shared<Program>();
		progPineDP->setVerbose(true);
		progPineDP->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_pineappleDoorParts.glsl");
		if (!progPineDP->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPineDP->addUniform("P");
		progPineDP->addUniform("V");
		progPineDP->addUniform("M");
		progPineDP->addUniform("campos");
		progPineDP->addAttribute("vertPos");
		progPineDP->addAttribute("vertNor");
		progPineDP->addAttribute("vertTex");

		// Initialize the GLSL program.
		progLeaf = std::make_shared<Program>();
		progLeaf->setVerbose(true);
		progLeaf->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_pineappleLeaf.glsl");
		if (!progLeaf->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progLeaf->addUniform("P");
		progLeaf->addUniform("V");
		progLeaf->addUniform("M");
		progLeaf->addUniform("campos");
		progLeaf->addAttribute("vertPos");
		progLeaf->addAttribute("vertNor");
		progLeaf->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPineW = std::make_shared<Program>();
		progPineW->setVerbose(true);
		progPineW->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_pineappleWindow.glsl");
		if (!progPineW->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPineW->addUniform("P");
		progPineW->addUniform("V");
		progPineW->addUniform("M");
		progPineW->addUniform("campos");
		progPineW->addAttribute("vertPos");
		progPineW->addAttribute("vertNor");
		progPineW->addAttribute("vertTex");

		// Initialize the GLSL program.
		progWGlass = std::make_shared<Program>();
		progWGlass->setVerbose(true);
		progWGlass->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_windowglass.glsl");
		if (!progWGlass->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progWGlass->addUniform("P");
		progWGlass->addUniform("V");
		progWGlass->addUniform("M");
		progWGlass->addUniform("campos");
		progWGlass->addAttribute("vertPos");
		progWGlass->addAttribute("vertNor");
		progWGlass->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSquid = std::make_shared<Program>();
		progSquid->setVerbose(true);
		progSquid->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_squidward.glsl");
		if (!progSquid->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSquid->addUniform("P");
		progSquid->addUniform("V");
		progSquid->addUniform("M");
		progSquid->addUniform("campos");
		progSquid->addAttribute("vertPos");
		progSquid->addAttribute("vertNor");
		progSquid->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSquidS = std::make_shared<Program>();
		progSquidS->setVerbose(true);
		progSquidS->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_squidward_shirt.glsl");
		if (!progSquidS->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSquidS->addUniform("P");
		progSquidS->addUniform("V");
		progSquidS->addUniform("M");
		progSquidS->addUniform("campos");
		progSquidS->addAttribute("vertPos");
		progSquidS->addAttribute("vertNor");
		progSquidS->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSquidE = std::make_shared<Program>();
		progSquidE->setVerbose(true);
		progSquidE->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_squidward_eyes.glsl");
		if (!progSquidE->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSquidE->addUniform("P");
		progSquidE->addUniform("V");
		progSquidE->addUniform("M");
		progSquidE->addUniform("campos");
		progSquidE->addAttribute("vertPos");
		progSquidE->addAttribute("vertNor");
		progSquidE->addAttribute("vertTex");

		// Initialize the GLSL program.
		progSquidM = std::make_shared<Program>();
		progSquidM->setVerbose(true);
		progSquidM->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_squidward_mouth.glsl");
		if (!progSquidM->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progSquidM->addUniform("P");
		progSquidM->addUniform("V");
		progSquidM->addUniform("M");
		progSquidM->addUniform("campos");
		progSquidM->addAttribute("vertPos");
		progSquidM->addAttribute("vertNor");
		progSquidM->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPat = std::make_shared<Program>();
		progPat->setVerbose(true);
		progPat->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_patrick.glsl");
		if (!progPat->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPat->addUniform("P");
		progPat->addUniform("V");
		progPat->addUniform("M");
		progPat->addUniform("campos");
		progPat->addAttribute("vertPos");
		progPat->addAttribute("vertNor");
		progPat->addAttribute("vertTex");

		// Initialize the GLSL program.
		progPatE = std::make_shared<Program>();
		progPatE->setVerbose(true);
		progPatE->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_patrick_eyes.glsl");
		if (!progPatE->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPatE->addUniform("P");
		progPatE->addUniform("V");
		progPatE->addUniform("M");
		progPatE->addUniform("campos");
		progPatE->addAttribute("vertPos");
		progPatE->addAttribute("vertNor");
		progPatE->addAttribute("vertTex");
		
		// Initialize the GLSL program.
		progPatF = std::make_shared<Program>();
		progPatF->setVerbose(true);
		progPatF->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_patrick_face.glsl");
		if (!progPatF->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPatF->addUniform("P");
		progPatF->addUniform("V");
		progPatF->addUniform("M");
		progPatF->addUniform("campos");
		progPatF->addAttribute("vertPos");
		progPatF->addAttribute("vertNor");
		progPatF->addAttribute("vertTex");
		
		// Initialize the GLSL program.
		progPatS = std::make_shared<Program>();
		progPatS->setVerbose(true);
		progPatS->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_patrick_shorts.glsl");
		if (!progPatS->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPatS->addUniform("P");
		progPatS->addUniform("V");
		progPatS->addUniform("M");
		progPatS->addUniform("campos");
		progPatS->addAttribute("vertPos");
		progPatS->addAttribute("vertNor");
		progPatS->addAttribute("vertTex");
		
		// Initialize the GLSL program.
		progPatL = std::make_shared<Program>();
		progPatL->setVerbose(true);
		progPatL->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_patrick_shorts_legs.glsl");
		if (!progPatL->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progPatL->addUniform("P");
		progPatL->addUniform("V");
		progPatL->addUniform("M");
		progPatL->addUniform("campos");
		progPatL->addAttribute("vertPos");
		progPatL->addAttribute("vertNor");
		progPatL->addAttribute("vertTex");

		// Initialize the GLSL program.
		progJelly = std::make_shared<Program>();
		progJelly->setVerbose(true);
		progJelly->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_jelly.glsl");
		if (!progJelly->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progJelly->addUniform("P");
		progJelly->addUniform("V");
		progJelly->addUniform("M");
		progJelly->addUniform("campos");
		progJelly->addUniform("offset");
		progJelly->addAttribute("vertPos");
		progJelly->addAttribute("vertNor");
		progJelly->addAttribute("vertTex");

		// Initialize the GLSL program. (Spongebob)
		progBob = std::make_shared<Program>();
		progBob->setVerbose(true);
		progBob->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_sponge.glsl");
		progBob->init();
		progBob->addUniform("P");
		progBob->addUniform("V");
		progBob->addUniform("M");
		progBob->addUniform("campos");
		progBob->addAttribute("vertPos");
		progBob->addAttribute("vertNor");
		progBob->addAttribute("vertTex");

		progP = std::make_shared<Program>();
		progP->setVerbose(true);
		progP->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_pant.glsl");
		progP->init();
		progP->addUniform("P");
		progP->addUniform("V");
		progP->addUniform("M");
		progP->addUniform("campos");
		progP->addAttribute("vertPos");
		progP->addAttribute("vertNor");
		progP->addAttribute("vertTex");

		progUA = std::make_shared<Program>();
		progUA->setVerbose(true);
		progUA->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_upperarm.glsl");
		progUA->init();
		progUA->addUniform("P");
		progUA->addUniform("V");
		progUA->addUniform("M");
		progUA->addUniform("campos");
		progUA->addAttribute("vertPos");
		progUA->addAttribute("vertNor");
		progUA->addAttribute("vertTex");

		progNA = std::make_shared<Program>();
		progNA->setVerbose(true);
		progNA->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_nose+arm.glsl");
		progNA->init();
		progNA->addUniform("P");
		progNA->addUniform("V");
		progNA->addUniform("M");
		progNA->addUniform("campos");
		progNA->addAttribute("vertPos");
		progNA->addAttribute("vertNor");
		progNA->addAttribute("vertTex");

		progNAsphere = std::make_shared<Program>();
		progNAsphere->setVerbose(true);
		progNAsphere->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_nose+arm.glsl");
		progNAsphere->init();
		progNAsphere->addUniform("P");
		progNAsphere->addUniform("V");
		progNAsphere->addUniform("M");
		progNAsphere->addUniform("campos");
		progNAsphere->addAttribute("vertPos");
		progNAsphere->addAttribute("vertNor");
		progNAsphere->addAttribute("vertTex");

		progNT = std::make_shared<Program>();
		progNT->setVerbose(true);
		progNT->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_nosetip.glsl");
		progNT->init();
		progNT->addUniform("P");
		progNT->addUniform("V");
		progNT->addUniform("M");
		progNT->addUniform("campos");
		progNT->addAttribute("vertPos");
		progNT->addAttribute("vertNor");
		progNT->addAttribute("vertTex");

		progL = std::make_shared<Program>();
		progL->setVerbose(true);
		progL->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_leg.glsl");
		progL->init();
		progL->addUniform("P");
		progL->addUniform("V");
		progL->addUniform("M");
		progL->addUniform("campos");
		progL->addAttribute("vertPos");
		progL->addAttribute("vertNor");
		progL->addAttribute("vertTex");

		progE = std::make_shared<Program>();
		progE->setVerbose(true);
		progE->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_eye.glsl");
		progE->init();
		progE->addUniform("P");
		progE->addUniform("V");
		progE->addUniform("M");
		progE->addUniform("campos");
		progE->addAttribute("vertPos");
		progE->addAttribute("vertNor");
		progE->addAttribute("vertTex");

		progS = std::make_shared<Program>();
		progS->setVerbose(true);
		progS->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_shoe.glsl");
		progS->init();
		progS->addUniform("P");
		progS->addUniform("V");
		progS->addUniform("M");
		progS->addUniform("campos");
		progS->addAttribute("vertPos");
		progS->addAttribute("vertNor");
		progS->addAttribute("vertTex");

		progC = std::make_shared<Program>();
		progC->setVerbose(true);
		progC->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_cheek.glsl");
		progC->init();
		progC->addUniform("P");
		progC->addUniform("V");
		progC->addUniform("M");
		progC->addUniform("campos");
		progC->addAttribute("vertPos");
		progC->addAttribute("vertNor");
		progC->addAttribute("vertTex");

		// Initialize the GLSL program.
		progStick = std::make_shared<Program>();
		progStick->setVerbose(true);
		progStick->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_stick.glsl");
		if (!progStick->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progStick->addUniform("P");
		progStick->addUniform("V");
		progStick->addUniform("M");
		progStick->addUniform("campos");
		progStick->addAttribute("vertPos");
		progStick->addAttribute("vertNor");
		progStick->addAttribute("vertTex");

		// Initialize the GLSL program.
		progLoop = std::make_shared<Program>();
		progLoop->setVerbose(true);
		progLoop->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_stickLoop.glsl");
		if (!progLoop->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progLoop->addUniform("P");
		progLoop->addUniform("V");
		progLoop->addUniform("M");
		progLoop->addUniform("campos");
		progLoop->addAttribute("vertPos");
		progLoop->addAttribute("vertNor");
		progLoop->addAttribute("vertTex");

		// Initialize the GLSL program.
		progNet = std::make_shared<Program>();
		progNet->setVerbose(true);
		progNet->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_stickNet.glsl");
		if (!progNet->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progNet->addUniform("P");
		progNet->addUniform("V");
		progNet->addUniform("M");
		progNet->addUniform("campos");
		progNet->addAttribute("vertPos");
		progNet->addAttribute("vertNor");
		progNet->addAttribute("vertTex");

		// Initialize the GLSL program.
		progKK = std::make_shared<Program>();
		progKK->setVerbose(true);
		progKK->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_KK.glsl");
		if (!progKK->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progKK->addUniform("P");
		progKK->addUniform("V");
		progKK->addUniform("M");
		progKK->addUniform("campos");
		progKK->addAttribute("vertPos");
		progKK->addAttribute("vertNor");
		progKK->addAttribute("vertTex");

		// Initialize the GLSL program.
		progKKC = std::make_shared<Program>();
		progKKC->setVerbose(true);
		progKKC->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_KKC.glsl");
		if (!progKKC->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progKKC->addUniform("P");
		progKKC->addUniform("V");
		progKKC->addUniform("M");
		progKKC->addUniform("campos");
		progKKC->addAttribute("vertPos");
		progKKC->addAttribute("vertNor");
		progKKC->addAttribute("vertTex");

		// Initialize the GLSL program.
		progKKB = std::make_shared<Program>();
		progKKB->setVerbose(true);
		progKKB->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_KKborder.glsl");
		if (!progKKB->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progKKB->addUniform("P");
		progKKB->addUniform("V");
		progKKB->addUniform("M");
		progKKB->addUniform("campos");
		progKKB->addAttribute("vertPos");
		progKKB->addAttribute("vertNor");
		progKKB->addAttribute("vertTex");

		// Initialize the GLSL program.
		progKKDB = std::make_shared<Program>();
		progKKDB->setVerbose(true);
		progKKDB->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_KKdborder.glsl");
		if (!progKKDB->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progKKDB->addUniform("P");
		progKKDB->addUniform("V");
		progKKDB->addUniform("M");
		progKKDB->addUniform("campos");
		progKKDB->addAttribute("vertPos");
		progKKDB->addAttribute("vertNor");
		progKKDB->addAttribute("vertTex");

		// Initialize the GLSL program.
		progKKGlass = std::make_shared<Program>();
		progKKGlass->setVerbose(true);
		progKKGlass->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment_KKwindowglass.glsl");
		if (!progKKGlass->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		progKKGlass->addUniform("P");
		progKKGlass->addUniform("V");
		progKKGlass->addUniform("M");
		progKKGlass->addUniform("campos");
		progKKGlass->addAttribute("vertPos");
		progKKGlass->addAttribute("vertNor");
		progKKGlass->addAttribute("vertTex");
	}


	/****DRAW
	This is the most important function in your program - this is where you
	will actually issue the commands to draw any geometry you have set up to
	draw
	********/
	void render()
	{
		// Get current frame buffer size.
		int width, height;
		glfwGetFramebufferSize(windowManager->getHandle(), &width, &height);
		float aspect = width / (float)height;
		glViewport(0, 0, width, height);

		static float underwater = 0.0f;
		if (setUnderwater == 0) {
			underwater = 0.0f;
		}
		else {
			underwater += 0.1f;
		}

		// Clear framebuffer.
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		progFramebuffer->bind();
		glUniform1f(progFramebuffer->getUniform("underwater"), underwater);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, FBOtex);
		glBindVertexArray(VertexArrayIDRect);
		glDrawArrays(GL_TRIANGLES, 0, 6);
		progFramebuffer->unbind();

	}

	void render_to_framebuffer()
	{
		glBindFramebuffer(GL_FRAMEBUFFER, FrameBufferObj);

		double frametime = get_last_elapsed_time();
		static double totaltime = 0;
		totaltime += frametime;

		// Get current frame buffer size.
		int width, height;
		glfwGetFramebufferSize(windowManager->getHandle(), &width, &height);
		float aspect = width/(float)height;
		glViewport(0, 0, width, height);

		// Clear framebuffer.
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Create the matrix stacks - please leave these alone for now
		
		glm::mat4 V, M, P; //View, Model and Perspective matrix
		V = mycam.process(frametime);
		M = glm::mat4(1);
		// Apply orthographic projection....
		P = glm::perspective((float)(3.14159 / 4.), (float)((float)width/ (float)height), 0.1f, 1000.0f); //so much type casting... GLM metods are quite funny ones

		/*********************************************************************************************************************/
		//Rotate inverted textures!
		float angle = -3.1415926/2.0;
		float angle2 = -3.1415926 / 4.0;
		glm::mat4 RotateX = glm::rotate(glm::mat4(1.0f), angle, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 RotateNX = glm::rotate(glm::mat4(1.0f), -angle, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 RotateY = glm::rotate(glm::mat4(1.0f), angle, glm::vec3(0.0f, 1.0f, 0.0f));
		glm::mat4 RotateNY = glm::rotate(glm::mat4(1.0f), -angle, glm::vec3(0.0f, 1.0f, 0.0f));
		
		/*********************************************************************************************************************/
		//SKYBOX
		progSkybox->bind();
		glUniformMatrix4fv(progSkybox->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSkybox->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSkybox->getUniform("campos"), 1, &mycam.pos[0]);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture4);

		glm::vec3 camp = -mycam.pos;
		glm::mat4 TransSky = glm::translate(glm::mat4(1.0f), camp);
		glm::mat4 SSky = glm::scale(glm::mat4(1.0f), glm::vec3(10.0f, 8.50f, 10.0f));
		M = TransSky * SSky * RotateNX;

		glUniformMatrix4fv(progSkybox->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glDisable(GL_DEPTH_TEST);
		sphere->draw(progSkybox, FALSE);
		glEnable(GL_DEPTH_TEST);

		progSkybox->unbind();
		
		/*********************************************************************************************************************/
		//FLOOR-SAND
		glm::mat4 SFloor = glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 0.01f, 1.0f));
		glm::mat4 SFloor2 = glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 1.0f, 0.0f));

		progSand->bind();
		glUniformMatrix4fv(progSand->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSand->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSand->getUniform("campos"), 1, &mycam.pos[0]);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture);

		glBindVertexArray(VertexArrayIDSquare);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDSquare);

		M = RotateX * SFloor2;
		glUniformMatrix4fv(progSand->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glDrawElementsInstanced(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0, 3540);
		glBindVertexArray(0);

		progSand->unbind();

		/*********************************************************************************************************************/
		//ROADS
		progRoad->bind();
		glUniformMatrix4fv(progRoad->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progRoad->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progRoad->getUniform("campos"), 1, &mycam.pos[0]);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture3);

		glBindVertexArray(VertexArrayIDSquare);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDSquare);

		for (int x = 0; x < 59; x++) {
			for (int z = 21; z < 23; z++) {
				glm::mat4 TransRoad = glm::translate(glm::mat4(1.0f), glm::vec3(x, -0.5f, z));
				M = TransRoad * RotateNX * SFloor2;
				glUniformMatrix4fv(progRoad->getUniform("M"), 1, GL_FALSE, &M[0][0]);
				glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);
			}
		}

		glBindVertexArray(0);

		for (float z = 7.725; z < 20; z++) {
			glm::mat4 TransPatRoad = glm::translate(glm::mat4(1.0f), glm::vec3(5.0f, -0.499f, z));
			M = TransPatRoad * SFloor;
			glUniformMatrix4fv(progRoad->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			cube->draw(progRoad, FALSE);
		}

		for (int z = 7; z < 20; z++) {
			glm::mat4 TransBobRoad = glm::translate(glm::mat4(1.0f), glm::vec3(25.0f, -0.499f, z));
			M = TransBobRoad * SFloor;
			glUniformMatrix4fv(progRoad->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			cube->draw(progRoad, FALSE);
		}

		for (float x = 44.5; x < 46; x++) {
			for (int z = -25; z < 20; z++) {
				glm::mat4 TransKKRoad = glm::translate(glm::mat4(1.0f), glm::vec3(x, -0.499f, z));
				M = TransKKRoad * SFloor;
				glUniformMatrix4fv(progRoad->getUniform("M"), 1, GL_FALSE, &M[0][0]);
				cube->draw(progRoad, FALSE);
			}
		}

		progRoad->unbind();

		//Pebbles
		progPebbles->bind();
		glUniformMatrix4fv(progPebbles->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPebbles->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPebbles->getUniform("campos"), 1, &mycam.pos[0]);


		glm::mat4 SPebble = glm::scale(glm::mat4(1.0f), glm::vec3(0.45f, 0.01f, 0.45f));
		glm::mat4 SPebble2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.4f, 0.01f, 0.4f));
		glm::mat4 SPebble3 = glm::scale(glm::mat4(1.0f), glm::vec3(0.3f, 0.01f, 0.3f));
		glm::mat4 SPebble4 = glm::scale(glm::mat4(1.0f), glm::vec3(0.15f, 0.01f, 0.15f));
		
		for (int z = 7; z < 20; z += 2) {
			glm::mat4 TransBobRoad1 = glm::translate(glm::mat4(1.0f), glm::vec3(25.25f, -0.49f, z));
			M = TransBobRoad1 * SPebble;
			glUniformMatrix4fv(progPebbles->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			sphere->draw(progPebbles, FALSE);
		}
		for (int z = 8; z < 20; z += 2) {
			glm::mat4 TransBobRoad2 = glm::translate(glm::mat4(1.0f), glm::vec3(24.75f, -0.49f, z));
			M = TransBobRoad2 * SPebble2;
			glUniformMatrix4fv(progPebbles->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			sphere->draw(progPebbles, FALSE);
		}
		for (int z = 8; z < 20; z += 2) {
			glm::mat4 TransBobRoad3 = glm::translate(glm::mat4(1.0f), glm::vec3(25.5f, -0.49f, z));
			M = TransBobRoad3 * SPebble3;
			glUniformMatrix4fv(progPebbles->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			sphere->draw(progPebbles, FALSE);
		}
		for (int z = 7; z < 20; z += 2) {
			glm::mat4 TransBobRoad4 = glm::translate(glm::mat4(1.0f), glm::vec3(24.5f, -0.49f, z));
			M = TransBobRoad4 * SPebble4;
			glUniformMatrix4fv(progPebbles->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			sphere->draw(progPebbles, FALSE);
		}

		progPebbles->unbind();

		/*********************************************************************************************************************/
		//PATRICKS ROCK
		glm::mat4 SPatrickRock = glm::scale(glm::mat4(1.0f), glm::vec3(2.0f, 2.0f, 2.0f));
		glm::mat4 SPatrickRockBottom = glm::scale(glm::mat4(1.0f), glm::vec3(2.0f, 0.01f, 2.0f));

		progPRock->bind();
		glUniformMatrix4fv(progPRock->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPRock->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPRock->getUniform("campos"), 1, &mycam.pos[0]);

		if (moveRockUp == 1) {
			w += 0.05f;
			if (w > 1.2f) {
				w = 1.2f;
				moveRockUp = 0;
				movePatrickDown = 1;
			}
		}

		if (moveRockDown == 1) {
			w -= 0.05f;
			if (w < 0.0f) {
				w = 0.0f;
				moveRockDown = 0;
			}
		}

		glm::mat4 TransPRockO = glm::translate(glm::mat4(1.0f), glm::vec3(1.75f, 0.0f, 0.0f));
		glm::mat4 RotatePRock = glm::rotate(glm::mat4(1.0f), w, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 TransPRockI = glm::translate(glm::mat4(1.0f), glm::vec3(-1.75f, 0.0f, 0.0f));
		glm::mat4 TransPRock = glm::translate(glm::mat4(1.0f), glm::vec3(5.0f, -0.5f, 5.0f));
		glm::mat4 PRock = TransPRock * TransPRockI * RotatePRock * TransPRockO;
		M = PRock * SPatrickRock;
		glUniformMatrix4fv(progPRock->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPRock, FALSE);

		glm::mat4 TransPRockBottom = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.01f, 0.0f));
		glm::mat4 PRockBottom = PRock * TransPRockBottom;
		M = PRockBottom * SPatrickRockBottom;
		glUniformMatrix4fv(progPRock->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPRock, FALSE);

		progPRock->unbind();

		//Arrow
		glm::mat4 SPRArrow = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.3f, 0.05f));
		glm::mat4 SPRArrow2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.35f, 0.05f));
		glm::mat4 SPRArrow3 = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.2f, 0.05f));
		glm::mat4 SPRArrow4 = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.125f, 0.05f));

		progPRockA->bind();
		glUniformMatrix4fv(progPRockA->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPRockA->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPRockA->getUniform("campos"), 1, &mycam.pos[0]);

		
		glm::mat4 TransPRockArrow1 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 2.2f, 0.0f));
		glm::mat4 PRockArrow1 = PRock * TransPRockArrow1;
		M = PRockArrow1 * SPRArrow;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPRockA, FALSE);

		glm::mat4 TransPRockArrow2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.275f, 0.0f));
		glm::mat4 PRockArrow2 = PRockArrow1 * TransPRockArrow2 * RotateY * RotateX;
		M = PRockArrow2 * SPRArrow2;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPRockA, FALSE);
		
		glm::mat4 TransPRockArrow3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.15f, 0.0f));
		glm::mat4 PRockArrow3 = PRockArrow2 * TransPRockArrow3 * RotateY * RotateX;
		M = PRockArrow3 * SPRArrow3;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPRockA, FALSE);

		glm::mat4 TransPRockArrow4 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.3f, 0.0f));
		glm::mat4 PRockArrow4 = PRockArrow2 * TransPRockArrow4 * RotateY * RotateX;
		M = PRockArrow4 * SPRArrow3;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPRockA, FALSE);
		
		glm::mat4 TransPRockArrow5 = glm::translate(glm::mat4(1.0f), glm::vec3(0.1f, -0.225f, 0.0f));
		glm::mat4 RotateX2 = glm::rotate(glm::mat4(1.0f), angle2, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 PRockArrow5 = PRockArrow2 * TransPRockArrow5 * RotateY * RotateX2;
		M = PRockArrow5 * SPRArrow4;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPRockA, FALSE);

		glm::mat4 TransPRockArrow6 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.1f, -0.225f, 0.0f));
		glm::mat4 RotateX3 = glm::rotate(glm::mat4(1.0f), -angle2, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 PRockArrow6 = PRockArrow2 * TransPRockArrow6 * RotateY * RotateX3;
		M = PRockArrow6 * SPRArrow4;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPRockA, FALSE);

		glm::mat4 SKKSign = glm::scale(glm::mat4(1.0f), glm::vec3(0.1f, 7.5f, 0.1f));
		glm::mat4 TransKKSign = glm::translate(glm::mat4(1.0f), glm::vec3(35.0f, 0.0f, -20.0f));
		glm::mat4 KKSign = TransKKSign;
		M = KKSign * SKKSign;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPRockA, FALSE);

		progPRockA->unbind();

		/*********************************************************************************************************************/
		//SQUIDWARDS HOUSE
		glm::mat4 SSHouse = glm::scale(glm::mat4(1.0f), glm::vec3(5.0f, 10.0f, 5.0f));
		glm::mat4 SSHouseTop = glm::scale(glm::mat4(1.0f), glm::vec3(1.425f, 0.01f, 1.39f));
		glm::mat4 SSHouseBrow = glm::scale(glm::mat4(1.0f), glm::vec3(1.25f, 0.25f, 0.2f));
		glm::mat4 SSHouseEar = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 1.15f, 0.3f));

		progSHouse->bind();
		glUniformMatrix4fv(progSHouse->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSHouse->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSHouse->getUniform("campos"), 1, &mycam.pos[0]);

		
		glm::mat4 TransSHouse = glm::translate(glm::mat4(1.0f), glm::vec3(15.0f, 6.5f, 5.0f));
		glm::mat4 SHouse = TransSHouse;
		M = SHouse * SSHouse;
		glUniformMatrix4fv(progSHouse->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progSHouse, FALSE);

		glm::mat4 TransSHouseTop = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.525f, 0.0f));
		glm::mat4 SHouseTop = SHouse * TransSHouseTop;
		M = SHouseTop * SSHouseTop;
		glUniformMatrix4fv(progSHouse->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSHouse, FALSE);
		
		glm::mat4 TransSHouseBrow = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -2.25f, 1.65f));
		glm::mat4 SHouseBrow = SHouse * TransSHouseBrow;
		M = SHouseBrow * SSHouseBrow;
		glUniformMatrix4fv(progSHouse->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progSHouse, FALSE);
		
		glm::mat4 TransSHouseLEar = glm::translate(glm::mat4(1.0f), glm::vec3(1.65f, -3.5f, 0.0f));
		glm::mat4 SHouseLEar = SHouse * TransSHouseLEar;
		M = SHouseLEar * SSHouseEar;
		glUniformMatrix4fv(progSHouse->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progSHouse, FALSE);

		glm::mat4 TransSHouseREar = glm::translate(glm::mat4(1.0f), glm::vec3(-1.65f, -3.5f, 0.0f));
		glm::mat4 SHouseREar = SHouse * TransSHouseREar;
		M = SHouseREar * SSHouseEar;
		glUniformMatrix4fv(progSHouse->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progSHouse, FALSE);

		progSHouse->unbind();

		//Nose
		glm::mat4 SSHouseNose = glm::scale(glm::mat4(1.0f), glm::vec3(1.15f, 2.0f, 1.15f));

		progSHouseN->bind();
		glUniformMatrix4fv(progSHouseN->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSHouseN->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSHouseN->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 TransSHouseNose = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -3.0f, 1.65f));
		glm::mat4 SHouseNose = SHouse * TransSHouseNose;
		M = SHouseNose * SSHouseNose;
		glUniformMatrix4fv(progSHouseN->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progSHouseN, FALSE);

		progSHouseN->unbind();

		//Door + Front Steps
		glm::mat4 SSHouseDoor = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 1.25f, 0.325f));
		glm::mat4 SSHouseFSteps = glm::scale(glm::mat4(1.0f), glm::vec3(0.75f, 0.3f, 0.35f));

		progSHouseD->bind();
		glUniformMatrix4fv(progSHouseD->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSHouseD->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSHouseD->getUniform("campos"), 1, &mycam.pos[0]);


		glm::mat4 TransSHouseDoor = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -6.65f, 2.0f));
		glm::mat4 SHouseDoor = SHouse * TransSHouseDoor;
		M = SHouseDoor * SSHouseDoor;
		glUniformMatrix4fv(progSHouseD->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSHouseD, FALSE);

		for (float z = 19.5; z > 7; z -= 1.5) {
			glm::mat4 TransSteps = glm::translate(glm::mat4(1.0f), glm::vec3(15.0f, -0.775f, z));
			M = TransSteps * SSHouseFSteps;
			glUniformMatrix4fv(progSHouseD->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			cube->draw(progSHouseD, FALSE);
		}

		progSHouseD->unbind();

		//Window
		glm::mat4 SWindow = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 0.5f, 0.1f));
		glm::mat4 SWindowGlass = glm::scale(glm::mat4(1.0f), glm::vec3(0.35f, 0.35f, 0.05f));

		progSHouseW->bind();
		glUniformMatrix4fv(progSHouseW->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSHouseW->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSHouseW->getUniform("campos"), 1, &mycam.pos[0]);


		glm::mat4 TransWindow = glm::translate(glm::mat4(1.0f), glm::vec3(0.75f, -3.0f, 1.65f));
		glm::mat4 Window = SHouse * TransWindow;
		M = Window * SWindow;
		glUniformMatrix4fv(progSHouseW->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSHouseW, FALSE);

		glm::mat4 TransWindow2 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.75f, -3.0f, 1.65f));
		glm::mat4 Window2 = SHouse * TransWindow2;
		M = Window2 * SWindow;
		glUniformMatrix4fv(progSHouseW->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSHouseW, FALSE);

		progSHouseW->unbind();

		progWGlass->bind();
		glUniformMatrix4fv(progWGlass->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progWGlass->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progWGlass->getUniform("campos"), 1, &mycam.pos[0]);


		glm::mat4 WindowGlass = Window;
		M = WindowGlass * SWindowGlass;
		glUniformMatrix4fv(progWGlass->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progWGlass, FALSE);

		glm::mat4 WindowGlass2 = Window2;
		M = WindowGlass2 * SWindowGlass;
		glUniformMatrix4fv(progWGlass->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progWGlass, FALSE);

		progWGlass->unbind();

		/*********************************************************************************************************************/
		//PINEAPPLE
		glm::mat4 SSBHouse = glm::scale(glm::mat4(1.0f), glm::vec3(2.0f, 3.0f, 2.0f));

		progPine->bind();
		glUniformMatrix4fv(progPine->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPine->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPine->getUniform("campos"), 1, &mycam.pos[0]);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture2);
		
		glm::mat4 TransSBHouse = glm::translate(glm::mat4(1.0f), glm::vec3(25.0f, 0.75f, 5.0f));
		glm::mat4 SBHouse = TransSBHouse;
		M = SBHouse * SSBHouse * RotateX;
		glUniformMatrix4fv(progPine->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPine, FALSE);

		progPine->unbind();

		//Leaf
		glm::mat4 SSBHouseLeaf = glm::scale(glm::mat4(1.0f), glm::vec3(1.75f, 1.75f, 0.75f));
		glm::mat4 SSBHouseLeaf2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.75f, 1.75f, 1.75f));
		glm::mat4 SSBHouseLeaf3 = glm::scale(glm::mat4(1.0f), glm::vec3(2.0f, 1.75f, 2.0f));

		progLeaf->bind();
		glUniformMatrix4fv(progLeaf->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progLeaf->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progLeaf->getUniform("campos"), 1, &mycam.pos[0]);


		glm::mat4 RotateSBHouseLeaf = glm::rotate(glm::mat4(1.0f), 0.5f, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 TransSBHouseLeaf = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 3.0f, 0.75f));
		glm::mat4 SBHouseLeaf = SBHouse * TransSBHouseLeaf * RotateSBHouseLeaf;
		M = SBHouseLeaf * SSBHouseLeaf;
		glUniformMatrix4fv(progLeaf->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progLeaf, FALSE);

		glm::mat4 RotateSBHouseLeaf2 = glm::rotate(glm::mat4(1.0f), 0.5f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 TransSBHouseLeaf2 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.75f, 3.0f, 0.0f));
		glm::mat4 SBHouseLeaf2 = SBHouse * TransSBHouseLeaf2 * RotateSBHouseLeaf2;
		M = SBHouseLeaf2 * SSBHouseLeaf2;
		glUniformMatrix4fv(progLeaf->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progLeaf, FALSE);

		glm::mat4 RotateSBHouseLeaf3 = glm::rotate(glm::mat4(1.0f), -0.5f, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 TransSBHouseLeaf3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 3.0f, -0.75f));
		glm::mat4 SBHouseLeaf3 = SBHouse * TransSBHouseLeaf3 * RotateSBHouseLeaf3;
		M = SBHouseLeaf3 * SSBHouseLeaf;
		glUniformMatrix4fv(progLeaf->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progLeaf, FALSE);

		glm::mat4 RotateSBHouseLeaf4 = glm::rotate(glm::mat4(1.0f), -0.5f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 TransSBHouseLeaf4 = glm::translate(glm::mat4(1.0f), glm::vec3(0.75f, 3.0f, 0.0f));
		glm::mat4 SBHouseLeaf4 = SBHouse * TransSBHouseLeaf4 * RotateSBHouseLeaf4;
		M = SBHouseLeaf4 * SSBHouseLeaf2;
		glUniformMatrix4fv(progLeaf->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progLeaf, FALSE);

		glm::mat4 TransSBHouseLeaf5 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 3.25f, 0.0f));
		glm::mat4 SBHouseLeaf5 = SBHouse * TransSBHouseLeaf5;
		M = SBHouseLeaf5 * SSBHouseLeaf3;
		glUniformMatrix4fv(progLeaf->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progLeaf, FALSE);

		progLeaf->unbind();

		//Door
		glm::mat4 SSBHouseDoor = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 1.25f, 0.2f));
		glm::mat4 SSBHouseDoorHandle = glm::scale(glm::mat4(1.0f), glm::vec3(0.075f, 0.075f, 0.05f));
		
		progPineD->bind();
		glUniformMatrix4fv(progPineD->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPineD->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPineD->getUniform("campos"), 1, &mycam.pos[0]);
		
		glm::mat4 TransSBHouseDoor = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -1.0f, 1.95f));
		glm::mat4 SBHouseDoor = SBHouse * TransSBHouseDoor;
		M = SBHouseDoor * SSBHouseDoor;
		glUniformMatrix4fv(progPineD->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineD, FALSE);

		glm::mat4 SSBHouseCylThing = glm::scale(glm::mat4(1.0f), glm::vec3(0.125f, 0.35f, 0.125f));
		glm::mat4 TransSBHouseCylThing = glm::translate(glm::mat4(1.0f), glm::vec3(2.0f, 1.5f, 0.0f));
		glm::mat4 SBHouseCylThing = SBHouse * TransSBHouseCylThing * RotateY * RotateX;
		M = SBHouseCylThing * SSBHouseCylThing;
		glUniformMatrix4fv(progPineD->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPineD, FALSE);

		glm::mat4 SSBHouseCylThing2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.165f, 0.35f, 0.165f));
		glm::mat4 TransSBHouseCylThing2 = glm::translate(glm::mat4(1.0f), glm::vec3(2.25f, 1.675f, 0.0f));
		glm::mat4 SBHouseCylThing2 = SBHouse * TransSBHouseCylThing2;
		M = SBHouseCylThing2 * SSBHouseCylThing2;
		glUniformMatrix4fv(progPineD->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPineD, FALSE);

		progPineD->unbind();

		progPineDP->bind();
		glUniformMatrix4fv(progPineDP->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPineDP->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPineDP->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 TransSBHouseDoorH1 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.3f, 0.2f));
		glm::mat4 SBHouseDoorH1 = SBHouseDoor * TransSBHouseDoorH1;
		M = SBHouseDoorH1 * SSBHouseDoorHandle;
		glUniformMatrix4fv(progPineDP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineDP, FALSE);

		glm::mat4 TransSBHouseDoorH2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.575f, 0.2f));
		glm::mat4 SBHouseDoorH2 = SBHouseDoor * TransSBHouseDoorH2;
		M = SBHouseDoorH2 * SSBHouseDoorHandle;
		glUniformMatrix4fv(progPineDP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineDP, FALSE);

		glm::mat4 TransSBHouseDoorH3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.25f, 0.425f, 0.2f));
		glm::mat4 SBHouseDoorH3 = SBHouseDoor * TransSBHouseDoorH3;
		M = SBHouseDoorH3 * SSBHouseDoorHandle;
		glUniformMatrix4fv(progPineDP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineDP, FALSE);

		glm::mat4 TransSBHouseDoorH4 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.25f, 0.425f, 0.2f));
		glm::mat4 SBHouseDoorH4 = SBHouseDoor * TransSBHouseDoorH4;
		M = SBHouseDoorH4 * SSBHouseDoorHandle;
		glUniformMatrix4fv(progPineDP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineDP, FALSE);

		glm::mat4 TransSBHouseDoorH5 = glm::translate(glm::mat4(1.0f), glm::vec3(0.2f, 0.1f, 0.2f));
		glm::mat4 SBHouseDoorH5 = SBHouseDoor * TransSBHouseDoorH5;
		M = SBHouseDoorH5 * SSBHouseDoorHandle;
		glUniformMatrix4fv(progPineDP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineDP, FALSE);

		glm::mat4 TransSBHouseDoorH6 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.2f, 0.1f, 0.2f));
		glm::mat4 SBHouseDoorH6 = SBHouseDoor * TransSBHouseDoorH6;
		M = SBHouseDoorH6 * SSBHouseDoorHandle;
		glUniformMatrix4fv(progPineDP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineDP, FALSE);

		progPineDP->unbind();

		//Window
		glm::mat4 SWindow2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.4f, 0.4f, 0.1f));
		glm::mat4 SDoorFront = glm::scale(glm::mat4(1.0f), glm::vec3(0.3f, 0.3f, 0.1f));
		glm::mat4 SWindowGlass2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.35f, 0.35f, 0.05f));

		progPineW->bind();
		glUniformMatrix4fv(progPineW->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPineW->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPineW->getUniform("campos"), 1, &mycam.pos[0]);

		
		glm::mat4 TransWindow3 = glm::translate(glm::mat4(1.0f), glm::vec3(1.0f, -0.1f, 1.875f));
		glm::mat4 Window3 = SBHouse * TransWindow3;
		M = Window3 * SWindow2;
		glUniformMatrix4fv(progPineW->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineW, FALSE);

		glm::mat4 TransWindow4 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.725f, 0.65f, 1.9f));
		glm::mat4 Window4 = SBHouse * TransWindow4;
		M = Window4 * SWindow2;
		glUniformMatrix4fv(progPineW->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineW, FALSE);

		glm::mat4 TransDoorFront = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.3f, 0.15f));
		glm::mat4 DoorFront = SBHouseDoor * TransDoorFront;
		M = DoorFront * SDoorFront;
		glUniformMatrix4fv(progPineW->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPineW, FALSE);

		progPineW->unbind();

		progWGlass->bind();
		glUniformMatrix4fv(progWGlass->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progWGlass->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progWGlass->getUniform("campos"), 1, &mycam.pos[0]);


		glm::mat4 WindowGlass3 = Window3;
		M = WindowGlass3 * SWindowGlass2;
		glUniformMatrix4fv(progWGlass->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progWGlass, FALSE);

		glm::mat4 WindowGlass4 = Window4;
		M = WindowGlass4 * SWindowGlass2;
		glUniformMatrix4fv(progWGlass->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progWGlass, FALSE);

		progWGlass->unbind();

		/*********************************************************************************************************************/
		//SQUIDWARD
		progSquidS->bind();
		glUniformMatrix4fv(progSquidS->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSquidS->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSquidS->getUniform("campos"), 1, &mycam.pos[0]);


		//Body
		glm::mat4 SSQBody = glm::scale(glm::mat4(1.0f), glm::vec3(0.16f, 0.3f, 0.125f));
		glm::mat4 SSQNeck = glm::scale(glm::mat4(1.0f), glm::vec3(0.04f, 0.15f, 0.04f));
		
		glm::mat4 TransSQBody = glm::translate(glm::mat4(1.0f), glm::vec3(16.0f, 0.3f, 8.0f));
		glm::mat4 SQBody = TransSQBody;
		M = SQBody * SSQBody;
		glUniformMatrix4fv(progSquidS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquidS, FALSE);

		progSquidS->unbind();

		progSquid->bind();
		glUniformMatrix4fv(progSquid->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSquid->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSquid->getUniform("campos"), 1, &mycam.pos[0]);
		

		glm::mat4 TransSQNeck = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.45f, 0.0f));
		glm::mat4 SQNeck = SQBody * TransSQNeck;
		M = SQNeck * SSQNeck;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);

		//Face
		glm::mat4 SSQHead = glm::scale(glm::mat4(1.0f), glm::vec3(0.1f, 0.125f, 0.1f));
		glm::mat4 SSQFHead = glm::scale(glm::mat4(1.0f), glm::vec3(0.225f, 0.15f, 0.15f));
		glm::mat4 SSQMouth = glm::scale(glm::mat4(1.0f), glm::vec3(0.175f, 0.04f, 0.125f));
		glm::mat4 SSQNose = glm::scale(glm::mat4(1.0f), glm::vec3(0.04f, 0.08f, 0.035f));

		glm::mat4 TransSQHead = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.15f, 0.0f));
		glm::mat4 SQHead = SQNeck * TransSQHead;
		M = SQHead * SSQHead;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);

		glm::mat4 TransSQFHead = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.15f, 0.0f));
		glm::mat4 SQFHead = SQHead * TransSQFHead;
		M = SQFHead * SSQFHead;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		glm::mat4 RotateSQNose = glm::rotate(glm::mat4(1.0f), -0.225f, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 TransSQNose = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.1f, 0.125f));
		glm::mat4 SQNose = SQHead * TransSQNose * RotateSQNose;
		M = SQNose * SSQNose;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		//Arms
		glm::mat4 SSQArm = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.25f, 0.05f));
		glm::mat4 SSQHand = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.125f, 0.05f));

		glm::mat4 TransSQLArm = glm::translate(glm::mat4(1.0f), glm::vec3(-0.2f, 0.0f, 0.0f));
		glm::mat4 SQLArm = SQBody * TransSQLArm;
		M = SQLArm * SSQArm;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);

		glm::mat4 TransSQLHand = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.275f, 0.0f));
		glm::mat4 SQLHand = SQLArm * TransSQLHand;
		M = SQLHand * SSQHand;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		glm::mat4 TransSQRArm = glm::translate(glm::mat4(1.0f), glm::vec3(0.2f, 0.0f, 0.0f));
		glm::mat4 SQRArm = SQBody * TransSQRArm;
		M = SQRArm * SSQArm;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);

		glm::mat4 TransSQRHand = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.275f, 0.0f));
		glm::mat4 SQRHand = SQRArm * TransSQRHand;
		M = SQRHand * SSQHand;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		//Legs
		glm::mat4 SSQLeg = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.25f, 0.05f));
		glm::mat4 SSQFoot = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.05f, 0.125f));
		glm::mat4 SSQFoot2 = glm::scale(glm::mat4(1.0f), glm::vec3(0.125f, 0.05f, 0.05f));

		glm::mat4 TransSQLeg = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.525f, 0.055f));
		glm::mat4 SQLeg = SQBody * TransSQLeg;
		M = SQLeg * SSQLeg;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);
		
		glm::mat4 TransSQFoot = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.25f, 0.075f));
		glm::mat4 SQFoot = SQLeg * TransSQFoot;
		M = SQFoot * SSQFoot;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		glm::mat4 TransSQLeg2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.525f, -0.055f));
		glm::mat4 SQLeg2 = SQBody * TransSQLeg2;
		M = SQLeg2 * SSQLeg;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);

		glm::mat4 TransSQFoot2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.25f, -0.075f));
		glm::mat4 SQFoot2 = SQLeg2 * TransSQFoot2;
		M = SQFoot2 * SSQFoot;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		glm::mat4 TransSQLeg3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.1f, -0.525f, 0.0f));
		glm::mat4 SQLeg3 = SQBody * TransSQLeg3;
		M = SQLeg3 * SSQLeg;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);

		glm::mat4 TransSQFoot3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.075f, -0.25f, 0.0f));
		glm::mat4 SQFoot3 = SQLeg3 * TransSQFoot3;
		M = SQFoot3 * SSQFoot2;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		glm::mat4 TransSQLeg4 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.1f, -0.525f, 0.0f));
		glm::mat4 SQLeg4 = SQBody * TransSQLeg4;
		M = SQLeg4 * SSQLeg;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progSquid, FALSE);

		glm::mat4 TransSQFoot4 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.075f, -0.25f, 0.0f));
		glm::mat4 SQFoot4 = SQLeg4 * TransSQFoot4;
		M = SQFoot4 * SSQFoot2;
		glUniformMatrix4fv(progSquid->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquid, FALSE);

		progSquid->unbind();

		progSquidM->bind();
		glUniformMatrix4fv(progSquidM->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSquidM->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSquidM->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 TransSQMouth = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.125f, 0.0f));
		glm::mat4 SQMouth = SQHead * TransSQMouth;
		M = SQMouth * SSQMouth;
		glUniformMatrix4fv(progSquidM->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquidM, FALSE);

		progSquidM->unbind();

		progSquidE->bind();
		glUniformMatrix4fv(progSquidE->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progSquidE->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progSquidE->getUniform("campos"), 1, &mycam.pos[0]);

		//Eyes
		glm::mat4 SSQEye = glm::scale(glm::mat4(1.0f), glm::vec3(0.06f, 0.0775f, 0.05f));
		
		glm::mat4 TransSQLEye = glm::translate(glm::mat4(1.0f), glm::vec3(-0.05f, 0.0f, 0.125f));
		glm::mat4 SQLEye = SQHead * TransSQLEye;
		M = SQLEye * SSQEye;
		glUniformMatrix4fv(progSquidE->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquidE, FALSE);

		glm::mat4 TransSQREye = glm::translate(glm::mat4(1.0f), glm::vec3(0.05f, 0.0f, 0.125f));
		glm::mat4 SQREye = SQHead * TransSQREye;
		M = SQREye * SSQEye;
		glUniformMatrix4fv(progSquidE->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progSquidE, FALSE);

		progSquidE->unbind();

		/*********************************************************************************************************************/
		//PATRICK

		progPatS->bind();
		glUniformMatrix4fv(progPatS->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPatS->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPatS->getUniform("campos"), 1, &mycam.pos[0]);

		if (movePatrickDown == 1) {
			movePatrick.y -= 0.25f;
			ww += 0.05f;
			if (ww > 0.35f) {
				ww = 0.35f;
			}
			if (movePatrick.y < -2.70f) {
				movePatrick.y = -2.70f;
				movePatrickDown = 0;
			}
		}

		if (movePatrickUp == 1) {
			movePatrick.y += 0.25f;
			ww -= 0.05f;
			if (ww < 0) {
				ww = 0;
			}
			if (movePatrick.y > 0.0f) {
				movePatrick.y = 0.0f;
				movePatrickUp = 0;
				moveRockDown = 1;
			}
		}

		//Body
		glm::mat4 SPBody = glm::scale(glm::mat4(1.0f), glm::vec3(0.365f, 0.3f, 0.3f));
		
		glm::mat4 TransPBody = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.1f, 0.0f));
		glm::mat4 MovePBody = glm::translate(glm::mat4(1.0f), movePatrick);
		glm::mat4 RotateP = glm::rotate(glm::mat4(1.0f), ww, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 PBody = PRock * MovePBody * TransPBody * RotateP * RotateNY * RotateNX;
		M = PBody * SPBody;
		glUniformMatrix4fv(progPatS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPatS, FALSE);

		progPatS->unbind();

		progPatF->bind();
		glUniformMatrix4fv(progPatF->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPatF->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPatF->getUniform("campos"), 1, &mycam.pos[0]);


		//Head
		glm::mat4 SPHead = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 0.5f, 0.55f));
		glm::mat4 SPHeadTip = glm::scale(glm::mat4(1.0f), glm::vec3(0.065f, 0.2f, 0.065f));
		
		glm::mat4 TransPHead = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.6f, 0.0f));
		glm::mat4 PHead = PBody * TransPHead;
		M = PHead * SPHead;
		glUniformMatrix4fv(progPatF->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progPatF, FALSE);

		progPatF->unbind();

		progPat->bind();
		glUniformMatrix4fv(progPat->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPat->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPat->getUniform("campos"), 1, &mycam.pos[0]);


		glm::mat4 RotatePHeadTip = glm::rotate(glm::mat4(1.0f), -0.175f, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 TransPHeadTip = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.319f, 0.0f));
		glm::mat4 PHeadTip = PHead * TransPHeadTip * RotatePHeadTip;
		M = PHeadTip * SPHeadTip;
		glUniformMatrix4fv(progPat->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPat, FALSE);

		//Arms
		glm::mat4 SPArm = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 0.5f, 0.45f));
		glm::mat4 SPHand = glm::scale(glm::mat4(1.0f), glm::vec3(0.075f, 0.2f, 0.05f));

		glm::mat4 RotatePLArm = glm::rotate(glm::mat4(1.0f), 1.3f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 TransPLArm = glm::translate(glm::mat4(1.0f), glm::vec3(-0.3f, 0.1f, 0.0f));
		glm::mat4 PLArm = PBody * TransPLArm * RotatePLArm;
		M = PLArm * SPArm;
		glUniformMatrix4fv(progPat->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progPat, FALSE);
		
		glm::mat4 TransPLHand = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.3f, 0.0f));
		glm::mat4 PLHand = PLArm * TransPLHand;
		M = PLHand * SPHand;
		glUniformMatrix4fv(progPat->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPat, FALSE);

		glm::mat4 RotatePRArm = glm::rotate(glm::mat4(1.0f), -1.3f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 TransPRArm = glm::translate(glm::mat4(1.0f), glm::vec3(0.3f, 0.1f, 0.0f));
		glm::mat4 PRArm = PBody * TransPRArm * RotatePRArm;
		M = PRArm * SPArm;
		glUniformMatrix4fv(progPat->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cone->draw(progPat, FALSE);

		glm::mat4 TransPRHand = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.3f, 0.0f));
		glm::mat4 PRHand = PRArm * TransPRHand;
		M = PRHand * SPHand;
		glUniformMatrix4fv(progPat->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPat, FALSE);

		progPat->unbind();

		progPatL->bind();
		glUniformMatrix4fv(progPatL->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPatL->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPatL->getUniform("campos"), 1, &mycam.pos[0]);


		//Legs
		glm::mat4 SPLeg = glm::scale(glm::mat4(1.0f), glm::vec3(0.125f, 0.3f, 0.125f));
		
		glm::mat4 RotatePLLeg = glm::rotate(glm::mat4(1.0f), -0.2f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 TransPLLeg = glm::translate(glm::mat4(1.0f), glm::vec3(-0.15f, -0.35f, 0.0f));
		glm::mat4 PLLeg = PBody * TransPLLeg * RotatePLLeg;
		M = PLLeg * SPLeg;
		glUniformMatrix4fv(progPatL->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPatL, FALSE);

		glm::mat4 RotatePRLeg = glm::rotate(glm::mat4(1.0f), 0.2f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 TransPRLeg = glm::translate(glm::mat4(1.0f), glm::vec3(0.15f, -0.35f, 0.0f));
		glm::mat4 PRLeg = PBody * TransPRLeg * RotatePRLeg;
		M = PRLeg * SPLeg;
		glUniformMatrix4fv(progPatL->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPatL, FALSE);

		progPatL->unbind();

		progPatE->bind();
		glUniformMatrix4fv(progPatE->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPatE->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPatE->getUniform("campos"), 1, &mycam.pos[0]);


		//Eyes
		glm::mat4 SPEye = glm::scale(glm::mat4(1.0f), glm::vec3(0.06f, 0.0775f, 0.05f));
		
		glm::mat4 TransPLEye = glm::translate(glm::mat4(1.0f), glm::vec3(-0.065f, -0.1f, 0.17f));
		glm::mat4 PLEye = PHead * TransPLEye;
		M = PLEye * SPEye;
		glUniformMatrix4fv(progPatE->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPatE, FALSE);

		glm::mat4 TransPREye = glm::translate(glm::mat4(1.0f), glm::vec3(0.065f, -0.1f, 0.17f));
		glm::mat4 PREye = PHead * TransPREye;
		M = PREye * SPEye;
		glUniformMatrix4fv(progPatE->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progPatE, FALSE);

		progPatE->unbind();

		/*********************************************************************************************************************/
		//JELLYFISH FIELDS
		progJellyFields->bind();
		glUniformMatrix4fv(progJellyFields->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progJellyFields->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progJellyFields->getUniform("campos"), 1, &mycam.pos[0]);
		glBindVertexArray(VertexArrayID);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, HeightTexture);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, Texture6);
		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D, Texture7);

		glm::mat4 TransY = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f));
		M = TransY;
		glUniformMatrix4fv(progJellyFields->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glDrawElements(GL_TRIANGLES, MESHSIZE*MESHSIZE * 6, GL_UNSIGNED_SHORT, (void*)0);

		progJellyFields->unbind();
	
		/*********************************************************************************************************************/
		//Spongebob (imported from Project 2B)
		glm::mat4 SBody = glm::scale(glm::mat4(1.0f), glm::vec3(0.4f, 0.5f, 0.2f));
		glm::mat4 SNose = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.12f, 0.05f));
		glm::mat4 SArm = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.175f, 0.05f));
		glm::mat4 SPant = glm::scale(glm::mat4(1.0f), glm::vec3(0.1f, 0.05f, 0.1f));
		glm::mat4 SLeg = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.175f, 0.05f));
		glm::mat4 SEye = glm::scale(glm::mat4(1.0f), glm::vec3(0.1f, 0.1f, 0.1f));
		glm::mat4 SNoseTip = glm::scale(glm::mat4(1.0f), glm::vec3(0.053f, 0.055f, 0.053f));
		glm::mat4 SHand = glm::scale(glm::mat4(1.0f), glm::vec3(0.085f, 0.085f, 0.085f));
		glm::mat4 SShoe = glm::scale(glm::mat4(1.0f), glm::vec3(0.085f, 0.085f, 0.2f));
		glm::mat4 SEyeLash = glm::scale(glm::mat4(1.0f), glm::vec3(0.01f, 0.035f, 0.01f));
		glm::mat4 SShoeBottom = glm::scale(glm::mat4(1.0f), glm::vec3(0.075f, 0.0675f, 0.06f));
		glm::mat4 SCheek = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.05f, 0.05f));

		/**********************************************BODY***************************************************************/
		//body
		progBob->bind();
		glUniformMatrix4fv(progBob->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progBob->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progBob->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 TransBody = glm::translate(glm::mat4(1.0f), glm::vec3(8.0f, 0.475f, 5.0f));
		glm::mat4 Body = TransBody * RotateY;

		M = Body * SBody;
		glUniformMatrix4fv(prog->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progBob, FALSE);

		progBob->unbind();

		/**********************************************UPPER ARM**********************************************************/
		progUA->bind();
		glUniformMatrix4fv(progUA->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progUA->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progUA->getUniform("campos"), 1, &mycam.pos[0]);

		//left upper arm
		glm::mat4 TransLUArm = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 TransLUArm2 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.4f, -0.1f, 0.0f));
		glm::mat4 RotateLUArm = glm::rotate(glm::mat4(1.0f), 1.8f, glm::vec3(1.0f, 0.0f, 1.0f));
		glm::mat4 LUArm = Body * TransLUArm2 * RotateLUArm * TransLUArm;

		M = LUArm * SArm;
		glUniformMatrix4fv(progUA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progUA, FALSE);

		//right upper arm
		glm::mat4 TransRUArm = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 TransRUArm2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.4f, -0.1f, 0.0f));
		glm::mat4 RotateRUArm = glm::rotate(glm::mat4(1.0f), angle, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 RUArm = Body * TransRUArm2 * RotateRUArm * TransRUArm;

		M = RUArm * SArm;
		glUniformMatrix4fv(progUA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progUA, FALSE);

		progUA->unbind();

		/************************************NOSE AND LOWER ARM AND HAND**************************************************/

		progNA->bind();
		glUniformMatrix4fv(progNA->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progNA->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progNA->getUniform("campos"), 1, &mycam.pos[0]);

		//nose
		glm::mat4 TransNose = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.1f, 0.3f));
		glm::mat4 RotateNose = glm::rotate(glm::mat4(1.0f), 1.57f, glm::vec3(1.0f, 0.0f, 0.0f));
		glm::mat4 Nose = Body * TransNose * RotateNose;

		M = Nose * SNose;
		glUniformMatrix4fv(progNA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progNA, FALSE);

		//left lower arm
		glm::mat4 TransLLArm = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 TransLLArm2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 RotateLlArm = glm::rotate(glm::mat4(1.0f), -1.2f, glm::vec3(-1.0f, 0.0f, 1.0f));
		glm::mat4 LLArm = LUArm * TransLLArm2 * RotateLlArm * TransLLArm;

		M = LLArm * SArm;
		glUniformMatrix4fv(progNA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progNA, FALSE);

		//right lower arm
		glm::mat4 TransRLArm = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 TransRLArm2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 RotateRLArm = glm::rotate(glm::mat4(1.0f), 1.8f, glm::vec3(1.0f, 0.0f, 1.0f));
		glm::mat4 RLArm = RUArm * TransRLArm2 * RotateRLArm * TransRLArm;

		M = RLArm * SArm;
		glUniformMatrix4fv(progNA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progNA, FALSE);

		progNA->unbind();

		progNT->bind();
		glUniformMatrix4fv(progNT->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progNT->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progNT->getUniform("campos"), 1, &mycam.pos[0]);

		//nose tip
		glm::mat4 TransNoseTip = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.1f, 0.0f));
		glm::mat4 NoseTip = Nose * TransNoseTip;

		M = NoseTip * SNoseTip;
		glUniformMatrix4fv(progNT->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progNT, FALSE);

		progNT->unbind();

		progNAsphere->bind();
		glUniformMatrix4fv(progNAsphere->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progNAsphere->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progNAsphere->getUniform("campos"), 1, &mycam.pos[0]);

		//left elbow
		glm::mat4 TransLElbow = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 LElbow = LUArm * TransLElbow;

		M = LElbow * SNoseTip;
		glUniformMatrix4fv(progNAsphere->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progNAsphere, FALSE);

		//right elbow
		glm::mat4 TransRElbow = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 RElbow = RUArm * TransRElbow;

		M = RElbow * SNoseTip;
		glUniformMatrix4fv(progNAsphere->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progNAsphere, FALSE);

		//left hand
		glm::mat4 TransLHand = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 LHand = LLArm * TransLHand;

		M = LHand * SHand;
		glUniformMatrix4fv(progNAsphere->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progNAsphere, FALSE);

		//right hand
		glm::mat4 TransRHand = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.18f, 0.0f));
		glm::mat4 RHand = RLArm * TransRHand;

		M = RHand * SHand;
		glUniformMatrix4fv(progNAsphere->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progNAsphere, FALSE);

		progNAsphere->unbind();

		/**********************************************CHEEKS*************************************************************/

		progC->bind();
		glUniformMatrix4fv(progC->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progC->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progC->getUniform("campos"), 1, &mycam.pos[0]);

		//left cheek
		glm::mat4 TransLCheek = glm::translate(glm::mat4(1.0f), glm::vec3(-0.2f, 0.02f, 0.18f));
		glm::mat4 LCheek = Body * TransLCheek;

		M = LCheek * SCheek;
		glUniformMatrix4fv(progC->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progC, FALSE);

		//right cheek
		glm::mat4 TransRCheek = glm::translate(glm::mat4(1.0f), glm::vec3(0.2f, 0.02f, 0.18f));
		glm::mat4 RCheek = Body * TransRCheek;

		M = RCheek * SCheek;
		glUniformMatrix4fv(progC->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progC, FALSE);

		progC->unbind();

		/**********************************************PANT***************************************************************/

		progP->bind();
		glUniformMatrix4fv(progP->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progP->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progP->getUniform("campos"), 1, &mycam.pos[0]);

		//left pant
		glm::mat4 TransLPant = glm::translate(glm::mat4(1.0f), glm::vec3(-0.2f, -0.5f, 0.0f));
		glm::mat4 LPant = Body * TransLPant;

		M = LPant * SPant;
		glUniformMatrix4fv(progP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progP, FALSE);

		//right pant
		glm::mat4 TransRPant = glm::translate(glm::mat4(1.0f), glm::vec3(0.2f, -0.5f, 0.0f));
		glm::mat4 RPant = Body * TransRPant;

		M = RPant * SPant;
		glUniformMatrix4fv(progP->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progP, FALSE);

		progP->unbind();

		/**********************************************LEG****************************************************************/

		progL->bind();
		glUniformMatrix4fv(progL->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progL->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progL->getUniform("campos"), 1, &mycam.pos[0]);

		//left leg
		glm::mat4 TransLLeg = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.2f, 0.0f));
		glm::mat4 LLeg = LPant * TransLLeg;

		M = LLeg * SLeg;
		glUniformMatrix4fv(progL->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progL, FALSE);

		//right leg
		glm::mat4 TransRLeg = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.2f, 0.0f));
		glm::mat4 RLeg = RPant * TransRLeg;

		M = RLeg * SLeg;
		glUniformMatrix4fv(progL->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progL, FALSE);

		progL->unbind();

		/**********************************************EYE****************************************************************/

		progE->bind();
		glUniformMatrix4fv(progE->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progE->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progE->getUniform("campos"), 1, &mycam.pos[0]);

		//left eye
		glm::mat4 TransLEye = glm::translate(glm::mat4(1.0f), glm::vec3(-0.15f, 0.25f, 0.2f));
		glm::mat4 LEye = Body * TransLEye;

		M = LEye * SEye;
		glUniformMatrix4fv(progE->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progE, FALSE);

		//right eye
		glm::mat4 TransREye = glm::translate(glm::mat4(1.0f), glm::vec3(0.15f, 0.25f, 0.2f));
		glm::mat4 REye = Body * TransREye;

		M = REye * SEye;
		glUniformMatrix4fv(progE->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progE, FALSE);

		progE->unbind();

		/*******************************************SHOE AND EYELASH******************************************************/

		progS->bind();
		glUniformMatrix4fv(progS->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progS->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progS->getUniform("campos"), 1, &mycam.pos[0]);

		//left shoe
		glm::mat4 TransLShoe = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.25f, 0.05f));
		glm::mat4 LShoe = LLeg * TransLShoe;

		M = LShoe * SShoe;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progS, FALSE);

		//left shoe bottom
		glm::mat4 TransLShoeBottom = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.25f, 0.0f));
		glm::mat4 RotateLShoeBottom = glm::rotate(glm::mat4(1.0f), 3.14f, glm::vec3(0.0f, 1.0f, 0.0f));
		glm::mat4 LShoeBottom = LLeg * TransLShoeBottom * RotateLShoeBottom;

		M = LShoeBottom * SShoeBottom;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		//right shoe
		glm::mat4 TransRShoe = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.25f, 0.05f));
		glm::mat4 RShoe = RLeg * TransRShoe;

		M = RShoe * SShoe;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progS, FALSE);

		//right shoe bottom
		glm::mat4 TransRShoeBottom = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.25f, 0.0f));
		glm::mat4 RotateRShoeBottom = glm::rotate(glm::mat4(1.0f), 3.14f, glm::vec3(0.0f, 1.0f, 0.0f));
		glm::mat4 RShoeBottom = RLeg * TransRShoeBottom * RotateRShoeBottom;

		M = RShoeBottom * SShoeBottom;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		//eyelash 1
		glm::mat4 TransEL1 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.1f, 0.0f));
		glm::mat4 EL1 = LEye * TransEL1;

		M = EL1 * SEyeLash;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		//eyelash 2
		glm::mat4 TransEL2 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.05f, 0.08f, 0.0f));
		glm::mat4 RotateEL2 = glm::rotate(glm::mat4(1.0f), 0.5f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 EL2 = LEye * TransEL2 * RotateEL2;

		M = EL2 * SEyeLash;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		//eyelash 3
		glm::mat4 TransEL3 = glm::translate(glm::mat4(1.0f), glm::vec3(0.05f, 0.08f, 0.0f));
		glm::mat4 RotateEL3 = glm::rotate(glm::mat4(1.0f), -0.5f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 EL3 = LEye * TransEL3 * RotateEL3;

		M = EL3 * SEyeLash;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		//eyelash 4
		glm::mat4 TransEL4 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.1f, 0.0f));
		glm::mat4 EL4 = REye * TransEL1;

		M = EL4 * SEyeLash;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		//eyelash 5
		glm::mat4 TransEL5 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.05f, 0.08f, 0.0F));
		glm::mat4 RotateEL5 = glm::rotate(glm::mat4(1.0f), 0.5f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 EL5 = REye * TransEL5 * RotateEL5;

		M = EL5 * SEyeLash;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		//eyelash 6
		glm::mat4 TransEL6 = glm::translate(glm::mat4(1.0f), glm::vec3(0.05f, 0.08f, 0.0F));
		glm::mat4 RotateEL6 = glm::rotate(glm::mat4(1.0f), -0.5f, glm::vec3(0.0f, 0.0f, 1.0f));
		glm::mat4 EL6 = REye * TransEL6 * RotateEL6;

		M = EL6 * SEyeLash;
		glUniformMatrix4fv(progS->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progS, FALSE);

		progS->unbind();

		//JellyFishing Rods
		progStick->bind();
		glUniformMatrix4fv(progStick->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progStick->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progStick->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SStick = glm::scale(glm::mat4(1.0f), glm::vec3(0.05f, 0.25f, 0.05f));
		glm::mat4 TransStick = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -0.2f));
		glm::mat4 Stick = LHand * TransStick * RotateX * RotateNY;
		M = Stick * SStick;
		glUniformMatrix4fv(progStick->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progStick, FALSE);

		glm::mat4 TransStick2 = glm::translate(glm::mat4(1.0f), glm::vec3(-0.2f, 0.1f, 0.0f));
		glm::mat4 Stick2 = PRHand * TransStick2 * RotateNY * RotateX;
		M = Stick2 * SStick;
		glUniformMatrix4fv(progStick->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progStick, FALSE);

		progStick->unbind();
		
		progLoop->bind();
		glUniformMatrix4fv(progLoop->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progLoop->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progLoop->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SStickLoop = glm::scale(glm::mat4(1.0f), glm::vec3(0.2f, 0.2f, 0.2f));
		glm::mat4 TransStickLoop = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.425f, 0.0f));
		glm::mat4 StickLoop = Stick * TransStickLoop;
		M = StickLoop * SStickLoop;
		glUniformMatrix4fv(progLoop->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progLoop, FALSE);

		glm::mat4 TransStickLoop2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.425f, 0.0f));
		glm::mat4 StickLoop2 = Stick2 * TransStickLoop2;
		M = StickLoop2 * SStickLoop;
		glUniformMatrix4fv(progLoop->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progLoop, FALSE);

		progLoop->unbind();

		progNet->bind();
		glUniformMatrix4fv(progNet->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progNet->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progNet->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SStickNet = glm::scale(glm::mat4(1.0f), glm::vec3(0.35f, 0.195f, 0.195f));
		glm::mat4 TransStickNet = glm::translate(glm::mat4(1.0f), glm::vec3(0.05f, 0.0f, 0.0f));
		glm::mat4 StickNet = StickLoop * TransStickNet;
		M = StickNet * SStickNet;
		glUniformMatrix4fv(progLoop->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progLoop, FALSE);

		glm::mat4 TransStickNet2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.05f, 0.0f, 0.0f));
		glm::mat4 StickNet2 = StickLoop2 * TransStickNet2;
		M = StickNet2 * SStickNet;
		glUniformMatrix4fv(progLoop->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(progLoop, FALSE);

		progNet->unbind();

		/*********************************************************************************************************************/
		//KRUSTY KRAB
		progKK->bind();
		glUniformMatrix4fv(progKK->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progKK->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progKK->getUniform("campos"), 1, &mycam.pos[0]);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture9);

		glm::mat4 SKKrab = glm::scale(glm::mat4(1.0f), glm::vec3(6.0f, 5.0f, 5.0f));
		glm::mat4 TransKKrab = glm::translate(glm::mat4(1.0f), glm::vec3(45.0f, 2.0f, -30.0f));
		glm::mat4 KKrab =  TransKKrab;
		M = KKrab * SKKrab * RotateY * RotateX;
		glUniformMatrix4fv(progKK->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progKK, FALSE);

		progKK->unbind();

		progKKC->bind();
		glUniformMatrix4fv(progKKC->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progKKC->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progKKC->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SKKrabC = glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 5.5f, 5.5f));
		glm::mat4 TransKKrabLC = glm::translate(glm::mat4(1.0f), glm::vec3(-6.0f, 0.0f, 0.0f));
		glm::mat4 KKrabLC = KKrab * TransKKrabLC;
		M = KKrabLC * SKKrabC * RotateY * RotateX;
		glUniformMatrix4fv(progKKC->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progKKC, FALSE);
		
		glm::mat4 TransKKrabRC = glm::translate(glm::mat4(1.0f), glm::vec3(6.0f, 0.0f, 0.0f));
		glm::mat4 KKrabRC = KKrab * TransKKrabRC;
		M = KKrabRC * SKKrabC * RotateY * RotateX;
		glUniformMatrix4fv(progKKC->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progKKC, FALSE);

		progKKC->unbind();

		progKKB->bind();
		glUniformMatrix4fv(progKKB->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progKKB->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progKKB->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SKKrabBorder = glm::scale(glm::mat4(1.0f), glm::vec3(7.0f, 1.0f, 5.5f));
		glm::mat4 TransKKrabBorder = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -2.5f, 0.0f));
		glm::mat4 KKrabBorder = KKrab * TransKKrabBorder;
		M = KKrabBorder * SKKrabBorder;
		glUniformMatrix4fv(progKKB->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progKKB, FALSE);

		progKKB->unbind();

		progKKDB->bind();
		glUniformMatrix4fv(progKKDB->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progKKDB->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progKKDB->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SKKrabDBorder = glm::scale(glm::mat4(1.0f), glm::vec3(1.8f, 4.0f, 0.5f));
		glm::mat4 TransKKrabDBorder = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -2.5f, 5.0f));
		glm::mat4 KKrabDBorder = KKrab * TransKKrabDBorder;
		M = KKrabDBorder * SKKrabDBorder;
		glUniformMatrix4fv(progKKDB->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progKKDB, FALSE);

		progKKDB->unbind();

		progKKGlass->bind();
		glUniformMatrix4fv(progKKGlass->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progKKGlass->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progKKGlass->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SKKrabGlass = glm::scale(glm::mat4(1.0f), glm::vec3(6.25f, 2.0f, 4.85f));
		glm::mat4 TransKKrabGlass = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, -0.9f, 0.16f));
		glm::mat4 KKrabGlass = KKrab * TransKKrabGlass;
		M = KKrabGlass * SKKrabGlass;
		glUniformMatrix4fv(progKKGlass->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progKKGlass, FALSE);

		progKKGlass->unbind();

		progNA->bind();
		glUniformMatrix4fv(progNA->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progNA->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progNA->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SKKrabGlassD = glm::scale(glm::mat4(1.0f), glm::vec3(0.225f, 0.4f, 0.1f));
		glm::mat4 TransKKrabGlassLD = glm::translate(glm::mat4(1.0f), glm::vec3(-0.325f, 0.0f, 4.85f));
		glm::mat4 KKrabGlassLD = KKrabGlass * TransKKrabGlassLD;
		M = KKrabGlassLD * SKKrabGlassD;
		glUniformMatrix4fv(progNA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progNA, FALSE);

		glm::mat4 TransKKrabGlassRD = glm::translate(glm::mat4(1.0f), glm::vec3(0.325f, 0.0f, 4.85f));
		glm::mat4 KKrabGlassRD = KKrabGlass * TransKKrabGlassRD;
		M = KKrabGlassRD * SKKrabGlassD;
		glUniformMatrix4fv(progNA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cube->draw(progNA, FALSE);

		progNA->unbind();

		progPineD->bind();
		glUniformMatrix4fv(progPineD->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progPineD->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progPineD->getUniform("campos"), 1, &mycam.pos[0]);
		
		glm::mat4 SKKCylThing = glm::scale(glm::mat4(1.0f), glm::vec3(0.8f, 1.25f, 0.8f));
		glm::mat4 TransKKCylThing = glm::translate(glm::mat4(1.0f), glm::vec3(-2.25f, 4.9f, 0.0f));
		glm::mat4 KKCylThing = KKrab * TransKKCylThing;
		M = KKCylThing * SKKCylThing;
		glUniformMatrix4fv(progPineD->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		cylinder->draw(progPineD, FALSE);

		progPineD->unbind();

		prog->bind();
		glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(prog->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(prog->getUniform("campos"), 1, &mycam.pos[0]);

		glm::mat4 SKKClam1 = glm::scale(glm::mat4(1.0f), glm::vec3(1.25f, 1.5f, 0.5f));
		glm::mat4 TransClam1 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 7.5f, 0.0f));
		glm::mat4 Clam1 = KKSign * TransClam1;
		M = Clam1 * SKKClam1;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(prog, FALSE);

		glm::mat4 SKKClam2 = glm::scale(glm::mat4(1.0f), glm::vec3(1.25f, 0.5f, 1.5f));
		glm::mat4 TransClam2 = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 6.25f, 1.0f));
		glm::mat4 Clam2 = KKSign * TransClam2;
		M = Clam2 * SKKClam2;
		glUniformMatrix4fv(progPRockA->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		sphere->draw(prog, FALSE);

		prog->unbind();

		progJelly->bind();
		glm::vec2 off;
		float animationtime = totaltime * 5;
		int ianimationtime = (int)animationtime;
		off.x = ianimationtime % 3;
		off.y = (ianimationtime / 3) % 3;
		glUniformMatrix4fv(progJelly->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(progJelly->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniform3fv(progJelly->getUniform("campos"), 1, &mycam.pos[0]);
		glUniform2fv(progJelly->getUniform("offset"), 1, &off[0]);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture8);

		glBindVertexArray(VertexArrayIDSquare);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDSquare);

		glm::mat4 Vi = glm::transpose(V);
		Vi[0][3] = 0;
		Vi[1][3] = 0;
		Vi[2][3] = 0;

		glm::mat4 SJelly = glm::scale(glm::mat4(1.0f), glm::vec3(1.0f, 1.0f, 0.0f));
		for (float x = 57.5; x > 0; x -= 15) {
			for (float z = 75; z > 25; z -= 25) {
				glm::mat4 TransJelly = glm::translate(glm::mat4(1.0f), glm::vec3(x, sin(x + z)+0.1, z));
				M = TransJelly * Vi * SJelly;
				glUniformMatrix4fv(progJelly->getUniform("M"), 1, GL_FALSE, &M[0][0]);
				glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);
			}
		}

		for (float x = 50.0; x > 0; x -= 15) {
			for (float z = 81.25; z > 25; z -= 25) {
				glm::mat4 TransJelly = glm::translate(glm::mat4(1.0f), glm::vec3(x, cos(x + z)+0.25, z));
				M = TransJelly * Vi * SJelly;
				glUniformMatrix4fv(progJelly->getUniform("M"), 1, GL_FALSE, &M[0][0]);
				glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);
			}
		}

		glBindVertexArray(0);

		progJelly->unbind();

		glBindFramebuffer(GL_FRAMEBUFFER, 0);
		glBindTexture(GL_TEXTURE_2D, FBOtex);
		glGenerateMipmap(GL_TEXTURE_2D);

	}

};
//******************************************************************************************
int main(int argc, char **argv)
{
	std::string resourceDir = "../resources"; // Where the resources are loaded from
	if (argc >= 2)
	{
		resourceDir = argv[1];
	}

	Application *application = new Application();

	/* your main will always include a similar set up to establish your window
		and GL context, etc. */
	WindowManager * windowManager = new WindowManager();
	windowManager->init(1920, 1080);
	windowManager->setEventCallbacks(application);
	application->windowManager = windowManager;

	/* This is the code that will likely change program to program as you
		may need to initialize or set up different data and state */
	// Initialize scene.
	application->init(resourceDir);
	application->initGeom();

	// Loop until the user closes the window.
	while(! glfwWindowShouldClose(windowManager->getHandle()))
	{
		// Render scene.
		application->render_to_framebuffer();
		application->render();

		// Swap front and back buffers.
		glfwSwapBuffers(windowManager->getHandle());
		// Poll for and process events.
		glfwPollEvents();
	}

	// Quit program.
	windowManager->shutdown();
	return 0;
}
