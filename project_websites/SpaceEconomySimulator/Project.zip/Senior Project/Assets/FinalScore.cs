﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FinalScore : MonoBehaviour {


	public Text finalScore;
	// Use this for initialization
	void Start () {
		finalScore.text = "Score" + (GameHandler.timePassed + GameHandler.maxMoneyOwned);
	}

}
