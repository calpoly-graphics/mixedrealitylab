﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour {

	private int speed = 20;
	private Vector3 savedPosition = new Vector3(0 , 0, -15);

	public void savePosition(Vector3 pos) {
		savedPosition.x = pos.x;
		savedPosition.y = pos.y; 
	}

	void Update() {
		if (Input.GetKey(KeyCode.D)) {
			transform.Translate(new Vector3(speed * Time.deltaTime, 0, 0));
		}
		if (Input.GetKey(KeyCode.A)) {
			transform.Translate(new Vector3(-speed * Time.deltaTime, 0, 0));
		}
		if (Input.GetKey(KeyCode.S)) {
			transform.Translate(new Vector3(0, -speed * Time.deltaTime, 0));
		}
		if (Input.GetKey(KeyCode.W)) {
			transform.Translate(new Vector3(0, speed * Time.deltaTime, 0));
		}
		if (Input.GetKey(KeyCode.Space)) {
			transform.position = savedPosition;
		}
	}
}