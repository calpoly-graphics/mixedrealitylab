﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpgradeOption : MonoBehaviour {
   
   UIHandler uihandler;
   Upgrade upgrade;
   public Text upgradeName;
   public Text upgradeDesc;
   public Button btn;

   public void Initialize(UIHandler uihandler, Upgrade upgrade,string upgradeName,string upgradeDesc){
      this.uihandler = uihandler;
      this.upgrade = upgrade;
      this.upgradeName.text = upgradeName;
      this.upgradeDesc.text = upgradeDesc;
   }

   void Start()
    {
        btn.onClick.AddListener(TaskOnClick);
    }

    void TaskOnClick()
    {
        uihandler.handleUpgradeRequest(upgrade);
         DestroyObject(gameObject);
    }
}
