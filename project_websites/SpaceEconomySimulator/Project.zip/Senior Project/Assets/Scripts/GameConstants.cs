﻿using System.Collections;
using System.Collections.Generic;

public class GameConstants {
   public static Dictionary <Planet.Tier,int> tierToWealth = new Dictionary<Planet.Tier, int>()
   {
      {Planet.Tier.Poor, 1000},
      {Planet.Tier.Developing, 3000},
      {Planet.Tier.Prospering, 5000}
   };
}
