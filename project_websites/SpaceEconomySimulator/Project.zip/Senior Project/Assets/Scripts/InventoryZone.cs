﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class InventoryZone : MonoBehaviour, IDropHandler {

   Stats owner;

   public void setOwner(Stats owner) {
      this.owner = owner;
   }

   public Stats getOwner() {
      return owner;
   }

   public void OnDrop(PointerEventData eventData) {
      DraggableItem dI = eventData.pointerDrag.GetComponent<DraggableItem>();
      Item i = dI.GetComponent<ItemGO>().getItem();
      if (dI) {
         dI.targetParent = this.transform;
         Debug.Log(i.itemName + " dragged to " + this.name);

      }
   }

   public void ResetInventory() {
      foreach (Transform child in transform) {
         GameObject.Destroy(child.gameObject);
      }
   }
}