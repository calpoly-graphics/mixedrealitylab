﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class PlanetGenerator : MonoBehaviour {
   private static int planetId = 0;
   public Sprite[] planetSprites = new Sprite[105];
   public List<Planet> planets = new List<Planet>();
   public List<PlanetGO> planetsGO = new List<PlanetGO>();
   public Dictionary<Planet, PlanetGO> planetsToGO = new Dictionary<Planet, PlanetGO>();
   public PlanetGO planetPrefab;

   public void loadPlanetSprites() {
      for(int i = 0; i < 105; i++) {
         planetSprites[i] = Resources.Load<Sprite>("Sprite/105 Colorful 2D Planet Icons/planet_"
            + (i + 1).ToString().PadLeft (3, '0'));
      }
   }

   public void enterStats() {
      foreach (Planet p in planets) {
         p.wealthOverTime.add(p.getWealth());
         foreach (Planet.History h in p.itemHistories) {
            h.add(h.getItem().getQuantity()); // Quantity or price?
         }
      }
   }

   void generatePlanet(string name, List<int> produced, List<int> consumed, int wealth, int x, int y) {

      PlanetGO pGO = Instantiate(planetPrefab, new Vector2(x, y), Quaternion.identity) as PlanetGO;

      pGO.transform.parent = this.transform;
      Planet p = new Planet(name, produced, consumed, wealth, planetId++);
      pGO.planet = p;
      pGO.GetComponentInChildren<SpriteRenderer>().sprite = planetSprites[p.id];
      Debug.Log("Generated planet: " + planetSprites[p.id].name);
      planetsToGO.Add(p, pGO);
      planets.Add(p);
      planetsGO.Add(pGO);
   }

   private string randomPlanetName() {
      string name = "";
      int rand = Random.Range(1, 4);
      for(int i = 0; i < rand; i++) {
         name += (char)('A' + Random.Range(0, 26));
      }
      rand = Random.Range(1, 1000);
      name += "-" + rand.ToString().PadLeft (3, '0');
      return name;
   }

   public void generatePlanets() {
      /* Format: 
       * Number of planets
       * Name NumProduced produced NumConsumed consumed wealth x y */
      string path = "Assets/Resources/Init/Planets.csv";
      int planets = 0;

      StreamReader reader = new StreamReader(path);

      planets = System.Int32.Parse(reader.ReadLine());

      for (int i = 0; i < planets; i++) {
         string[] line = reader.ReadLine().Split(',');
         string name = randomPlanetName();
         int produces, consumes, wealth, x, y;
         List<int> produceIds = new List<int>{ 0, 1, 2, 3, 4 };
         List<int> consumeIds = new List<int>{ 0, 1, 2, 3, 4 };

         // Planets can currently produce and consume same thing
         produces = Random.Range(1, 6);
         for (int j = 0; j < produces; j++) {
            produceIds.RemoveAt(Random.Range(0, produceIds.Count));
         }
         consumes = Random.Range(1, 6);
         for (int j = 0; j < produces; j++) {
            consumeIds.RemoveAt(Random.Range(0, consumeIds.Count));
         }
         
         wealth = Random.Range(1, 31) * 100; // Wealth from 100 - 3000
         x = System.Int32.Parse(line[0]);
         y = System.Int32.Parse(line[1]);

         generatePlanet(name, produceIds, consumeIds, wealth, x, y);
      }
   }

   public void produceConsumeAll() {
      foreach (Planet planet in this.planets) {
         planet.produceConsume();
      }
   }
}