﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameEvent
{
    public enum Affected { happiness, EnergyPrice, income, sensorRange, stationUpkeep, JumpRange };
    [System.Serializable]
    public class Choice{
        public string text;
        public Affected affected_variable;
        public int value;
    }

    public string title;

    [TextArea]
    public string desc;
    public Choice choice1;
    public Choice choice2;
    public delegate void HandlePlayerChoice(Choice choice);
    public HandlePlayerChoice onPlayerChoice;
}
