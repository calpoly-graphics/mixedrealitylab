﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class RouteGenerator : MonoBehaviour {

   public Route routePrefab;
   public GameHandler game;
   public List<Route> availableRoutes;
   public int[, ] adjMatrix;
   public int[, ] shortestPath;

   // Use this for initialization
   public void generateRoutes() {
      /* Format: 
       * Number of routes
       * Planets in route */
      string path = "Assets/Resources/Init/Routes.csv";
      int routes = 0;
      StreamReader reader = new StreamReader(path);
      Route route;

      routes = System.Int32.Parse(reader.ReadLine());

      availableRoutes = new List<Route>();

      for (int i = 0; i < routes; i++) {
         List<PlanetGO> connectedPlanets = new List<PlanetGO>();
         string[] line = reader.ReadLine().Split(',');

         route = Instantiate(routePrefab) as Route;
         route.transform.parent = this.transform;

         for (int j = 0; j < line.Length; j++) {
            int planetIndex = System.Int32.Parse(line[j]);
            connectedPlanets.Add(game.planetGen.planetsToGO[game.planetGen.planets[planetIndex]]);
         }

         route.Init(connectedPlanets);
         availableRoutes.Add(route);
      }
      generatePathing();
   }

   public void generatePathing() {
      int numPlanets = game.planetGen.planets.Count;
      adjMatrix = new int[numPlanets, numPlanets];
      shortestPath = new int[numPlanets, numPlanets];

      for(int i = 0; i < availableRoutes.Count; i++) {
         List<Planet> connectedPlanets = availableRoutes[i].getConnectedPlanets();
         for(int j = 0; j < connectedPlanets.Count; j++) {
            int cur = connectedPlanets[j].id;
            for(int k = 0; k < connectedPlanets.Count; k++) {
               adjMatrix[cur, connectedPlanets[k].id] = 1;
            }
         }
      }

      for(int i = 0; i < numPlanets; i++) {
         int[] curPaths = DijkstraAlgo(adjMatrix, i, numPlanets);
         for(int j = 0; j < numPlanets; j++) {
            shortestPath[i, j] = curPaths[j];
         }
      }
   }

   private static int MinimumDistance(int[] distance, bool[] shortestPathTreeSet, int verticesCount) {
      int min = int.MaxValue;
      int minIndex = 0;

      for (int v = 0; v < verticesCount; ++v) {
         if (shortestPathTreeSet[v] == false && distance[v] <= min) {
            min = distance[v];
            minIndex = v;
         }
      }

      return minIndex;
   }

   private static void Print(int[] distance, int verticesCount) {
      Debug.Log("Vertex Distance from source");

      for (int i = 0; i < verticesCount; ++i)
         Debug.Log("{" + i.ToString() + "}\t  {" + distance[i].ToString() + "}");
   }

   public static int[] DijkstraAlgo(int[, ] graph, int source, int verticesCount) {
      int[] distance = new int[verticesCount];
      bool[] shortestPathTreeSet = new bool[verticesCount];

      for (int i = 0; i < verticesCount; ++i) {
         distance[i] = int.MaxValue;
         shortestPathTreeSet[i] = false;
      }

      distance[source] = 0;

      for (int count = 0; count < verticesCount - 1; ++count) {
         int u = MinimumDistance(distance, shortestPathTreeSet, verticesCount);
         shortestPathTreeSet[u] = true;

         for (int v = 0; v < verticesCount; ++v)
            if (!shortestPathTreeSet[v] && 
               graph[u, v] != 0 && distance[u] != int.MaxValue &&
               distance[u] + graph[u, v] < distance[v])
               distance[v] = distance[u] + graph[u, v];
      }
      // Print(distance, verticesCount);
      return distance;
   }

   public List<Route> getAllConnectedRoutes(Planet planet) {
      List<Route> routes = new List<Route>();
      // Get routes with planet in it
      foreach (Route route in this.availableRoutes) {
         if (route.getConnectedPlanets().Contains(planet)) {
            routes.Add(route);
         }
      }

      return routes;
   }

   public List<Planet> getAllConnectedPlanets(Planet planet) {
      List<Planet> planets = new List<Planet>();
      List<Route> routes = getAllConnectedRoutes(planet);

      // Search routes for connected planetes
      foreach (Route route in routes) {
         foreach (Planet p in route.getConnectedPlanets()) {
            if (p != planet && !planets.Contains(p)) {
               planets.Add(p);
            }
         }
      }

      return planets;
   }
}
