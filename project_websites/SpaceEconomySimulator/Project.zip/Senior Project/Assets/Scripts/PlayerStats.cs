﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats : Stats {

   public enum upgradableStatus { stationUpkeep, fuel, sensorRange, dockSize, storageSize, income, jumpRange, happiness };
   List<Upgrade> appliedUpgrade;
   public Dictionary<upgradableStatus, int> currentUpgradableStatus;

   public PlayerStats() {
      currentUpgradableStatus = new Dictionary<upgradableStatus, int>();
      appliedUpgrade = new List<Upgrade>();
      this.money = 0;
      this.health = 10;
      this.itemsOwn = new List<Item>();
      initStatus();
   }

   public PlayerStats(int money, int health, List<Item> items) {
      currentUpgradableStatus = new Dictionary<upgradableStatus, int>();
      appliedUpgrade = new List<Upgrade>();
      initStatus();
      this.money = money;
      this.health = health;
      this.itemsOwn = items;
   }
   public void applyAllUpgrades() {
      foreach (Upgrade up in appliedUpgrade) {
         applyUpgrade(up);
      }
   }

   void applyUpgrade(Upgrade upgrade) {
      this.currentUpgradableStatus[upgrade.modifiedStatus] += upgrade.modifierValue;
   }

   public void applyEvent(GameEvent.Choice choice) {
      string affected = choice.affected_variable.ToString();
      upgradableStatus status = (upgradableStatus) System.Enum.Parse(typeof(upgradableStatus), affected);
      this.currentUpgradableStatus[status] += choice.value;
   }

   public void insertUpgrade(Upgrade upgrade) {
      Debug.Log(upgrade.upgradeName.ToString() + upgrade.cost);
      this.money -= upgrade.cost;
      appliedUpgrade.Add(upgrade);
      applyUpgrade(upgrade);
   }

   void initStatus() {
      currentUpgradableStatus.Add(upgradableStatus.stationUpkeep, 25);
      currentUpgradableStatus.Add(upgradableStatus.fuel, 100);
      currentUpgradableStatus.Add(upgradableStatus.sensorRange, 1);
      currentUpgradableStatus.Add(upgradableStatus.dockSize, 5);
      currentUpgradableStatus.Add(upgradableStatus.storageSize, 25);
      currentUpgradableStatus.Add(upgradableStatus.income, 0);
      currentUpgradableStatus.Add(upgradableStatus.jumpRange, 0);
      currentUpgradableStatus.Add(upgradableStatus.happiness, 1);
   }
}