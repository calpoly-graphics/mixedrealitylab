﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Statistic : MonoBehaviour {

	public Slider[] bars;
   public ItemInfo[] items;
   public Text statsName;
   public Text money;
   public Text maxScale;
   public Button toggle;
   int amount = 5;
   int offset = 0;
   Color[] set;
   bool displayItemToggle = false;
   int displayedItemID;

   void Start() {
      Button btn = toggle.GetComponent<Button>();
      btn.onClick.AddListener(switchDisplay);
      ItemInfo.selectClicked += switchItemDisplay;
   }

   void Awake() {
      set = new Color[5];
      for(int i =0 ; i < set.Length;i++){
         set[i] = UnityEngine.Random.ColorHSV();
      }
   }

   public void displayItems(Planet planet) {
      for(int i = 0; i < bars.Length;i++) {
         bars[i].maxValue = planet.getStorage()[i].getCapacity();
         bars[i].value = planet.getStorage()[i].getQuantity();
         bars[i].GetComponentInChildren<Image>().color = set[i];
      }
   }

   public void displayItem(Planet planet) {
      Planet.History display = planet.findItemHistory(this.displayedItemID);
      Color current = new Color();
      
      foreach(ItemInfo i in items) {
         if(i.getItem().itemID == this.displayedItemID) {
            current = i.select.GetComponent<Image>().color;
            break;
         }
      }

      if(display == null) {
         Debug.Log("Unknown item id"); // Should not get here
      }

      List<int> history = display.getLatest();

      Debug.Log(planet.name + " displaying " + display.getItem().getItemType().itemName + ": " + String.Join(", ", history.ConvertAll(i => i.ToString()).ToArray()));

      for(int i = 0; i < bars.Length;i++) {
         bars[i].maxValue = display.getItem().getCapacity();
         if(i < history.Count) {
            bars[i].value = history[i];
         }
         else {
            bars[i].value = 0;
         }
         bars[i].GetComponentInChildren<Image>().color = current;

         // if(bars[i].value == 0) {
         //    bars[i].GetComponent<Slider>(). = false;
         // }
         // else {
         //    bars[i].GetComponent<Slider>().enabled = true;            
         // }
      }

      maxScale.text = display.getItem().getCapacity().ToString();
   }

   public void displayMoney(Planet planet) {
      List<int> history = planet.wealthOverTime.getLatest();
      Color money = new Color((float)244/255, (float)223/255, (float)66/255);

      // Debug.Log(planet.name + " Latest " + String.Join(", ",
      //       history
      //       .ConvertAll(i => i.ToString())
      //       .ToArray()));

      for(int i = 0; i < bars.Length; i++) {
         bars[i].maxValue = planet.wealthOverTime.getMax();
         if(i < history.Count) {
            bars[i].value = history[i];
         }
         else {
            bars[i].value = 0;
         }
         bars[i].GetComponentInChildren<Image>().color = money;
      }

      maxScale.text = planet.wealthOverTime.getMax().ToString();
   }

   public void displayStats(Planet planet){

      //bars
      this.statsName.text = planet.name;
      this.money.text = planet.getWealth().ToString();

      if(this.displayItemToggle) {
         displayItem(planet);
      }
      else {
         displayMoney(planet);
      }

      // other
      List<int> consuming = planet.getConsumedId();
      List<int> producing = planet.getProducedId();


      for(int i = 0 ; i < items.Length; i++) {
         int netgain = 0;
         // TODO
         if(consuming.Contains(planet.getStorage()[i].getItemType().itemID)) netgain = -2;
         else if(producing.Contains(planet.getStorage()[i].getItemType().itemID)) netgain = +2;
         Sprite sprite = Resources.Load<Sprite>("Sprite/" + planet.getStorage()[i].getItemType().itemName);
         items[i].setInfo(planet, set[i], sprite, netgain, planet.getStorage()[i].getPrice(), planet.getStorage()[i].getItemType());
      }
   }

   public void switchDisplay() {
      this.displayItemToggle = !this.displayItemToggle;
   }

   public void switchItemDisplay(Item item, Planet planet) {
      Debug.Log("Comparing " + this.statsName.text + " with " + planet.name);
      if(this.statsName.text == planet.name) { // Ignore if button pressed isn't from right planet
         this.displayItemToggle = true;
         this.displayedItemID = item.itemID;
      }
   }
}
