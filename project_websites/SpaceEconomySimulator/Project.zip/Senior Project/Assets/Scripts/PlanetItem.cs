using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlanetItem {

	Item item;
   int quantity;
   int capacity;

   public PlanetItem(Item item, int quantity, int capacity) {
      this.item = item;
      this.quantity = quantity;
      this.capacity = capacity;
   }

	public void setItem(Item item){
		this.item = item;
	}

	public Item getItemType() {
		return this.item;
	}

   public int getQuantity() {
      return this.quantity;
   }

   // Add and subtract return actual number added/subtracted
   public int add(int num) {
      int actual = num;
      this.quantity += num;
      if(this.quantity > this.capacity) {
         actual = num - (this.capacity - this.quantity);
         this.quantity = this.capacity;
      }
      return actual;
   }

   public int subtract(int num) {
      int actual = num;
      this.quantity -= num;
      if(this.quantity < 0) {
         actual = num + this.quantity;
         this.quantity = 0;
      }
      return actual;
   }

   public int getCapacity() {
      return this.capacity;
   }

   public void setCapacity(int cap) {
      this.capacity = cap;
      if(this.quantity > this.capacity) {
         this.quantity = this.capacity;
      }
   }

   public override string ToString(){
      return item.itemName + " x" + quantity + "/" + capacity;
   }

   public int getPrice(){
      return (int)((item.basePrice * 2) - (((float)quantity / (float) capacity) * item.basePrice));
   }
}
