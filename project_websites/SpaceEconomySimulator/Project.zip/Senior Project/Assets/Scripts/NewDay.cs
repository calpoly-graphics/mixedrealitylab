﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class NewDay : MonoBehaviour, IPointerDownHandler {

   public delegate void OnDayClick();

   public static OnDayClick dayClicked;

   public void OnPointerDown(PointerEventData data) {
      Debug.Log("New Day");
      dayClicked();
      this.transform.parent.gameObject.SetActive(false);
   }
}
