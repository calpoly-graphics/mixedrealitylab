﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemGO : MonoBehaviour{

	Item itemStat;
   Stats owner;

	public void setItemStats(Item item){
		itemStat = item;
	}

	public Item getItem(){
		return itemStat;
	}

//   public void setOwner(Stats owner) {
//      this.owner = owner;
//   }
//
//   public Stats getOwner() {
//      return owner;
//   }
}
