﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ship : MonoBehaviour
{

    ShipGenerator shipGen;
    List<Vector3> path;
    int step = 0;
    Vector3 target;
    Stats npcStats;
    bool moving;
    bool docked = false;
    int offset = 0;

    public Ship(Stats stat, ShipGenerator sg)
    {
        this.shipGen = sg;
        this.npcStats = stat;
    }

    public bool isDocked()
    {
        return docked;
    }

    public void undocked()
    {
        docked = false;
        transform.SetParent(null);
    }

    public void setGen(ShipGenerator sg)
    {
        this.shipGen = sg;
    }

    public void setStats(Stats stat)
    {
        npcStats = stat;
    }

    public Stats getStats()
    {
        return npcStats;
    }

    public delegate void OnShipClick(Stats npcStats);
    public static OnShipClick shipClicked;

    void OnMouseDown()
    {
        if (!moving)
        {
            // Debug.Log("Pop Up");
            shipClicked(npcStats);
        }
    }

    public void StartMoving(List<Vector3> path)
    {
        this.step = 0;
        this.path = path;
        StartCoroutine(prepareToMove(path[step], 3));
    }

    public void StopMoving()
    {
        moving = false;
    }

    public void SetDock(int offset)
    {
        StopMoving();
        docked = true;
        transform.SetParent(shipGen.theGame.cameraController.transform);
        this.offset = offset;
    }

    public void arrivedAt(Planet planet)
    {
        if (npcStats.destination.Equals(planet))
        {
            StopMoving();
            shipGen.sellNPCItems(this);
            transform.gameObject.SetActive(false);
        }
    }

    void Update()
    {
        if (moving)
        {
            if (target.Equals(this.transform.position))
            {
                if (step + 1 != path.Count)
                {
                    step++;
                    StartCoroutine(prepareToMove(path[step], 0));
                }
            }
            this.transform.position = Vector3.MoveTowards(this.transform.position, target, 20f * Time.deltaTime);
        }
        if(docked) transform.position = transform.parent.position + new Vector3(10 + this.offset, -24, 1);
    }

    IEnumerator prepareToMove(Vector3 target, int delay)
    {
        int wait_time = Random.Range(0, delay);
        yield return new WaitForSeconds(wait_time);
        // Debug.Log("MOVE!");
        this.target = target;
        moving = true;
    }
}