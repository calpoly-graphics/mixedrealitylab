﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class GameHandler : MonoBehaviour {
   const int DAY_LEN = 20;
   public static int TIER_ONE_THRESHOLD = 5;

   public static int TAX = 25;

   [Header("All Important Object")]
   public PlayerStats playerStats;
   public Station station;
   public ShipGenerator shipGen;
   public PlanetGenerator planetGen;
   public RouteGenerator routeGen;
   public StatGenerator statGen;
   public LevelManager levelManager;
   public Upgrade upgradeManager;
   public CameraController cameraController;

   [Header("Inventories Zone")]
   public InventoryZone npcTrade;
   public InventoryZone playerTrade;
   [HideInInspector] public static int timePassed = 0;
   [HideInInspector] public static int maxMoneyOwned = 0;
   bool dayEnd = false;
   bool activeEndReport = false;
   float timeLeft = DAY_LEN;
   List<Vector3> moveLocs = new List<Vector3>();

   public static List<Item> globalItem = new List<Item>() {
      new Item(0, "Raw Materials", 10),
      new Item(1, "Tools", 20),
      new Item(2, "Energy", 20),
      new Item(3, "Data", 30),
      new Item(4, "Antiques", 50),
   };
   public GameObject itemGameObject;
   public UIHandler ui;

   public List<Upgrade> stationAvailableUpgrade;
   [Header("All events in the game")]
   public GameEvent[] gameEvents;

   public int getTime() {
      return (int) timeLeft;
   }

   void Start() {
      Ship.shipClicked += InitTradeScreen;
      Route.routeClicked += moveStation;
      NewDay.dayClicked += StartDay;
      playerStats = new PlayerStats(1000, 100, new List<Item>());
      // stationUpkeep,fuel,sensorRange, dockSize ,storageSize,income
      stationAvailableUpgrade = new List<Upgrade> {
         new Upgrade("Basic Solar Panel", "Will add a passive income", PlayerStats.upgradableStatus.income, 20, 100),
         // new Upgrade("Communication Station", "Display nearby planet info", PlayerStats.upgradableStatus.sensorRange, 10, 100),
         new Upgrade("Engine", "Jumps are cheaper", PlayerStats.upgradableStatus.jumpRange, 1, 100),
         new Upgrade("Crew Quarter", "Reduce Maintenance", PlayerStats.upgradableStatus.stationUpkeep, -10, 100),
         new Upgrade("Cafeteria", "Increase happiness", PlayerStats.upgradableStatus.happiness, 1, 400),
         new Upgrade("Solar Sail", "Add more passive income", PlayerStats.upgradableStatus.stationUpkeep, 50, 700),
      };

      planetGen.loadPlanetSprites();
      planetGen.generatePlanets();
      routeGen.generateRoutes();
      statGen.generateStats();
      setMoveLocations();

      station.move(routeGen.availableRoutes[Random.Range(0, routeGen.availableRoutes.Count)]);
      cameraController.transform.position = new Vector3(station.GetComponent<Transform>().position.x, station.GetComponent<Transform>().position.y, -15);
      playerStats.itemsOwn.Add(globalItem[2]);
      timePassed = 0;
      //   ui.DisplayInfo();
      StartDay();

   }

   void Update() {
      if (timeLeft > 0) {
         timeLeft -= Time.deltaTime;
         maxMoneyOwned = Mathf.Max(maxMoneyOwned, playerStats.money);
         timePassed++;
      } else {
         if (dayEnd && !activeEndReport) {
            showMovement();
            ui.closeAll();
            ui.ReportPopUp();

            if (playerStats.money <= 0) {
               levelManager.LoadLevel("End");
            }

            shipGen.sellDockedShips();
            shipGen.disableShips();
            planetGen.enterStats();
            activeEndReport = true;
            ui.SetUpgradePopUp();
            ui.UnsetDockPopUp();
            ui.SetEventPopUp();
         }
         if (!ui.isActiveTrade()) {
            dayEnd = true;
         }
      }
   }

   void CreateItemIcon(Item itemStats, InventoryZone inv, Stats owner) {
      GameObject newItem = Instantiate(itemGameObject) as GameObject;
      newItem.transform.SetParent(inv.transform);
      newItem.name = itemStats.itemName;

      // will take the Item GO set the item reference
      ItemGO newItemStats = newItem.GetComponent<ItemGO>();
      newItemStats.setItemStats(itemStats);
      Image i = newItem.GetComponent<Image>();
      i.sprite = Resources.Load<Sprite>("Sprite/" + newItem.name);
      Debug.Log(i.sprite);
   }

   void InitTradeScreen(Stats npcStats) {
      npcTrade.setOwner(npcStats);
      npcTrade.ResetInventory();
      playerTrade.ResetInventory();

      foreach (Item item in npcStats.itemsOwn) {
         CreateItemIcon(item, npcTrade, npcStats);
      }

      playerTrade.setOwner(playerStats);
      foreach (Item item in playerStats.itemsOwn) {
         CreateItemIcon(item, playerTrade, playerStats);
      }

      ui.TradePopUP();
   }

   void StartDay() {
      dayEnd = false;
      activeEndReport = false;
      timeLeft = DAY_LEN;
      planetGen.produceConsumeAll();
      shipGen.generateShips();
      shipGen.refreshNPCItems();
      station.offset = 0;
      station.moveToNextRoute(playerStats);

      hideMovement();
      ui.UnsetUpgradePopUp();
      ui.UnsetEventPopUp();
      ui.SetdockPopUp();
      ui.HideMinimize();

      cameraController.savePosition(station.GetComponent<Transform>().position);
   }

   void setMoveLocations() {
      Vector3 node;

      moveLocs.Clear();

      foreach (Route route in routeGen.GetComponentsInChildren<Route>()) {
         node = route.connectingNode;
         moveLocs.Add(node);
         route.GetComponentInChildren<SpriteRenderer>().transform.position = node;
      }
   }

   void showMovement() {
      foreach (Route route in routeGen.GetComponentsInChildren<Route>()) {
         route.GetComponentInChildren<SpriteRenderer>().enabled = true;
      }
   }

   void hideMovement() {
      foreach (Route route in routeGen.GetComponentsInChildren<Route>()) {
         route.GetComponentInChildren<SpriteRenderer>().enabled = false;
      }
   }

   void moveStation(Route route) {
      if (dayEnd) {
         Debug.Log("Attempting move");
         station.attemptMove(route, playerStats);
      }
   }

   public void applyHandleUpgradeRequest(Upgrade upgrade) {
      this.stationAvailableUpgrade.Remove(upgrade);
      this.playerStats.insertUpgrade(upgrade);
   }

   public GameEvent GetRandomEvent() {
      GameEvent gameEvent = gameEvents[Random.Range(0, gameEvents.Length)];
      gameEvent.onPlayerChoice = delegate(GameEvent.Choice choice) {
         if (choice.affected_variable == GameEvent.Affected.EnergyPrice) {
            globalItem[2].basePrice += 5;
         } else {
            playerStats.applyEvent(choice);
         }
      };

      return gameEvent;
   }

}