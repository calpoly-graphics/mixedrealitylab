﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StatGenerator : MonoBehaviour {
	public List<Statistic> planetStats = new List<Statistic>();
   public Statistic statPrefab;
   public GameHandler game;

	public void generateStats() {
		List<Planet> planets = game.planetGen.planets;
		Vector3 Offset = new Vector3(0, 100, 0);
		Statistic stats;

		foreach(Planet p in planets) {
			stats = Instantiate(statPrefab) as Statistic;
			stats.displayStats(p);
			stats.transform.parent = game.ui.transform.GetChild(0); // Index of statistics in Canvas
			stats.transform.position = game.ui.worldToUISpace(
				game.ui.transform.GetComponent<Canvas>(),
				game.planetGen.planetsToGO[p].transform.position) + Offset;
			planetStats.Add(stats);
		}
	}
}
