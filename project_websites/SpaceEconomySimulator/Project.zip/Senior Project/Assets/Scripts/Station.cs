﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Station : MonoBehaviour {
   public const int JUMP_COST = 10;
   public Route activeRoute;
   public Route nextRoute;
   public GameHandler game;
   public int offset = 0;
   
   private int getCost(Route src, Route dest) {
      int cost = System.Int32.MaxValue;
      foreach(Planet p in src.getConnectedPlanets()) {
         foreach(Planet q in dest.getConnectedPlanets()) {
            cost = Mathf.Min(game.routeGen.shortestPath[p.id, q.id], cost);
         }
      }
      return cost + 1 - game.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.jumpRange];
   }

   public void attemptMove(Route route, PlayerStats stats) {
      int cost = 0;
      if(route != activeRoute) {   
         cost = getCost(activeRoute, route);
      }
      if(stats.money > cost * JUMP_COST) {
         Debug.Log("Moving cost: " + (cost * JUMP_COST).ToString());
         previewMove(route);
      }
      else {
         Debug.Log("Unable to jump");
      }
   }

   public void moveToNextRoute(PlayerStats stats) {
      if(nextRoute) {
         stats.money -= getCost(activeRoute, nextRoute);
         move(nextRoute);
         nextRoute = null;
      }
      else {
         Debug.Log("Station did not move");
      }
   }

   public void previewMove(Route route) {
      nextRoute = route;
      this.transform.position = route.connectingNode;
   }

   public void move(Route route) {
      activeRoute = route;
      this.transform.position = route.connectingNode;
      Debug.Log("Station moved");
   }

   void OnTriggerEnter2D(Collider2D coll){
      Ship ship = coll.transform.GetComponent<Ship>();
      if(ship){
         ship.SetDock(offset);
         offset += 2;
      }
   }
}
