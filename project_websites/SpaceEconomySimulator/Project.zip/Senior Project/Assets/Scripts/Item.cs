﻿public class Item{

	public enum Grade{Common = 1, Uncommon = 2, Rare = 3};
	public enum Stage{Raw = 1, Processesed = 2, Goods = 4};


	public int itemID;
	public string itemName;
	public int basePrice;
	public int finalPrice;

   public Item(int id, string name, int baseP){
      this.itemID = id;
      this.itemName = name;
      this.basePrice = baseP;
      this.finalPrice = this.basePrice;
   }
}
