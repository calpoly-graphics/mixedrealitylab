﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;


public class PopupAble : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler  {

	public delegate void OnEnter(Item item);
	public delegate void OnExit();
	public static event OnEnter onItemEnter;
	public static event OnExit onItemExit;

	public void OnPointerEnter(PointerEventData eventData){
		//Debug.Log(GetComponent<ItemGO>().getItem().itemName);
		onItemEnter(GetComponent<ItemGO>().getItem());
	}

	public void OnPointerExit(PointerEventData eventData){
		//Debug.Log(GetComponent<ItemGO>().getItem().itemName);
		onItemExit();
	}
}
