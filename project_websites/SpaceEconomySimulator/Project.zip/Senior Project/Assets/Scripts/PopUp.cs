﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class PopUp : MonoBehaviour  {

	GameObject popUp;

	// Use this for initialization
	void Start () {
		popUp = this.gameObject;
		popUp.SetActive(false);
	}

}
