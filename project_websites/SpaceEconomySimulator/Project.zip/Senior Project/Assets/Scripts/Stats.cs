﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


// this should be class for npcs
[System.Serializable]
public class Stats {

   public Planet origin;
   public Planet destination;
	public int money;
	public int health;
	public List<Item> itemsOwn = new List<Item>();

   public Stats() {

   }
  
   public Stats(int money, int health, List<Item> items) {
      this.money = money;
      this.health = health;
      this.itemsOwn = items;
   }

   public void loadItem(List<Item> toLoad) {
      itemsOwn = toLoad;
   }

   public void addAmount(Item item, int amount) {
      for(int i = 0; i < amount; i++) {
         this.itemsOwn.Add(item);
      }
   }
}
