﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlanetGO : MonoBehaviour {

   public Planet planet;

   void OnTriggerEnter2D(Collider2D coll){

     Ship ship = coll.transform.GetComponent<Ship>();

         if(ship) ship.arrivedAt(planet);
   }
}
