﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHandler : MonoBehaviour
{

    public GameHandler theGame;
    public GameObject tradePopUp;
    public GameObject time;
    public GameObject itemPopUp;
    public GameObject reportPopUp;
    // public GameObject statisticPopUp; Do we need this?
    public GameObject upgradePopUp;
    public GameObject dockPopUp;
    public EventPopUp eventPopUp;
    public GameObject minimize;

    [Header("Item PopUP")]
    public Text itemText;
    public Text itemPrice;

    [Header("Trade PopUP")]
    public Text playerMoneyText;
    public Text npcMoney;
    public Text origin;
    public Text destination;

    //stationUpkeep,fuel,sensorRange, dockSize ,storageSize,income,jumpRange,happiness
    [Header("Report")]
    public Text dailyTax;
    Text timeText;
    public GameObject upgradeOptionPrefab;
    public Text upgradeText;
    public Text income;
    public Text upkeep;
    public Text sensorRange;
    public Text dockSize;
    public Text storageSize;
    public Text jumpRange;
    public Text happiness;

	public Text finalScore;
    


    bool activeTrade;
    int tax;

    void Start()
    {
        PopupAble.onItemEnter += ItemPopUp;
        PopupAble.onItemExit += ItemPopUpExit;
        DraggableItem.OnTrans += UpdateMoney;
        timeText = time.GetComponent<Text>();
        tradePopUp.SetActive(false);
        itemPopUp.SetActive(false);
        reportPopUp.SetActive(false);
        activeTrade = false;
        tax = 0;
    }

    public void UpdateMoney()
    {
        playerMoneyText.text = "MONEY:" + theGame.playerStats.money.ToString();
        npcMoney.text = "MONEY: " + theGame.npcTrade.getOwner().money.ToString();
    }

    public void SetdockPopUp()
    {
        this.dockPopUp.SetActive(true);
    }

    public void UnsetDockPopUp()
    {
        this.dockPopUp.SetActive(false);
    }

    public void SetEventPopUp()
    {
        this.eventPopUp.initialize(theGame.GetRandomEvent());
        this.eventPopUp.gameObject.SetActive(true);
    }

    public void UnsetEventPopUp()
    {
        this.eventPopUp.gameObject.SetActive(false);
    }

    public void SetUpgradePopUp()
    {
        int offset = 0;
        this.upgradePopUp.SetActive(true);
        Canvas parentCanvas = this.transform.GetComponent<Canvas>();

        foreach (Upgrade upgrade in theGame.stationAvailableUpgrade)
        {
            GameObject upgradeOptionGO = Instantiate(upgradeOptionPrefab, worldToUISpace(parentCanvas,
               new Vector3(0, 0, 0)),
               Quaternion.identity,
               this.upgradePopUp.gameObject.transform);
            //         RectTransform rt = upgradeOptionGO.GetComponent<RectTransform>();
            //         rt.localPosition =  new Vector3(0,offset,0);

            UpgradeOption upgradeOption = upgradeOptionGO.GetComponent<UpgradeOption>();
            upgradeOption.Initialize(this, upgrade, upgrade.upgradeName, upgrade.description);
            offset += 50;
        }

    }

    public void UnsetUpgradePopUp()
    {
        this.upgradePopUp.SetActive(false);
        foreach (Transform child in this.upgradePopUp.transform)
        {
            GameObject.Destroy(child.gameObject);
        }
    }

    public void HideMinimize(){
        minimize.SetActive(false);
    }

    public void TradePopUP()
    {
        UpdateMoney();
        origin.text = theGame.npcTrade.getOwner().origin.name;
        destination.text = theGame.npcTrade.getOwner().destination.name;

        activeTrade = true;
        tradePopUp.SetActive(true);
        Debug.Log(activeTrade);
    }

    // public void StatisticPopUp()
    // {
    //     statisticPopUp.SetActive(true);
    // }

    // public void StatisticPopDown()
    // {
    //     statisticPopUp.SetActive(false);
    // }


    public void TradeCloseUp()
    {
        tradePopUp.SetActive(false);
        activeTrade = false;
    }

    public void ReportPopUp()
    {
        reportPopUp.SetActive(true);
        minimize.SetActive(true);
        tax = GameHandler.TAX;
        theGame.playerStats.money -= tax;
        theGame.playerStats.money += theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.income];
        theGame.playerStats.money += theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.stationUpkeep];

    }

    public void togglePopUp()
    {

        reportPopUp.SetActive(!reportPopUp.activeSelf);
    }

    public void ItemPopUp(Item item)
    {
        itemText.text = item.itemName;
        itemPrice.text = item.basePrice.ToString();

        itemPopUp.SetActive(true);
    }

    public void ItemPopUpExit()
    {
        itemPopUp.SetActive(false);
    }

    public void closeAll()
    {

        tradePopUp.SetActive(false);
        itemPopUp.SetActive(false);
    }

    void Update()
    {

        timeText.text = "Time: " + theGame.getTime();
        dailyTax.text = "Taxed: $" + GameHandler.TAX + "\nMoney: $" + (theGame.playerStats.money + tax);
        income.text = "Passive Income: " + theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.income].ToString();
        upkeep.text = "Station Upkeep: " + theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.stationUpkeep].ToString();
        sensorRange.text = "Sensor Range: " + theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.sensorRange].ToString();
        dockSize.text = "Dock Size: "  + theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.dockSize].ToString();
        storageSize.text = "Storage Size: " + theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.storageSize].ToString();
        jumpRange.text = "Jump Range: " + theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.jumpRange].ToString();
        happiness.text = "Happiness: " + theGame.playerStats.currentUpgradableStatus[PlayerStats.upgradableStatus.happiness].ToString();
		finalScore.text = "Score: " + (GameHandler.maxMoneyOwned + GameHandler.timePassed);
		DisplayInfo();
    }

    public bool isActiveTrade()
    {
        return activeTrade;
    }

    public void DisplayInfo()
    {
        List<Statistic> stats = theGame.statGen.planetStats;
		Vector3 Offset = new Vector3(0, 100, 0);
        int i = 0;
		foreach(Statistic s in stats) {
            s.displayStats(theGame.planetGen.planets[i]);
			s.transform.position = worldToUISpace(
				theGame.ui.transform.GetComponent<Canvas>(),
				theGame.planetGen.planetsToGO[theGame.planetGen.planets[i++]].transform.position) + Offset;
		}
    }

    public Vector3 worldToUISpace(Canvas parentCanvas, Vector3 worldPos)
    {
        //Convert the world for screen point so that it can be used with ScreenPointToLocalPointInRectangle function
        Vector3 screenPos = Camera.main.WorldToScreenPoint(worldPos);
        Vector2 movePos;

        //Convert the screenpoint to ui rectangle local point
        RectTransformUtility.ScreenPointToLocalPointInRectangle(parentCanvas.transform as RectTransform, screenPos, parentCanvas.worldCamera, out movePos);
        //Convert the local point to world point
        return parentCanvas.transform.TransformPoint(movePos);
    }

    public void handleUpgradeRequest(Upgrade upgrade)
    {
        if (upgrade.cost <= theGame.playerStats.money)
        {
            theGame.applyHandleUpgradeRequest(upgrade);
        }
        else
        {
            Debug.Log("not enough money");
        }
    }
}

