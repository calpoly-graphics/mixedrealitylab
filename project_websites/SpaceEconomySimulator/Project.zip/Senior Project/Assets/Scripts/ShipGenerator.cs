﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipGenerator : MonoBehaviour {

   const int MAX_SHIPS = 200;
   int activeShips = 0;
   const float PRODUCER_FACTOR = 0.5f;
   const float CONSUMER_FACTOR = 1.5f;
   const float TRASH_FACTOR = 0.1f;
   const int BANKRUPT_THRESHOLD = 25;
   public GameHandler theGame;

   public GameObject shipPrefab;
   List<GameObject> shipGOs = new List<GameObject>();
   List<Stats> shipStats = new List<Stats>();
   Dictionary<Stats, GameObject> statsToGO = new Dictionary<Stats, GameObject>();

   bool instantiated = false;

   public void disableShips() {
      foreach (GameObject shipGO in shipGOs) {
         shipGO.SetActive(false);
      }
   }

   public void sellDockedShips() {
      foreach (GameObject shipGO in shipGOs) {
         Ship ship = shipGO.GetComponent<Ship>();
         if (ship.isDocked()) {
            sellNPCItems(ship);
            ship.undocked();
         }
      }
   }

   public void generateShips() {

      if (!instantiated) {
         for (int i = 0; i < MAX_SHIPS; i++) {
            GameObject newShipGO = Instantiate(shipPrefab) as GameObject;
            Ship newShip = newShipGO.GetComponent<Ship>();
            newShip.setGen(this);
            shipStats.Add(new Stats(100, 0, new List<Item>()));
            newShip.setStats(shipStats[i]);
            newShipGO.SetActive(false);
            shipGOs.Add(newShipGO);
            statsToGO.Add(shipStats[i], newShipGO);
         }
         instantiated = true;
      }
   }

   public void sellNPCItems(Ship ship) {
      Stats npcStats = ship.getStats();
      // tally up ship back to planets
      if (npcStats.destination != null) {
         foreach (Item item in npcStats.itemsOwn) {
            int sellPrice = npcStats.destination.dropItem(item);
            npcStats.money+= (int) (sellPrice * .90);
            npcStats.destination.changeWealth(-sellPrice);
         }
      }
      npcStats.origin.changeWealth(npcStats.money);
      npcStats.destination = null;
      npcStats.itemsOwn.Clear();

      activeShips--;
   }

   public void refreshNPCItems() {
      // Go by planets
      foreach (Planet planet in theGame.planetGen.planets) {
         //    List<Planet> destinations = theGame.routeGen.getAllConnectedPlanets(planet);
         List<Route> connectedRoutes = theGame.routeGen.getAllConnectedRoutes(planet);

         // Currently sending one ship per route's destinations??? should look for root
         foreach (Route route in connectedRoutes) {
            foreach (Planet dest in route.getConnectedPlanets()) {
               if (dest != planet) {
                  if (activeShips == MAX_SHIPS) {
                     return;
                  }
                  setupCurrentShip(planet, dest, route);
               }
            }
         }
      }
   }

   public int getShipCapacity(Planet.Tier tier) {
      if (tier == Planet.Tier.Poor) return 3;
      else if (tier == Planet.Tier.Developing) return 6;
      else return 9;
   }

   public void setupCurrentShip(Planet src, Planet dest, Route route) {
      Debug.Log("Setting up ship " + activeShips + " " + src.name + " -> " + dest.name);
      Stats currentStats = shipStats[activeShips];

      currentStats.origin = src;
      currentStats.destination = dest;


      Transform target = theGame.planetGen.planetsToGO[currentStats.destination].transform;
      GameObject GO = statsToGO[currentStats];

      GO.transform.position = theGame.planetGen.planetsToGO[currentStats.origin].transform.position;
      GO.GetComponentInChildren<SpriteRenderer>().color = Random.ColorHSV();
      GO.SetActive(true);
      Ship ship = GO.GetComponent<Ship>();
      ship.StartMoving(route.getPath(theGame.planetGen.planetsToGO[currentStats.destination]));

      currentStats.money = currentStats.origin.getInitialMoney();
      currentStats.origin.changeWealth(currentStats.origin.getInitialMoney() * -1);

      loadShip(currentStats);

      activeShips++;
   }

//   int SortByPrice(int a, int b) {
//      return GameHandler.globalItem[b].basePrice.CompareTo(GameHandler.globalItem[a].basePrice);
//   }

   public void loadShip(Stats stats) {
      int capacity = getShipCapacity(stats.origin.tier);

      // ask planet for items to load
      List<Item> toLoad = stats.origin.requestItems(capacity);
      stats.loadItem(toLoad);

   }
}