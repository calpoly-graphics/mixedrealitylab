﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Planet : IEquatable<Planet> {
   public static int HISTORY_LEN = 5;
   public string name;
   public enum Tier { Poor = 1, Developing = 2, Prospering = 3 };
   List<int> producedId;
   List<int> consumedId;
   List<PlanetItem> storage;
   public int id;
   int wealth;
   public Tier tier;
   public History wealthOverTime;
   public List<History> itemHistories;

   public Planet(string name, List<int> produced, List<int> consumed, int wealth, int id) {
      this.name = name;
      this.id = id;
      producedId = produced;
      consumedId = consumed;
      this.wealth = wealth;
      this.storage = new List<PlanetItem>();
      updateTier();
      wealthOverTime = new History("Money");
      wealthOverTime.add(this.wealth);
      this.itemHistories = new List<History>();

      // initialize all available tier 1 item
      for (int i = 0; i < GameHandler.TIER_ONE_THRESHOLD; i++) {
         this.storage.Add(new PlanetItem(GameHandler.globalItem[i], UnityEngine.Random.Range(0, 50), 50));
         this.itemHistories.Add(new History(this.storage[i]));
         this.itemHistories[i].add(this.storage[i].getQuantity());
      }
   }

   public int getWealth() {
      return this.wealth;
   }

   public List<PlanetItem> getStorage() {
      return storage;
   }

   // move on on their daily life
   public void produceConsume() {
      int num = 2;
      if (this.tier == Tier.Developing) {
         num = 3;
      } else if (this.tier == Tier.Prospering) {
         num = 4;
      }

      foreach (PlanetItem stockpile in this.storage) {
         if (this.producedId.Contains(stockpile.getItemType().itemID)) {
            wealth -= (int) (stockpile.getItemType().basePrice * .5);
            stockpile.add(num);
         }
         if (this.consumedId.Contains(stockpile.getItemType().itemID)) {
            stockpile.subtract(num);
         }
      }
   }

   public void changeWealth(int amount) {
      this.wealth += amount;
      updateTier();
   }

   public void updateTier() {
      if (this.wealth < GameConstants.tierToWealth[Tier.Poor]) {
         this.tier = Tier.Poor;
      } else if (this.wealth < GameConstants.tierToWealth[Tier.Developing]) {
         this.tier = Tier.Developing;
      } else {
         this.tier = Tier.Prospering;
      }
   }

   public List<int> getProducedId() {
      return producedId;
   }

   public List<int> getConsumedId() {
      return consumedId;
   }

   public string wealthToString() {
      return this.wealth.ToString();
   }

   public string toString() {
      string result = "";
      foreach (int i in producedId) {
         result += i.ToString();
      }

      foreach (int i in consumedId) {
         result += i.ToString();
      }

      return result;
   }

   public int getInitialMoney() {
      int result;
      if (tier == Tier.Poor) result = 100;
      else if (tier == Tier.Developing) result = 200;
      else result = 300;
      return Math.Min(result, this.wealth);
   }

   public bool Equals(Planet other) {
      return this.name == other.name;
   }

   public List<Item> requestItems(int capacity) {
      //find all surplus or exess item, this will later be limited by planet policy right now it load until its full
      List<Item> toLoad = new List<Item>();

      while (capacity > 0) {
         Item item = requestSurplusItem();
         toLoad.Add(item);
         foreach (PlanetItem stockpile in this.storage) {
            if (stockpile.getItemType().itemID == item.itemID) {
               stockpile.subtract(1);
            }
         }
         capacity--;
      }

      return toLoad;
   }

   // find the most abundant item
   private Item requestSurplusItem() {
      PlanetItem surplusStockpile = storage[0];
      foreach (PlanetItem stockpile in this.storage) {
         if (stockpile.getQuantity() > surplusStockpile.getQuantity()) {
            surplusStockpile = stockpile;
         }
      }
      return surplusStockpile.getItemType();
   }

   public int dropItem(Item item) {
      foreach (PlanetItem stockpile in this.storage) {
         if (stockpile.getItemType().itemID == item.itemID) {
            stockpile.add(1);
            return stockpile.getPrice();
         }
      }
      // should never reach here
      return 0;
   }

   public List<History> getItemHistories() {
      return this.itemHistories;
   }

   public History findItemHistory(int itemID) {
      foreach(History h in this.itemHistories) {
         if(h.getItem().getItemType().itemID == itemID) {
            return h;
         }
      }

      return null;
   }

   // Inner class to store history of price or money
   public class History {
      string name;
      int length;
      List<int> history;
      private int index = 0;
      private int HISTORY_LEN = 5;
      PlanetItem item;

      public History(string name) {
         this.name = name;
         this.length = HISTORY_LEN;
         history = new List<int>(length);
         for(int i = 0; i < length; i++) {
            history.Add(0);
         }
      }

      public History(PlanetItem item) {
         this.name = item.getItemType().itemName;
         this.length = HISTORY_LEN;
         this.item = item;
         history = new List<int>(length);
         for(int i = 0; i < length; i++) {
            history.Add(0);
         }
      }

      public void add(int price) {
         history[index%length] = price;
         index++;
      }

      public List<int> getLatest() {
         List<int> latest;

         if (index >= length) {
            latest = new List<int>(length);
            for (int i = 0; i < length; i++) {
               latest.Add(history[(index + i) % length]);
            }
         }
         else {
            latest = new List<int>(index+1);
            for (int i = 0; i < index; i++) {
               latest.Add(history[i]);
            }
         }

         return latest;
      }

      public void clear() {
         history.Clear();
         index = 0;
      }

      public int getMax() {
         int max = 0;

         foreach(int num in history) {
            if(num > max) {
               max = num;
            }
         }

         return max;
      }

      public PlanetItem getItem() {
         return this.item;
      }
   }
}