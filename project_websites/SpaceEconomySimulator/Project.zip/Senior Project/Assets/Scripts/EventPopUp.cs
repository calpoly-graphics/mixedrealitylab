﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EventPopUp : MonoBehaviour
{


    public Text title;
    public Text desc;
    public Text option1;
    public Text option2;
    public Button button1;
    public Button button2;

    private GameEvent gameEvent;


    public void initialize(GameEvent gameEvent)
    {
        this.title.text = gameEvent.title;
        this.desc.text = gameEvent.desc;
        this.option1.text = gameEvent.choice1.text;
        this.option2.text = gameEvent.choice2.text;
        this.gameEvent = gameEvent;
        button1.onClick.AddListener(Choice1Handler);
        button2.onClick.AddListener(Choice2Handler);
    }

    void Choice1Handler()
    {
        gameEvent.onPlayerChoice(gameEvent.choice1);
    }

    void Choice2Handler(){
        gameEvent.onPlayerChoice(gameEvent.choice2);
    }

}
