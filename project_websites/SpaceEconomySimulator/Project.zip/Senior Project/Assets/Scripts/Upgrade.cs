﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Upgrade{
   public string upgradeName;
   public PlayerStats.upgradableStatus modifiedStatus;
   public int modifierValue;
   public string description;
   public int cost;


   public Upgrade(string name,string description,PlayerStats.upgradableStatus modifiedStatus, int modifierValue, int cost){
      this.upgradeName = name;
      this.description = description;
      this.modifiedStatus = modifiedStatus;
      this.modifierValue = modifierValue;
      this.cost = cost;
   }
}
