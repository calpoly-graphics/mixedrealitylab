﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Route : MonoBehaviour {

   List<PlanetGO> planets;
   public Vector3 connectingNode;


   private Vector3 GetMidPoint(List<PlanetGO> planets) {
      float x = 0f;
      float y = 0f;
      int len = planets.Count;

      foreach (PlanetGO planet in planets) {
         x += planet.transform.position.x;
         y += planet.transform.position.y;
      }
      return new Vector3(x/len, y/len, 0);
   }

	// Use this for initialization
	public void Init (List<PlanetGO> planets) {

      this.planets = planets;


      int i = 0;
      LineRenderer lineRenderer = GetComponent<LineRenderer>();
      lineRenderer.startWidth = .25f;
      lineRenderer.startColor = Color.red;
      lineRenderer.endColor = Color.red;
      lineRenderer.material = new Material(Shader.Find("Mobile/Particles/Additive"));
      lineRenderer.positionCount = planets.Count * 2;
      connectingNode = GetMidPoint(planets);
      this.transform.position = connectingNode;

      foreach(PlanetGO planet in planets) {
         lineRenderer.SetPosition(i++, planet.transform.position);
         lineRenderer.SetPosition(i++, connectingNode);
      }
	}

   public List<Vector3> getPath(PlanetGO destination){
      return new List<Vector3>{GetMidPoint(this.planets),destination.transform.position};
   }

   public List<Planet> getConnectedPlanets(){
      List<Planet> connectedPlanets = new List<Planet>();
      foreach(PlanetGO planet in planets) {
         connectedPlanets.Add(planet.planet);
      }
      return connectedPlanets;
   }
	
   public delegate void OnRouteClick(Route route);
   public static OnRouteClick routeClicked;

   void OnMouseDown() {
      routeClicked(this);
   }


}
