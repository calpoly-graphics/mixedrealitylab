﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemInfo : MonoBehaviour {
   public GameObject select;
   public Image icon;
   public Text netGain;
   public Text price;
   private Item item;
   private Planet planet;
   
   public delegate void OnSelectClicked(Item item, Planet planet);
   public static OnSelectClicked selectClicked;

   void switchDisplay() {
      selectClicked(this.item, this.planet);
   }

   void Start() {
      Button btn = select.GetComponent<Button>();
      btn.onClick.AddListener(switchDisplay);
   }

   public void setInfo(Planet planet, Color color,
      Sprite iconSprite, int net, float price, Item item) {
      select.GetComponent<Image>().color = color;
      icon.sprite = iconSprite;
      netGain.text = net.ToString();
      this.price.text = price.ToString();
      this.item = item;
      this.planet = planet;
   }  

   public Item getItem() {
      return this.item;
   }
}
