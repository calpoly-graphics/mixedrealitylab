﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class DraggableItem : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{

    public delegate void OnTransaction();
    public static event OnTransaction OnTrans;
    public Transform targetParent;
    Transform oldParent;

    public void OnBeginDrag(PointerEventData eventData)
    {
        string debug = "";
        //Debug.Log(this.name + ": OnBeginDrag");
        Stats currentParentOwner = this.transform.GetComponentInParent<InventoryZone>().getOwner();
        Item itemStats = this.transform.GetComponent<ItemGO>().getItem();

        Debug.Log("Items After: " + debug);

        // shift the parent to grandparent , for dragging

        oldParent = targetParent = this.transform.parent;
        this.transform.SetParent(this.transform.parent.parent);
        this.transform.position = eventData.position;
        GetComponent<CanvasGroup>().blocksRaycasts = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
        //		Debug.Log(this.name + ": OnDrag");
        this.transform.position = eventData.position;

    }

    public void OnEndDrag(PointerEventData eventData)
    {
        //		Debug.Log(this.name + ": OnEndDrag");
        if (!oldParent.Equals(targetParent))
        {
            Item itemStats = this.transform.GetComponent<ItemGO>().getItem();
            // only base price for now TODO make a transaction function for this
            oldParent.GetComponent<InventoryZone>().getOwner().money += itemStats.basePrice;
            oldParent.GetComponent<InventoryZone>().getOwner().itemsOwn.Remove(itemStats);
            targetParent.GetComponent<InventoryZone>().getOwner().money -= itemStats.basePrice;
            targetParent.GetComponent<InventoryZone>().getOwner().itemsOwn.Add(itemStats);
            OnTrans();
        }

        GetComponent<CanvasGroup>().blocksRaycasts = true;
        this.transform.SetParent(targetParent);
    }
}
