/*
CPE/CSC 471 Lab base code Wood/Dunn/Eckhardt
*/

#include <iostream>
#include <glad/glad.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#include "GLSL.h"
#include "program.h"
#include "MatrixStack.h"

#include "WindowManager.h"
#include "Shape.h"
// value_ptr for glm
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>


#include <ctime>
using namespace std;
using namespace glm;
shared_ptr<Shape> shape, shape2, shape3;

#define NUMSTARS 100000
#define NUMASTEROIDS 2000
#define EXPLOSION_GRID_SIZE 4
#define PI pi<float>()

#define NUMGRIDWIDTH 6
#define NUMGRIDHEIGHT 3

bool gameOver = false;
bool pause = false;
int lives = 3;




double get_last_elapsed_time()
{
	static double lasttime = glfwGetTime();
	double actualtime =glfwGetTime();
	double difference = actualtime- lasttime;
	lasttime = actualtime;
	return difference;
}
class camera
{
public:
	glm::vec3 pos, rot;
	int w, a, s, d, boost;
	camera()
	{
		w = a = s = d = boost = 0;
		rot = glm::vec3(0, 0, 0);
		pos = glm::vec3(0, 0, -200);
	}
	glm::mat4 process(double ftime)
	{
		float speed = 0;
		if (!gameOver && !pause)
		{
			speed = 40*ftime;
			speed += boost * 4 * speed;
		}
		else {
			speed = 0;
		}
		/*else if (s == 1)
		{
			speed = -ftime*ftime;
			speed += boost * 4 * speed;
		}*/
		float yangle=0;
		if (a == 1 && !pause)
			yangle = -0.6*ftime;
		else if(d==1 && !pause)
			yangle = 0.6*ftime;

		float xangle = 0;
		if (w == 1 && !pause)
			xangle = -0.6*ftime;
		else if (s == 1 && !pause)
			xangle = 0.6*ftime;

		rot.y += yangle;
		rot.x += xangle;
		glm::mat4 Ry = glm::rotate(glm::mat4(1), rot.y, glm::vec3(0, 1, 0));
		glm::mat4 Rx = glm::rotate(glm::mat4(1), rot.x, glm::vec3(1, 0, 0));
		glm::vec4 dir = glm::vec4(0, 0, speed,1);
		dir = dir*Rx*Ry;
		pos += glm::vec3(dir.x, dir.y, dir.z);
		glm::mat4 T = glm::translate(glm::mat4(1), pos);
		return Rx*Ry*T;
	}
};

camera mycam;

class Application : public EventCallbacks
{

public:

	WindowManager * windowManager = nullptr;

	// Our shader program
	std::shared_ptr<Program> prog, prog2, prog3, prog4, prog5, prog6, prog7, prog8;

	// Contains vertex information for OpenGL
	GLuint VertexArrayID, VertexArrayID2, VertexArrayID3, VertexArrayID4;

	// Data necessary to give our box to OpenGL
	GLuint VertexBufferID, NormalBufferID, TextureBufferID, IndexBufferIDBox, IndexBufferIDBox2, InstanceBuffer;

	//texture data
	GLuint Texture0, Texture1, Texture2, Texture3, Texture4, Texture5, Texture6, Texture7;

	int left, right, up, down = 0;
	float xspeed, yspeed = 0;
	int shoot = 0;
	vector<mat4> shotDirs;
	vector<vec4> shotPos;
	vector<float> shotDists;
	vec3 shipPos = mycam.pos;
	vec3 destroyerPos;
	mat4 shipMatrix;

	//glm::vec4 *positionsAst = new glm::vec4[NUMASTEROIDS];
	vector<vec4> astPosVec;


	void keyCallback(GLFWwindow *window, int key, int scancode, int action, int mods)
	{
		if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		{
			glfwSetWindowShouldClose(window, GL_TRUE);
		}
		
		if (key == GLFW_KEY_W && action == GLFW_PRESS)
		{
			mycam.w = 1;
			//up = 1;
		}
		if (key == GLFW_KEY_W && action == GLFW_RELEASE)
		{
			mycam.w = 0;
			//up = 0;
		}
		if (key == GLFW_KEY_S && action == GLFW_PRESS)
		{
			mycam.s = 1;
			//down = 1;
		}
		if (key == GLFW_KEY_S && action == GLFW_RELEASE)
		{
			mycam.s = 0;
			//down = 0;
		}
		if (key == GLFW_KEY_A && action == GLFW_PRESS)
		{
			mycam.a = 1;
			//left = 1;
		}
		if (key == GLFW_KEY_A && action == GLFW_RELEASE)
		{
			mycam.a = 0;
			//left = 0;
		}
		if (key == GLFW_KEY_D && action == GLFW_PRESS)
		{
			mycam.d = 1;
			//right = 1;
		}
		if (key == GLFW_KEY_D && action == GLFW_RELEASE)
		{
			mycam.d = 0;
			//right = 0;
		}
		if (key == GLFW_KEY_SPACE && action == GLFW_PRESS)
		{
			mycam.boost = 1;
		}
		if (key == GLFW_KEY_SPACE && action == GLFW_RELEASE)
		{
			mycam.boost = 0;
		}
		if (key == GLFW_KEY_ENTER && action == GLFW_PRESS && !pause && !mycam.boost)
		{
			shoot = 1;
		}
		if (key == GLFW_KEY_P && action == GLFW_PRESS)
		{
			pause = !pause;
		}
	}

	// callback for the mouse when clicked move the triangle when helper functions
	// written
	void mouseCallback(GLFWwindow *window, int button, int action, int mods)
	{
		double posX, posY;
		float newPt[2];
		if (action == GLFW_PRESS)
		{
			glfwGetCursorPos(window, &posX, &posY);
			//std::cout << "Pos X " << posX <<  " Pos Y " << posY << std::endl;

			//change this to be the points converted to WORLD
			//THIS IS BROKEN< YOU GET TO FIX IT - yay!
			newPt[0] = posX;
			newPt[1] = posY;

			//std::cout << "converted:" << newPt[0] << " " << newPt[1] << std::endl;
			//glBindBuffer(GL_ARRAY_BUFFER, VertexBufferID);
			////update the vertex array with the updated points
			//glBufferSubData(GL_ARRAY_BUFFER, sizeof(float)*6, sizeof(float)*2, newPt);
			//glBindBuffer(GL_ARRAY_BUFFER, 0);
		}
	}

	//if the window is resized, capture the new size and reset the viewport
	void resizeCallback(GLFWwindow *window, int in_width, int in_height)
	{
		//get the window size - may be different then pixels for retina
		int width, height;
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);
	}

	int numVertices, numVerticesAst = 0;

	/*Note that any gl calls must always happen after a GL state is initialized */
	void initGeom()
	{
		//spaceship
		string resourceDirectory = "../resources";
		string mtlPath = resourceDirectory + "/xwing/source/";
		// Initialize mesh.
		shape = make_shared<Shape>();
		shape->loadMesh(resourceDirectory + "/xwing/source/Xwing.obj", &mtlPath, stbi_load);
		shape->resize();
		shape->init();

		//asteroid
		shape2 = make_shared<Shape>();
		//shape2->loadMesh(resourceDirectory + "/sphere.obj");
		shape2->loadMesh(resourceDirectory + "/meteor3.obj");
		shape2->resize();
		shape2->init();

		//asteroid
		shape3 = make_shared<Shape>();
		shape3->loadMesh(resourceDirectory + "/star-destroyer/source/Star_destroyer.obj");
		shape3->resize();
		shape3->init();


		//generate the VAO for spaceship
		glGenVertexArrays(1, &VertexArrayID);
		glBindVertexArray(VertexArrayID);

		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &VertexBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexBufferID);

		//construct non-indexed vertex buffer
		vector<vec3> vertices;
		for (int t = 0; t < shape->eleBuf[0].size(); t += 3) {
			int index_A = shape->eleBuf[0][t];
			int index_B = shape->eleBuf[0][t + 1];
			int index_C = shape->eleBuf[0][t + 2];
			float ax = shape->posBuf[0][index_A * 3 + 0];
			float ay = shape->posBuf[0][index_A * 3 + 1];
			float az = shape->posBuf[0][index_A * 3 + 2];
			float bx = shape->posBuf[0][index_B * 3 + 0];
			float by = shape->posBuf[0][index_B * 3 + 1];
			float bz = shape->posBuf[0][index_B * 3 + 2];
			float cx = shape->posBuf[0][index_C * 3 + 0];
			float cy = shape->posBuf[0][index_C * 3 + 1];
			float cz = shape->posBuf[0][index_C * 3 + 2];

			vertices.push_back(vec3(ax, ay, az));
			vertices.push_back(vec3(bx, by, bz));
			vertices.push_back(vec3(cx, cy, cz));
		}

		numVertices = vertices.size();

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec3) * vertices.size(), vertices.data(), GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(0);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);


		//now calculate flat normals
		//generate normal buffer to hand off to OGL
		glGenBuffers(1, &NormalBufferID);
		//set the current state to focus on our normal buffer
		glBindBuffer(GL_ARRAY_BUFFER, NormalBufferID);

		vector<vec3> normals;
		for (int i = 0; i < vertices.size(); i += 3) {
			vec3 a = vertices[i + 1] - vertices[i];
			vec3 b = vertices[i + 2] - vertices[i];
			vec3 normal = cross(a, b);
			normals.push_back(normal);
			normals.push_back(normal);
			normals.push_back(normal);
		}


		/*vector<float> normalFloats;
		for (int i = 0; i < normals.size(); i++) {
			normalFloats.push_back(normals[i].x);
			normalFloats.push_back(normals[i].y);
			normalFloats.push_back(normals[i].z);
		}

		shape->norBuf[0] = normalFloats;
		shape->resize();
		shape->init();*/

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec3) * normals.size(), normals.data(), GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(1);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);


		// texture
		glGenBuffers(1, &TextureBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, TextureBufferID);

		//construct non-indexed vertex buffer
		vector<vec2> texCoords;
		for (int t = 0; t < shape->eleBuf[0].size(); t += 3) {
			int index_A = shape->eleBuf[0][t];
			int index_B = shape->eleBuf[0][t + 1];
			int index_C = shape->eleBuf[0][t + 2];
			float ax = shape->texBuf[0][index_A * 2 + 0];
			float ay = shape->texBuf[0][index_A * 2 + 1];
			float bx = shape->texBuf[0][index_B * 2 + 0];
			float by = shape->texBuf[0][index_B * 2 + 1];
			float cx = shape->texBuf[0][index_C * 2 + 0];
			float cy = shape->texBuf[0][index_C * 2 + 1];

			texCoords.push_back(vec2(ax, ay));
			texCoords.push_back(vec2(bx, by));
			texCoords.push_back(vec2(cx, cy));
		}

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec2) * texCoords.size(), texCoords.data(), GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(2);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

		glBindVertexArray(0);




		//-------star billboards, instanced-----------------

		//generate the VAO
		glGenVertexArrays(1, &VertexArrayID2);
		glBindVertexArray(VertexArrayID2);

		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &VertexBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexBufferID);

		GLfloat cube_vertices[] = {
			// front
			-1.0, -1.0,  1.0,//LD
			1.0, -1.0,  1.0,//RD
			1.0,  1.0,  1.0,//RU
			-1.0,  1.0,  1.0,//LU
		};
		//make it a bit smaller
		for (int i = 0; i < 12; i++)
			cube_vertices[i] *= 0.5;
		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(cube_vertices), cube_vertices, GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(0);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//color
		GLfloat cube_norm[] = {
			// front colors
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,

		};
		glGenBuffers(1, &NormalBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, NormalBufferID);
		glBufferData(GL_ARRAY_BUFFER, sizeof(cube_norm), cube_norm, GL_STATIC_DRAW);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//color
		glm::vec2 cube_tex[] = {
			// front colors
			glm::vec2(0.0, 1.0),
			glm::vec2(1.0, 1.0),
			glm::vec2(1.0, 0.0),
			glm::vec2(0.0, 0.0),

		};
		glGenBuffers(1, &TextureBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, TextureBufferID);
		glBufferData(GL_ARRAY_BUFFER, sizeof(cube_tex), cube_tex, GL_STATIC_DRAW);
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);

		glGenBuffers(1, &IndexBufferIDBox);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox);
		GLushort cube_elements[] = {

			// front
			0, 1, 2,
			2, 3, 0,
		};
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cube_elements), cube_elements, GL_STATIC_DRAW);


		//generate vertex buffer to hand off to OGL ###########################
		glGenBuffers(1, &InstanceBuffer);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, InstanceBuffer);
		glm::vec4 *positions = new glm::vec4[NUMSTARS];
		for (int i = 0; i < NUMSTARS; i++) {
			float radius = (float)(rand() / (RAND_MAX*1.0));
			radius = pow(radius, 1.2);
			radius *= NUMSTARS / 50;
			float xangle = (float)(rand() / (RAND_MAX*1.0)) * PI;
			float yangle = (float)(rand() / (RAND_MAX*1.0)) * 2 * PI;
			glm::mat4 Rx = glm::rotate(glm::mat4(1), xangle, glm::vec3(1, 0, 0));
			glm::mat4 Ry = glm::rotate(glm::mat4(1), yangle, glm::vec3(0, 1, 0));
			positions[i] = Rx * Ry * vec4(0, 0, radius, 0);
			positions[i].y /= 2;
		}


		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, NUMSTARS * sizeof(glm::vec4), positions, GL_STATIC_DRAW);
		int position_loc = glGetAttribLocation(prog2->pid, "InstancePos");
		for (int i = 0; i < NUMSTARS; i++)
		{
			// Set up the vertex attribute
			glVertexAttribPointer(position_loc + i,              // Location
				4, GL_FLOAT, GL_FALSE,       // vec4
				sizeof(vec4),                // Stride
				(void *)(sizeof(vec4) * i)); // Start offset
											 // Enable it
			glEnableVertexAttribArray(position_loc + i);
			// Make it instanced
			glVertexAttribDivisor(position_loc + i, 1);
		}


		glBindVertexArray(0);



		//-----------asteroids------------------------
		//generate the VAO for spaceship
		glGenVertexArrays(1, &VertexArrayID3);
		glBindVertexArray(VertexArrayID3);

		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &VertexBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexBufferID);

		//construct non-indexed vertex buffer
		vector<vec3> verticesAst;
		for (int t = 0; t < shape2->eleBuf[0].size(); t += 3) {
			int index_A = shape2->eleBuf[0][t];
			int index_B = shape2->eleBuf[0][t + 1];
			int index_C = shape2->eleBuf[0][t + 2];
			float ax = shape2->posBuf[0][index_A * 3 + 0];
			float ay = shape2->posBuf[0][index_A * 3 + 1];
			float az = shape2->posBuf[0][index_A * 3 + 2];
			float bx = shape2->posBuf[0][index_B * 3 + 0];
			float by = shape2->posBuf[0][index_B * 3 + 1];
			float bz = shape2->posBuf[0][index_B * 3 + 2];
			float cx = shape2->posBuf[0][index_C * 3 + 0];
			float cy = shape2->posBuf[0][index_C * 3 + 1];
			float cz = shape2->posBuf[0][index_C * 3 + 2];

			verticesAst.push_back(vec3(ax, ay, az));
			verticesAst.push_back(vec3(bx, by, bz));
			verticesAst.push_back(vec3(cx, cy, cz));
		}

		numVerticesAst = verticesAst.size();

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec3) * verticesAst.size(), verticesAst.data(), GL_DYNAMIC_DRAW);
		//glBufferData(GL_ARRAY_BUFFER, sizeof(float) * shape2->posBuf[0].size(), shape2->posBuf[0].data(), GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(0);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);


		
		//glGenBuffers(1, &IndexBufferIDBox2);
		////set the current state to focus on our vertex buffer
		//glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox2);
		//glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(float) * shape2->eleBuf[0].size(), shape2->eleBuf[0].data(), GL_DYNAMIC_DRAW);


		//now calculate flat normals
		//generate normal buffer to hand off to OGL
		glGenBuffers(1, &NormalBufferID);
		//set the current state to focus on our normal buffer
		glBindBuffer(GL_ARRAY_BUFFER, NormalBufferID);

		vector<vec3> normalsAst;
		for (int i = 0; i < verticesAst.size(); i += 3) {
			vec3 a = verticesAst[i + 1] - verticesAst[i];
			vec3 b = verticesAst[i + 2] - verticesAst[i];
			vec3 normal = cross(a, b);
			normalsAst.push_back(normal);
			normalsAst.push_back(normal);
			normalsAst.push_back(normal);
		}

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec3) * normalsAst.size(), normalsAst.data(), GL_DYNAMIC_DRAW);
		//glBufferData(GL_ARRAY_BUFFER, sizeof(float) * shape2->norBuf[0].size(), shape2->norBuf[0].data(), GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(1);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);


		// texture
		glGenBuffers(1, &TextureBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, TextureBufferID);

		//construct non-indexed vertex buffer
		vector<vec2> texCoordsAst;
		for (int t = 0; t < shape2->eleBuf[0].size(); t += 3) {
			int index_A = shape2->eleBuf[0][t];
			int index_B = shape2->eleBuf[0][t + 1];
			int index_C = shape2->eleBuf[0][t + 2];
			float ax = shape2->texBuf[0][index_A * 2 + 0];
			float ay = shape2->texBuf[0][index_A * 2 + 1];
			float bx = shape2->texBuf[0][index_B * 2 + 0];
			float by = shape2->texBuf[0][index_B * 2 + 1];
			float cx = shape2->texBuf[0][index_C * 2 + 0];
			float cy = shape2->texBuf[0][index_C * 2 + 1];

			texCoordsAst.push_back(vec2(ax, ay));
			texCoordsAst.push_back(vec2(bx, by));
			texCoordsAst.push_back(vec2(cx, cy));
		}

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(vec2) * texCoordsAst.size(), texCoordsAst.data(), GL_DYNAMIC_DRAW);
		//glBufferData(GL_ARRAY_BUFFER, sizeof(float) * shape2->texBuf[0].size(), shape2->texBuf[0].data(), GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(2);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);


		//instance buffer
		//generate vertex buffer to hand off to OGL ###########################
		glGenBuffers(1, &InstanceBuffer);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, InstanceBuffer);
		
		for (int i = 0; i < NUMASTEROIDS; i++) {
			float radius = (float)(rand() / (RAND_MAX*1.0));
			radius = pow(radius, 0.7);
			radius *= NUMSTARS / 50;
			float xangle = (float)(rand() / (RAND_MAX*1.0)) * PI;
			float yangle = (float)(rand() / (RAND_MAX*1.0)) * 2 * PI;
			glm::mat4 Rx = glm::rotate(glm::mat4(1), xangle, glm::vec3(1, 0, 0));
			glm::mat4 Ry = glm::rotate(glm::mat4(1), yangle, glm::vec3(0, 1, 0));

			float scale = (float)(rand() / (RAND_MAX*1.0)) * 5;
			vec4 thisPos = Rx * Ry * vec4(0, 0, radius, 0);
			thisPos.y /= 2;

			if (distance(vec3(thisPos)*scale, mycam.pos) > 10) {
				thisPos.w = scale;
				astPosVec.push_back(thisPos);
			}
			else {
				thisPos.w = -scale;
				astPosVec.push_back(thisPos);
			}
		}

		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, NUMASTEROIDS * sizeof(glm::vec4), astPosVec.data(), GL_DYNAMIC_DRAW);
		int position_locAst = glGetAttribLocation(prog3->pid, "InstancePos");
		for (int i = 0; i < NUMASTEROIDS; i++)
		{
			// Set up the vertex attribute
			glVertexAttribPointer(position_locAst + i,              // Location
				4, GL_FLOAT, GL_FALSE,       // vec4
				sizeof(vec4),                // Stride
				(void *)(sizeof(vec4) * i)); // Start offset
											 // Enable it
			glEnableVertexAttribArray(position_locAst + i);
			// Make it instanced
			glVertexAttribDivisor(position_locAst + i, 1);
		}

		glBindVertexArray(0);


		//------explosion billboards-----------------------
		//generate the VAO
		glGenVertexArrays(1, &VertexArrayID4);
		glBindVertexArray(VertexArrayID4);

		//generate vertex buffer to hand off to OGL
		glGenBuffers(1, &VertexBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, VertexBufferID);

		GLfloat explosionBB_vertices[] = {
			// front
			-1.0, -1.0,  1.0,//LD
			1.0, -1.0,  1.0,//RD
			1.0,  1.0,  1.0,//RU
			-1.0,  1.0,  1.0,//LU
		};
		//make it a bit smaller
		for (int i = 0; i < 12; i++)
			explosionBB_vertices[i] *= 0.5;
		//actually memcopy the data - only do this once
		glBufferData(GL_ARRAY_BUFFER, sizeof(explosionBB_vertices), explosionBB_vertices, GL_DYNAMIC_DRAW);

		//we need to set up the vertex array
		glEnableVertexAttribArray(0);
		//key function to get up how many elements to pull out at a time (3)
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//color
		GLfloat explosionBB_norm[] = {
			// front colors
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,
			0.0, 0.0, 1.0,

		};
		glGenBuffers(1, &NormalBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, NormalBufferID);
		glBufferData(GL_ARRAY_BUFFER, sizeof(explosionBB_norm), explosionBB_norm, GL_STATIC_DRAW);
		glEnableVertexAttribArray(1);
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);

		//color
		glm::vec2 explosionBB_tex[] = {
			// front colors
			glm::vec2(0.0, 1.0),
			glm::vec2(1.0, 1.0),
			glm::vec2(1.0, 0.0),
			glm::vec2(0.0, 0.0),

		};
		glGenBuffers(1, &TextureBufferID);
		//set the current state to focus on our vertex buffer
		glBindBuffer(GL_ARRAY_BUFFER, TextureBufferID);
		glBufferData(GL_ARRAY_BUFFER, sizeof(explosionBB_tex), explosionBB_tex, GL_STATIC_DRAW);
		glEnableVertexAttribArray(2);
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
		glBindVertexArray(0);

		//---------------HUD text-------------------------
		



		//----------TEXTURES------------------------------------------------------------
		//------ship texture stuff------------
		int width, height, channels;
		char filepath[1000];

		//texture 1
		string str = resourceDirectory + "/xwing/source/XwingFuselage.jpg";
		strcpy(filepath, str.c_str());
		unsigned char* data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture0);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture0);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint Tex1Location = glGetUniformLocation(prog->pid, "tex");//tex, tex2... sampler in the fragment shader
																	 // Then bind the uniform samplers to texture units:
		glUseProgram(prog->pid);
		glUniform1i(Tex1Location, 0);


		//------star texture------------

		//texture 1
		str = resourceDirectory + "/Blue_Giant.jpg";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture1);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture1);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint StarTex1Location = glGetUniformLocation(prog2->pid, "tex");//tex, tex2... sampler in the fragment shader
		// Then bind the uniform samplers to texture units:
		glUseProgram(prog2->pid);
		glUniform1i(StarTex1Location, 0);


		//asteroid texture
		//texture 1
		str = resourceDirectory + "/asteroid.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture2);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture2);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint AstTex1Location = glGetUniformLocation(prog3->pid, "tex");//tex, tex2... sampler in the fragment shader
		// Then bind the uniform samplers to texture units:
		glUseProgram(prog3->pid);
		glUniform1i(AstTex1Location, 0);


		//------laser texture------------

		//texture 1
		str = resourceDirectory + "/laser.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture3);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture3);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint LaserTex1Location = glGetUniformLocation(prog4->pid, "tex");//tex, tex2... sampler in the fragment shader
																		  // Then bind the uniform samplers to texture units:
		glUseProgram(prog4->pid);
		glUniform1i(LaserTex1Location, 0);


		//------explosion texture------------

		//texture 1
		str = resourceDirectory + "/explode4.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture4);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture4);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint ExplodeTex1Location = glGetUniformLocation(prog5->pid, "tex");//tex, tex2... sampler in the fragment shader
		// Then bind the uniform samplers to texture units:
		glUseProgram(prog5->pid);
		glUniform1i(ExplodeTex1Location, 0);



		//------heart texture------------

		//texture 1
		str = resourceDirectory + "/heart.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture5);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture5);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint HeartTex1Location = glGetUniformLocation(prog6->pid, "tex");//tex, tex2... sampler in the fragment shader
																			 // Then bind the uniform samplers to texture units:
		glUseProgram(prog6->pid);
		glUniform1i(HeartTex1Location, 0);


		//------numbers texture------------

		//texture 1
		str = resourceDirectory + "/numbers.png";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture6);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture6);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint NumTex1Location = glGetUniformLocation(prog7->pid, "tex");//tex, tex2... sampler in the fragment shader
																		   // Then bind the uniform samplers to texture units:
		glUseProgram(prog7->pid);
		glUniform1i(NumTex1Location, 0);



		//------star destoryer texture------------

		//texture 1
		str = resourceDirectory + "/star-destroyer/textures/main_ship.jpg";
		strcpy(filepath, str.c_str());
		data = stbi_load(filepath, &width, &height, &channels, 4);
		glGenTextures(1, &Texture7);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture7);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		//set the textures to the correct samplers in the fragment shader:
		GLuint DestroyerTex1Location = glGetUniformLocation(prog8->pid, "tex");//tex, tex2... sampler in the fragment shader
																		 // Then bind the uniform samplers to texture units:
		glUseProgram(prog8->pid);
		glUniform1i(DestroyerTex1Location, 0);
	}

	//General OGL initialization - set OGL state here
	void init(const std::string& resourceDirectory)
	{
		GLSL::checkVersion();

		// Set background color.
		glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
		// Enable z-buffer test.
		glEnable(GL_DEPTH_TEST);
		//glDisable(GL_DEPTH_TEST);

		//------spaceship program--------
		prog = std::make_shared<Program>();
		prog->setVerbose(true);
		prog->setShaderNames(resourceDirectory + "/shader_vertex.glsl", resourceDirectory + "/shader_fragment.glsl");
		if (!prog->init())
		{
		std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
		exit(1);
		}
		prog->addUniform("P");
		prog->addUniform("V");
		prog->addUniform("M");
		prog->addUniform("campos");
		prog->addAttribute("vertPos");
		prog->addAttribute("vertNor");
		prog->addAttribute("vertTex");


		//---------star billboards program--------
		// Initialize the GLSL program.
		prog2 = std::make_shared<Program>();
		prog2->setVerbose(true);
		prog2->setShaderNames(resourceDirectory + "/shader_vertex2.glsl", resourceDirectory + "/shader_fragment2.glsl");
		if (!prog2->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog2->addUniform("P");
		prog2->addUniform("V");
		prog2->addUniform("M");
		prog2->addUniform("campos");
		prog2->addAttribute("vertPos");
		prog2->addAttribute("vertNor");
		prog2->addAttribute("vertTex");
		prog2->addAttribute("InstancePos");


		//---------asteroids program--------
		// Initialize the GLSL program.
		prog3 = std::make_shared<Program>();
		prog3->setVerbose(true);
		prog3->setShaderNames(resourceDirectory + "/shader_vertex3.glsl", resourceDirectory + "/shader_fragment3.glsl");
		if (!prog3->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog3->addUniform("P");
		prog3->addUniform("V");
		prog3->addUniform("M");
		prog3->addUniform("campos");
		prog3->addAttribute("vertPos");
		prog3->addAttribute("vertNor");
		prog3->addAttribute("vertTex");
		prog3->addAttribute("InstancePos");


		//------lasers program--------
		prog4 = std::make_shared<Program>();
		prog4->setVerbose(true);
		prog4->setShaderNames(resourceDirectory + "/shader_vertex4.glsl", resourceDirectory + "/shader_fragment4.glsl");
		if (!prog4->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog4->addUniform("P");
		prog4->addUniform("V");
		prog4->addUniform("M");
		prog4->addUniform("campos");
		prog4->addAttribute("vertPos");
		prog4->addAttribute("vertNor");
		prog4->addAttribute("vertTex");


		//------explosions program--------
		prog5 = std::make_shared<Program>();
		prog5->setVerbose(true);
		prog5->setShaderNames(resourceDirectory + "/shader_vertex5.glsl", resourceDirectory + "/shader_fragment5.glsl");
		if (!prog5->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog5->addUniform("P");
		prog5->addUniform("V");
		prog5->addUniform("M");
		prog5->addUniform("campos");
		prog5->addAttribute("vertPos");
		prog5->addAttribute("vertNor");
		prog5->addAttribute("vertTex");
		prog5->addUniform("offset");


		//------HUD program--------
		prog6 = std::make_shared<Program>();
		prog6->setVerbose(true);
		prog6->setShaderNames(resourceDirectory + "/shader_vertex6.glsl", resourceDirectory + "/shader_fragment6.glsl");
		if (!prog6->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog6->addUniform("P");
		prog6->addUniform("V");
		prog6->addUniform("M");
		prog6->addUniform("campos");
		prog6->addAttribute("vertPos");
		prog6->addAttribute("vertNor");
		prog6->addAttribute("vertTex");



		//------HUD text program--------
		prog7 = std::make_shared<Program>();
		prog7->setVerbose(true);
		prog7->setShaderNames(resourceDirectory + "/shader_vertex7.glsl", resourceDirectory + "/shader_fragment7.glsl");
		if (!prog7->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog7->addUniform("P");
		prog7->addUniform("V");
		prog7->addUniform("M");
		prog7->addUniform("campos");
		prog7->addAttribute("vertPos");
		prog7->addAttribute("vertNor");
		prog7->addAttribute("vertTex");
		prog7->addUniform("offset");


		//------star destroyer program--------
		prog8 = std::make_shared<Program>();
		prog8->setVerbose(true);
		prog8->setShaderNames(resourceDirectory + "/shader_vertex8.glsl", resourceDirectory + "/shader_fragment8.glsl");
		if (!prog8->init())
		{
			std::cerr << "One or more shaders failed to compile... exiting!" << std::endl;
			exit(1);
		}
		prog8->addUniform("P");
		prog8->addUniform("V");
		prog8->addUniform("M");
		prog8->addUniform("campos");
		prog8->addAttribute("vertPos");
		prog8->addAttribute("vertNor");
		prog8->addAttribute("vertTex");

	}


	void calcOffset(vec2 &offset, int digit) {
		if (digit == 0) {
			offset.x = 0;
			offset.y = 0;
		}
		else if (digit == 1) {
			offset.x = 1;
			offset.y = 0;
		}
		else if (digit == 2) {
			offset.x = 2;
			offset.y = 0;
		}
		else if (digit == 3) {
			offset.x = 3;
			offset.y = 0;
		}
		else if (digit == 4) {
			offset.x = 4;
			offset.y = 0;
		}
		else if (digit == 5) {
			offset.x = 5;
			offset.y = 0;
		}
		else if (digit == 6) {
			offset.x = 0;
			offset.y = 0.975;
		}
		else if (digit == 7) {
			offset.x = 1;
			offset.y = 0.945;
		}
		else if (digit == 8) {
			offset.x = 2;
			offset.y = 0.935;
		}
		else if (digit == 9) {
			offset.x = 3;
			offset.y = 0.935;
		}
	}

	bool removeDestroyer = false;

	/****DRAW
	This is the most important function in your program - this is where you
	will actually issue the commands to draw any geometry you have set up to
	draw
	********/
	void render()
	{
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		double frametime = get_last_elapsed_time();

		// Get current frame buffer size.
		int width, height;
		glfwGetFramebufferSize(windowManager->getHandle(), &width, &height);
		float aspect = width/(float)height;
		glViewport(0, 0, width, height);

		// Clear framebuffer.
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Create the matrix stacks - please leave these alone for now
		
		glm::mat4 V, M, P; //View, Model and Perspective matrix
		double thisTime = frametime;
		V = mycam.process(thisTime);
		M = glm::mat4(1);
		// Apply orthographic projection....
		P = glm::ortho(-1 * aspect, 1 * aspect, -1.0f, 1.0f, -2.0f, 100.0f);		
		if (width < height)
			{
			P = glm::ortho(-1.0f, 1.0f, -1.0f / aspect,  1.0f / aspect, -2.0f, 100.0f);
			}
		// ...but we overwrite it (optional) with a perspective projection.
		P = glm::perspective((float)(3.14159 / 4.), (float)((float)width/ (float)height), 0.1f, 1000.0f); //so much type casting... GLM metods are quite funny ones

		//-------render stars first so everything overlaps them----------

		//animation with the model matrix:
		static float w = 0.0;
		if (!pause) {
			w += 1.0 * frametime;//rotation angle
		}
		float trans = 0;// sin(t) * 2;
		mat4 RotateY = glm::rotate(glm::mat4(1.0f), w, glm::vec3(0.0f, 1.0f, 0.0f));
		float angle = -3.1415926/2.0;
		mat4 RotateX = glm::rotate(glm::mat4(1.0f), angle, glm::vec3(1.0f, 0.0f, 0.0f));
		mat4 TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -3 + trans));
		mat4 S = glm::scale(glm::mat4(1.0f), glm::vec3(0.8f, 0.8f, 0.8f));

		M =  TransZ * RotateY * RotateX * S;

		// Draw the box using GLSL.
		prog2->bind();

		
		//send the matrices to the shaders
		glUniformMatrix4fv(prog2->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(prog2->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniformMatrix4fv(prog2->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform3fv(prog2->getUniform("campos"), 1, &mycam.pos[0]);

		
	
		glBindVertexArray(VertexArrayID2);
		//actually draw from vertex 0, 3 vertices
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox);
		//glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, (void*)0);
		mat4 Vi = glm::transpose(V);
		Vi[0][3] = 0;
		Vi[1][3] = 0;
		Vi[2][3] = 0;
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture1);

		M = TransZ * S* Vi;
		glUniformMatrix4fv(prog2->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		
		glDisable(GL_DEPTH_TEST);
		glDrawElementsInstanced(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0,NUMSTARS);
		glEnable(GL_DEPTH_TEST);
		glBindVertexArray(0);

		prog2->unbind();


		//----------Star Destroyer----------------------------
		prog8->bind();
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture7);

		angle = -3.1415926 / 6.0;
		destroyerPos = vec3(0.0f, 0.0f, -1800.0f);
		TransZ = glm::translate(glm::mat4(1), destroyerPos);
		RotateY = glm::rotate(glm::mat4(1.0f), angle, glm::vec3(0.0f, 1.0f, 0.0f));
		S = glm::scale(glm::mat4(1.0f), glm::vec3(1000.0f, 1000.0f, 1000.0f));
		M = TransZ * RotateY * S;

		//send the matrices to the shaders
		glUniformMatrix4fv(prog8->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(prog8->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniformMatrix4fv(prog8->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform3fv(prog8->getUniform("campos"), 1, &mycam.pos[0]);
		if (!removeDestroyer) {
			shape3->draw(prog8, FALSE);
		}
		prog8->unbind();




		//#########COLLISION CHECKING########
		float astRad = 2.75;
		float shotRad = 0.2;
		float shipRad = 0.5;
		float destroyerRad = 320;

		static vec3 explodePos;
		static float explodeScale = 1.0;
		static bool explosion = false;
		//static int hits = 0;
		for (int i = 0; i < astPosVec.size(); i++) {
			//for each asteroid, check collision with every lasershot
			vec3 astPos = astPosVec[i];
			float scale = astPosVec[i].w;
			
			astPos *= scale;
			float thisAstRad = astRad * scale;
			for (int j = 0; j < shotPos.size(); j++) {
				vec3 laserPos = shotPos[j];
				float dist = distance(astPos, laserPos);
				if (dist < thisAstRad + shotRad) {
					//LASER-ASTEROID COLLISION
					//cout << "LASER-ASTEROID COLLISION" << endl;
					explosion = true;
					explodePos = astPos;
					explodeScale = scale;
					//cout << "make some booms" << endl;
					//cout << "ASTEROID COORDS::  x: " << astPos.x << " y: " << astPos.y << " z: " << astPos.z << endl;
					shotDirs.erase(shotDirs.begin() + j);
					shotDists.erase(shotDists.begin() + j);
					shotPos.erase(shotPos.begin() + j);
					j--;

					//remove asteroid
					//cout << "before: " << astPosVec.size() << endl;
					astPosVec.erase(astPosVec.begin() + i);
					//cout << "after: " << astPosVec.size() << endl;
					i--;
					glBindVertexArray(VertexArrayID3);
					glBindBuffer(GL_ARRAY_BUFFER, InstanceBuffer);
					
					vec4* data = (vec4*)glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY);
					// fill the buffer again:
					for (int k = 0; k < astPosVec.size(); k++) {
						data[k] = astPosVec[k];
					}
					// Okay, done, unmap the buffer 
					glUnmapBuffer(GL_ARRAY_BUFFER);
					glBindVertexArray(0);
				}
			}
			
			float dist = distance(astPos, shipPos);
			if (dist < thisAstRad + shipRad) {
				//SHIP-ASTEROID COLLISION
				//cout << "SHIP-ASTEROID COLLISION" << endl;
				explosion = true;
				explodePos = shipPos + vec3(shipMatrix * vec4(0, 0, -8, 0));
				explodeScale = 1.0;
				lives--;
				//cout << hits << endl;

				//remove asteroid
				astPosVec.erase(astPosVec.begin() + i);
				i--;
				glBindVertexArray(VertexArrayID3);
				glBindBuffer(GL_ARRAY_BUFFER, InstanceBuffer);

				vec4* data = (vec4*)glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY);
				// fill the buffer again:
				for (int k = 0; k < astPosVec.size(); k++) {
					data[k] = astPosVec[k];
				}
				// Okay, done, unmap the buffer 
				glUnmapBuffer(GL_ARRAY_BUFFER);
				glBindVertexArray(0);
				//cout << lives << endl;
				//cout << "astpos  x: " << astPos.x << " y: " << astPos.y << " z: " << astPos.z << endl;
				if (lives < 1 || mycam.boost) {
					gameOver = true;
					lives = 0;
				}
			}
		}

		//---star destroyer collisions-------------
		static int destroyerLife = 4;
		if (!removeDestroyer) {
			for (int j = 0; j < shotPos.size(); j++) {
				vec3 laserPos = shotPos[j];
				float dist = distance(destroyerPos, laserPos);
				if (dist < destroyerRad + shotRad) {
					//LASER-ASTEROID COLLISION
					//cout << "LASER-ASTEROID COLLISION" << endl;
					destroyerLife--;
					//cout << destroyerLife << endl;
					if (destroyerLife < 1) {
						explosion = true;
						explodePos = destroyerPos;
						explodeScale = destroyerRad / 5;
						removeDestroyer = true;
					}

					//cout << "make some booms" << endl;
					//cout << "ASTEROID COORDS::  x: " << astPos.x << " y: " << astPos.y << " z: " << astPos.z << endl;
					shotDirs.erase(shotDirs.begin() + j);
					shotDists.erase(shotDists.begin() + j);
					shotPos.erase(shotPos.begin() + j);
					j--;
				}
			}


			float dist = distance(destroyerPos, shipPos);
			if (dist < destroyerRad + shipRad) {
				//SHIP-destroyer COLLISION
				//cout << "SHIP-ASTEROID COLLISION" << endl;
				explosion = true;
				explodePos = shipPos + vec3(shipMatrix * vec4(0, 0, -8, 0));
				explodeScale = 1.0;
				lives = 0;
				//cout << hits << endl;

				if (lives < 1 || mycam.boost) {
					gameOver = true;
					lives = 0;
				}
			}
		}
		
		//cout << "SHIP COORDS::  x: " << shipPos.x << " y: " << shipPos.y << " z: " << shipPos.z << endl;
		//cout << "CAMERA::  x: " << -mycam.pos.x << " y: " << -mycam.pos.y << " z: " << -mycam.pos.z << endl;

		//cout << "NUM ASTEROIDS: " << astPosVec.size() << endl;

		

		//---------asteroids-----------------
		prog3->bind();
		glBindVertexArray(VertexArrayID3);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture2);


		RotateY = glm::rotate(glm::mat4(1.0f), w, glm::vec3(1.0f, 1.0f, 0.0f));
		S = glm::scale(glm::mat4(1.0f), glm::vec3(3.0f, 3.5f, 2.5f));
		TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, -3.0f));
		M = RotateY * S;
		glUniformMatrix4fv(prog3->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(prog3->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniformMatrix4fv(prog3->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform3fv(prog3->getUniform("campos"), 1, &mycam.pos[0]);

		glDrawArraysInstanced(GL_TRIANGLES, 0, numVerticesAst, astPosVec.size());
		glBindVertexArray(0);

		prog3->unbind();


		//-----explosions----------
		static bool stopboom1 = false, stopboom2 = false;

		if (explosion) {
			prog5->bind();
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Texture4);
			glBindVertexArray(VertexArrayID4);
			//actually draw from vertex 0, 3 vertices
			glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox);

			//explodePos = shipPos;
			//cout << "EXPLODE COORDS::  x: " << explodePos.x << " y: " << explodePos.y << " z: " << explodePos.z << endl;
			TransZ = glm::translate(glm::mat4(1.0f), explodePos);
			S = glm::scale(glm::mat4(1.0f), glm::vec3(explodeScale * 4.0f, explodeScale * 4.0f, explodeScale * 4.0f));
			M = TransZ * S * Vi;


			static double tcount1 = 0, tcount2 = 0;
			static int row1 = 0, col1 = 0, row2 = 0, col2 = 0;
			if (!pause) {
				tcount1 += 8000 * frametime;
				tcount2 += 4000 * frametime;
			}
			if (tcount1 > 0.000000001 && !stopboom1) {
				row1++;
				if (row1 > EXPLOSION_GRID_SIZE) {
					col1++;
					row1 = 0;
				}
				tcount1 = 0;

				if (row1 == EXPLOSION_GRID_SIZE && col1 == EXPLOSION_GRID_SIZE) {
					stopboom1 = true;
				}
			}

			if (tcount2 > 0.00001 && col1 > 0 && !stopboom2) {
				row2++;
				if (row2 > EXPLOSION_GRID_SIZE) {
					col2++;
					row2 = 0;
				}
				tcount2 = 0;

				if (row2 == EXPLOSION_GRID_SIZE && col2 == EXPLOSION_GRID_SIZE) {
					stopboom2 = true;
				}
			}

			vec2 offset1 = vec2(row1, col1);
			vec2 offset2 = vec2(row2, col2);

			if (stopboom1 && stopboom2) {
				//cout << "No kabooms..." << endl;
				explosion = false;
				stopboom1 = stopboom2 = false;
				tcount1 = tcount2 = row1 = row2 = col1 = col2 = 0;
			}

			//send the matrices to the shaders
			glUniformMatrix4fv(prog2->getUniform("P"), 1, GL_FALSE, &P[0][0]);
			glUniformMatrix4fv(prog2->getUniform("V"), 1, GL_FALSE, &V[0][0]);
			glUniformMatrix4fv(prog2->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			glUniform3fv(prog2->getUniform("campos"), 1, &mycam.pos[0]);
			glUniform2fv(prog5->getUniform("offset"), 1, &offset1[0]);
			glDisable(GL_DEPTH_TEST);
			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);

			TransZ = glm::translate(glm::mat4(1.0f), explodePos + vec3(3, 2, 1));
			S = glm::scale(glm::mat4(1.0f), glm::vec3(explodeScale * 8.0f, explodeScale * 8.0f, explodeScale * 8.0f));
			M = TransZ * S * Vi;
			glUniformMatrix4fv(prog2->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			glUniform2fv(prog5->getUniform("offset"), 1, &offset2[0]);
			if (col1 > 0) {
				glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);
			}
			glEnable(GL_DEPTH_TEST);
			glBindVertexArray(0);
			prog5->unbind();

			//cout << "KABOOOOOOM!" << endl;
		}



		//-------render spaceship--------------

		float setYTurnAngle = 3.1415926 / 10;
		static float actualYTurnAngle = 0;
		if (!pause) {
			if (mycam.a) {
				actualYTurnAngle = actualYTurnAngle + (setYTurnAngle - actualYTurnAngle) * 0.08;
			}
			else if (mycam.d) {
				setYTurnAngle *= -1;
				actualYTurnAngle = actualYTurnAngle + (setYTurnAngle - actualYTurnAngle) * 0.08;
			}
			else {
				setYTurnAngle = 0;
				actualYTurnAngle = actualYTurnAngle + (setYTurnAngle - actualYTurnAngle) * 0.08;
			}
		}
		

		float setXTurnAngle = 3.1415926 / 15;
		static float actualXTurnAngle = 0;
		if (!pause) {
			if (mycam.w) {
				actualXTurnAngle = actualXTurnAngle + (setXTurnAngle - actualXTurnAngle) * 0.08;
			}
			else if (mycam.s) {
				setXTurnAngle *= -1;
				actualXTurnAngle = actualXTurnAngle + (setXTurnAngle - actualXTurnAngle) * 0.08;
			}
			else {
				setXTurnAngle = 0;
				actualXTurnAngle = actualXTurnAngle + (setXTurnAngle - actualXTurnAngle) * 0.08;
			}
		}
		
		mat4 RotateZ = glm::rotate(glm::mat4(1.0f), actualYTurnAngle, glm::vec3(0.0f, 0.0f, 1.0f));
		RotateY = glm::rotate(glm::mat4(1.0f), actualYTurnAngle / 2, glm::vec3(0.0f, 1.0f, 0.0f));
		mat4 Tilt = glm::rotate(glm::mat4(1.0f), actualXTurnAngle, glm::vec3(1.0f, 0.0f, 0.0f));

		float setZ = -4.7;
		static float actualZ = 0;
		if (!pause) {
			if (mycam.boost) {
				actualZ = actualZ + (setZ - actualZ) * 0.25;
			}
			else {
				setZ = -3.7;
				actualZ = actualZ + (setZ - actualZ) * 0.25;
			}
		}

		TransZ = glm::translate(glm::mat4(1), vec3(0, -0.35, actualZ));
		angle = -3.1415926;
		mat4 faceForward = glm::rotate(glm::mat4(1.0f), angle, glm::vec3(0.0f, 1.0f, 0.0f));
		S = glm::scale(glm::mat4(1.0f), glm::vec3(0.75f, 0.75f, 0.75f));

		mat4 AMA = inverse(V) * TransZ * RotateY * RotateZ * Tilt;
		M = AMA * faceForward * S;
		shipMatrix = AMA;
		shipPos = M * vec4(0, 0, 0, 1);
		//M = inverse(mycam.process(thisTime)) * TransZ * RotateY * RotateZ * Tilt * RotateX * S;
		// Draw the box using GLSL.
		prog->bind();
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture0);

		//send the matrices to the shaders
		glUniformMatrix4fv(prog->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(prog->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniformMatrix4fv(prog->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform3fv(prog->getUniform("campos"), 1, &mycam.pos[0]);
		if (!gameOver) {
			shape->draw(prog, FALSE);
		}
		prog->unbind();


		//--------------shooting-----------------
		static int shooterIndex = 0;
		if (shoot && !mycam.boost && !gameOver && !pause) {
			//shotDirs.push_back(AMA);
			//shotPos.push_back(AMA * vec4(0, 0, 0, 1));
			shotDists.push_back(0.0);
			
			shooterIndex++;
			if (shooterIndex > 3) {
				shooterIndex = 0;
			}
			shoot = 0;

			/*prog4->bind();
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Texture3);*/

			vector<vec3> shooters;
			shooters.push_back(vec3(0.9f, 0.1f, 0.0f));
			shooters.push_back(vec3(1.0f, -0.6f, 0.0f));
			shooters.push_back(vec3(-1.0f, -0.6f, 0.0f));
			shooters.push_back(vec3(-0.9f, 0.1f, 0.0f));

			mat4 Shooter = glm::translate(glm::mat4(1), shooters[shooterIndex]);
			S = glm::scale(glm::mat4(1.0f), glm::vec3(-0.07f, -0.07f, 1.5f));
			mat4 AMB = AMA * Shooter;
			shotDirs.push_back(AMB);
			shotPos.push_back(AMB * vec4(0, 0, 0, 1));
			//M = AMB * S;

			////send the matrices to the shaders
			//glUniformMatrix4fv(prog4->getUniform("P"), 1, GL_FALSE, &P[0][0]);
			//glUniformMatrix4fv(prog4->getUniform("V"), 1, GL_FALSE, &V[0][0]);
			//glUniformMatrix4fv(prog4->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			//glUniform3fv(prog4->getUniform("campos"), 1, &mycam.pos[0]);
			//shape2->draw(prog4, FALSE);
			//prog4->unbind();
		}

		for (int i = 0; i < shotDirs.size(); i++) {
			prog4->bind();
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, Texture3);
			
			if (!pause) {
				shotDists[i] += 150.0 * frametime;
			}
			vector<vec3> shooters;
			shooters.push_back(vec3(0.9f, 0.1f, -shotDists[i]));
			shooters.push_back(vec3(1.0f, -0.6f, -shotDists[i]));
			shooters.push_back(vec3(-1.0f, -0.6f, -shotDists[i]));
			shooters.push_back(vec3(-0.9f, 0.1f, -shotDists[i]));


			mat4 TransShoot = glm::translate(glm::mat4(1), vec3(0.0f, 0.0f, -shotDists[i]));
			S = glm::scale(glm::mat4(1.0f), glm::vec3(-0.07f, -0.07f, 1.5f));
			mat4 AMC = shotDirs[i] * TransShoot;
			shotPos[i] = AMC * vec4(0, 0, 0, 1);
			M = AMC * S;

			//send the matrices to the shaders
			glUniformMatrix4fv(prog4->getUniform("P"), 1, GL_FALSE, &P[0][0]);
			glUniformMatrix4fv(prog4->getUniform("V"), 1, GL_FALSE, &V[0][0]);
			glUniformMatrix4fv(prog4->getUniform("M"), 1, GL_FALSE, &M[0][0]);
			glUniform3fv(prog4->getUniform("campos"), 1, &mycam.pos[0]);
			shape2->draw(prog4, FALSE);
			prog4->unbind();

			if (shotDists[i] > 500) {
				shotDirs.erase(shotDirs.begin() + i);
				shotDists.erase(shotDists.begin() + i);
				shotPos.erase(shotPos.begin() + i);
			}
		}


		//-----------HUD--------------------
		prog6->bind();
		//send the matrices to the shaders
		glUniformMatrix4fv(prog6->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(prog6->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniformMatrix4fv(prog6->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform3fv(prog6->getUniform("campos"), 1, &mycam.pos[0]);

		glBindVertexArray(VertexArrayID2);
		//actually draw from vertex 0, 3 vertices
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture5);

		glDisable(GL_DEPTH_TEST);
		if (lives > 0) {
			TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(-0.7f, 0.37f, -1.0f));
			S = glm::scale(glm::mat4(1.0f), glm::vec3(0.04f, 0.04f, 0.04f));
			M = inverse(V) * TransZ * S;
			glUniformMatrix4fv(prog6->getUniform("M"), 1, GL_FALSE, &M[0][0]);

			glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);

			if (lives > 1) {
				TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(-0.65f, 0.37f, -1.0f));
				M = inverse(V) * TransZ * S;
				glUniformMatrix4fv(prog6->getUniform("M"), 1, GL_FALSE, &M[0][0]);

				glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);

				if (lives > 2) {
					TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(-0.60f, 0.37f, -1.0f));
					M = inverse(V) * TransZ * S;
					glUniformMatrix4fv(prog6->getUniform("M"), 1, GL_FALSE, &M[0][0]);

					glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);
				}
			}
		}
		glEnable(GL_DEPTH_TEST);
		
		glBindVertexArray(0);
		prog6->unbind();



		//----------HUD text-------------------------
		int score = NUMASTEROIDS - astPosVec.size();
		string scoreStr = to_string(score);
		int onesDig = scoreStr[0] - '0';
		int thousandsDig = 0;
		int hundredsDig = 0;
		int tensDig = 0;

		int numDigits = strlen(&scoreStr[0]);
		if (numDigits > 1) {
			tensDig = scoreStr[0] - '0';
			onesDig = scoreStr[1] - '0';

			if (numDigits > 2) {
				hundredsDig = scoreStr[0] - '0';
				tensDig = scoreStr[1] - '0';
				onesDig = scoreStr[2] - '0';

				if (numDigits > 3) {
					thousandsDig = scoreStr[0] - '0';
					hundredsDig = scoreStr[1] - '0';
					tensDig = scoreStr[2] - '0';
					onesDig = scoreStr[3] - '0';

				}
			}
		}
		//cout << "Score: " << thousandsDig << hundredsDig << tensDig << onesDig << endl;

		prog7->bind();
		//send the matrices to the shaders
		glUniformMatrix4fv(prog7->getUniform("P"), 1, GL_FALSE, &P[0][0]);
		glUniformMatrix4fv(prog7->getUniform("V"), 1, GL_FALSE, &V[0][0]);
		glUniformMatrix4fv(prog7->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform3fv(prog7->getUniform("campos"), 1, &mycam.pos[0]);

		glBindVertexArray(VertexArrayID2);
		//actually draw from vertex 0, 3 vertices
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IndexBufferIDBox);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, Texture6);

		vec2 numOffset;
		glDisable(GL_DEPTH_TEST);

		//ones digit
		calcOffset(numOffset, onesDig);
		TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(0.66f, 0.36f, -1.0f));
		S = glm::scale(glm::mat4(1.0f), glm::vec3(0.08f, 0.08f, 0.08f));
		M = inverse(V) * TransZ * S;
		glUniformMatrix4fv(prog7->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform2fv(prog7->getUniform("offset"), 1, &numOffset[0]);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);

		//tens digit
		calcOffset(numOffset, tensDig);
		TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(0.64f, 0.36f, -1.0f));
		M = inverse(V) * TransZ * S;
		glUniformMatrix4fv(prog7->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform2fv(prog7->getUniform("offset"), 1, &numOffset[0]);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);

		//hundreds digit
		calcOffset(numOffset, hundredsDig);
		TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(0.62f, 0.36f, -1.0f));
		M = inverse(V) * TransZ * S;
		glUniformMatrix4fv(prog7->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform2fv(prog7->getUniform("offset"), 1, &numOffset[0]);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);

		//thousands digit
		calcOffset(numOffset, thousandsDig);
		TransZ = glm::translate(glm::mat4(1.0f), glm::vec3(0.6f, 0.36f, -1.0f));
		M = inverse(V) * TransZ * S;
		glUniformMatrix4fv(prog7->getUniform("M"), 1, GL_FALSE, &M[0][0]);
		glUniform2fv(prog7->getUniform("offset"), 1, &numOffset[0]);
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (void*)0);

		glEnable(GL_DEPTH_TEST);

		glBindVertexArray(0);
		prog7->unbind();

	}
};
//******************************************************************************************
int main(int argc, char **argv)
{
	srand(time(0));

	std::string resourceDir = "../resources"; // Where the resources are loaded from
	if (argc >= 2)
	{
		resourceDir = argv[1];
	}

	Application *application = new Application();

	/* your main will always include a similar set up to establish your window
		and GL context, etc. */
	WindowManager * windowManager = new WindowManager();
	windowManager->init(1920, 1080);
	windowManager->setEventCallbacks(application);
	application->windowManager = windowManager;

	/* This is the code that will likely change program to program as you
		may need to initialize or set up different data and state */
	// Initialize scene.
	application->init(resourceDir);
	application->initGeom();

	// Loop until the user closes the window.
	while(! glfwWindowShouldClose(windowManager->getHandle()))
	{
		// Render scene.
		application->render();

		// Swap front and back buffers.
		glfwSwapBuffers(windowManager->getHandle());
		// Poll for and process events.
		glfwPollEvents();
	}

	// Quit program.
	windowManager->shutdown();
	return 0;
}
