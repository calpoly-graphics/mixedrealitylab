//
//  CountryData.cpp
//  3D-Thematic-Mapping
//
//  Created by Gregory Aitken on 6/2/18.
//

#include "CountryData.hpp"

//******************************************************************************

// open file located in resource directory
static FILE* openFile(string resourceDirectory, const char *filename)
{
    const char *pathname = resourceDirectory.append(filename).c_str();
    
    FILE *file;
    
    if ((file = fopen(pathname, "r")) == NULL)
    {
        perror(pathname);
        exit(EXIT_FAILURE);
    }
    
    return file;
}

//******************************************************************************

static void printCountries(map<string, Country> *countries)
{
    for (auto it = countries->begin(); it != countries->end(); it++)
    {
        printf("%s\n", it->first.c_str());
        printf("%s\n", it->second.iso_alpha2.c_str());
        printf("%s\n", it->second.country_short.c_str());
        printf("%s\n", it->second.country_full.c_str());
        printf("%f\n", it->second.latitude);
        printf("%f\n", it->second.longitude);
        printf("%hi\n\n", it->second.index);
    }
}

map<string, Country> *initCountries(string resourceDirectory)
{
    FILE *countries_fp = openFile(resourceDirectory, COUNTRIES_FILE);
    
    map<string, Country> *countries = new map<string, Country>();
    
    char line[SMALL_BUFFER_SIZE];
    string iso_alpha3;
    Country country;
    
    // skip header
    fgets(line, SMALL_BUFFER_SIZE, countries_fp);
    
    for (short index = 0; fgets(line, SMALL_BUFFER_SIZE, countries_fp) != NULL; index++)
    {
        // parse in expected format
        iso_alpha3 = strtok(line, ",");
        
        country.iso_alpha2 = strtok(NULL, ",");
        country.country_short = strtok(NULL, ",");
        country.country_full = strtok(NULL, ",");
        country.latitude = atof(strtok(NULL, ","));
        country.longitude = atof(strtok(NULL, "\n"));
        
        country.index = index;
        
        // add pair with key as alpha-3 country code and value as country struct
        countries->insert({iso_alpha3, country});
    }
    
    fclose(countries_fp);
    
    //printCountries(countries);
    
    return countries;
}

//******************************************************************************

// sort descending by value
static bool compareDatapoints(Datapoint a, Datapoint b)
{
    return a.value > b.value;
}

static void processMetadata(string resourceDirectory, map<string, Indicator> *indicators)
{
    FILE *metadata_fp = openFile(resourceDirectory, METADATA_FILE);
    
    bool (*compare_fn_ptr)(Datapoint,Datapoint) = compareDatapoints;
    
    char line[SMALL_BUFFER_SIZE];
    string indicator_code;
    Indicator indicator;
    
    // skip header
    fgets(line, SMALL_BUFFER_SIZE, metadata_fp);
    
    while (fgets(line, SMALL_BUFFER_SIZE, metadata_fp) != NULL)
    {
        // parse in expected format
        indicator_code = strtok(line, ",");
        indicator.name = strtok(NULL, "\n");
        
        indicator.max_magnitude = 0;
        
        for (short year = FIRST_YEAR; year <= LAST_YEAR; year++)
        {
            set<Datapoint, bool (*)(Datapoint,Datapoint)> datapoints(compare_fn_ptr);
            indicator.years.insert({year, datapoints});
        }
        
        // add pair with key as indicator code and value as indicator struct
        indicators->insert({indicator_code, indicator});
    }
    
    fclose(metadata_fp);
}

static void processDataset(string resourceDirectory, map<string, Indicator> *indicators, map<string, Country> *countries)
{
    FILE *dataset_fp = openFile(resourceDirectory, DATASET_FILE);
    
    char line[LARGE_BUFFER_SIZE];
    string indicator_code, iso_alpha3, value;
    Indicator *indicator_ptr;
    Datapoint datapoint;
    
    // skip header
    fgets(line, LARGE_BUFFER_SIZE, dataset_fp);
    
    while (fgets(line, LARGE_BUFFER_SIZE, dataset_fp) != NULL)
    {
        // parse in expected format
        iso_alpha3 = strtok(line, ",");
        datapoint.country = &(countries->at(iso_alpha3));
        
        indicator_code = strtok(NULL, "\"");
        indicator_ptr = &(indicators->at(indicator_code));
        
        for (short year = FIRST_YEAR; year <= LAST_YEAR; year++)
        {
            if ((value = strtok(NULL, ",\"")) != "NA")
            {
                datapoint.value = atof(value.c_str());
                indicator_ptr->years.at(year).insert(datapoint);
                
                if (fabs(datapoint.value) > indicator_ptr->max_magnitude)
                    indicator_ptr->max_magnitude = fabs(datapoint.value);
            }
        }
    }
    
    fclose(dataset_fp);
}

static void printData(map<string, Indicator> *indicators)
{
    for (auto it1 = indicators->begin(); it1 != indicators->end(); it1++)
    {
        printf("%s\n", it1->first.c_str());
        printf("%s\n", it1->second.name.c_str());
        printf("%f\n", it1->second.max_magnitude);
        
        for (auto it2 = it1->second.years.begin(); it2 != it1->second.years.end(); it2++)
        {
            printf("\t%hi\n", it2->first);
            
            for (auto it3 = it2->second.begin(); it3 != it2->second.end(); it3++)
                printf("\t\t%s: %f\n", it3->country->country_short.c_str(), it3->value);
        }
        
        printf("\n");
    }
}

map<string, Indicator> *processData(string resourceDirectory, map<string, Country> *countries)
{
    map<string, Indicator> *indicators = new map<string, Indicator>();
    
    processMetadata(resourceDirectory, indicators);
    processDataset(resourceDirectory, indicators, countries);
    
    //printData(indicators);
    
    return indicators;
}
