//
//  Application.hpp
//  3D-Thematic-Mapping
//
//  Created by Gregory Aitken on 5/29/18.
//

#ifndef Application_hpp
#define Application_hpp

#include <iostream>

#include "Camera.hpp"
#include "CountryData.hpp"
#include "GLSL.h"
#include "Program.h"
#include "Shape.h"
#include "WindowManager.h"

#define SPHERE_FILE "/sphere.obj"
#define MAP_FILE "/basemap_flipped.png"

#define VERTICES_PER_CIRCLE 25
#define CYLINDER_RADIUS 0.01
#define CYLINDER_BASE 0.0
#define CYLINDER_HEIGHT 1.0

#define EQUATOR_OFFSET PI/2
#define PRIME_MERIDIAN_OFFSET PI

//******************************************************************************

class Application : public EventCallbacks
{
    
private:
    
    WindowManager *windowManager = nullptr;
    
    Camera camera;
    
    shared_ptr<Program> globe_prog, cylinders_prog;
    
    // obj mesh
    shared_ptr<Shape> sphere;
    
    // data for OpenGL
    GLuint CylinderVertexArrayID;
    GLuint CylinderPositionBufferID, CylinderNormalBufferID, CylinderIndexBufferID, CylinderInstanceInfoBufferID;
    GLuint Texture;
    
    // handle camera movement
    void keyCallback(GLFWwindow *window, int key, int scancode, int action, int mods);
    
    // callback for mouse when clicked
    void mouseCallback(GLFWwindow *window, int button, int action, int mods);
    
    // if the window is resized capture the new size and reset the viewport
    void resizeCallback(GLFWwindow *window, int in_width, int in_height);
    
    double get_last_elapsed_time();
    
public:
    
    // setter
    void setWindowManager(WindowManager *wm);
    
    // general OpenGL initialization
    void init(string resourceDirectory);
    
    void initGeom(string resourceDirectory, map<string, Country> *countries, map<string, Indicator> *indicators);
    
    void render();
    
};

#endif /* Application_hpp */
