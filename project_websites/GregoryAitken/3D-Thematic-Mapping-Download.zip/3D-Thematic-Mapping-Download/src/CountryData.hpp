//
//  CountryData.hpp
//  3D-Thematic-Mapping
//
//  Created by Gregory Aitken on 6/2/18.
//

#ifndef CountryData_hpp
#define CountryData_hpp

#include <map>
#include <set>
#include <string>

#include <math.h>

using namespace std;

#define NUMBER_OF_COUNTRIES 248
#define SMALL_BUFFER_SIZE 110
#define LARGE_BUFFER_SIZE 440

#define COUNTRIES_FILE "/ISO3166-to-GPS-master/iso2gps_modified.csv"
#define DATASET_FILE "/Data_Extract_From_World_Development_Indicators/dataset.csv"
#define METADATA_FILE "/Data_Extract_From_World_Development_Indicators/metadata_abridged.txt"

#define FIRST_YEAR 1998
#define LAST_YEAR 2017

//******************************************************************************

struct Country
{
    string iso_alpha2, country_short, country_full;
    float latitude, longitude;
    short index;
};

struct Datapoint
{
    Country *country;
    float value;
};

struct Indicator
{
    string name;
    float max_magnitude;
    map<short, set<Datapoint, bool (*)(Datapoint,Datapoint)>> years;
};

map<string, Country> *initCountries(string resourceDirectory);

map<string, Indicator> *processData(string resourceDirectory, map<string, Country> *countries);

#endif /* CountryData_hpp */
