//
//  Camera.cpp
//  3D-Thematic-Mapping
//
//  Created by Gregory Aitken on 5/29/18.
//

#include "Camera.hpp"

//******************************************************************************

// constructor
Camera::Camera()
{
    H = J = K = L = RELEASED;
    longitude = latitude = 0;
    
    I = O = RELEASED;
    altitude = INITIAL_ALTITUDE;
}

//******************************************************************************

// setters
void Camera::setH(int state) { H = state; }
void Camera::setJ(int state) { J = state; }
void Camera::setK(int state) { K = state; }
void Camera::setL(int state) { L = state; }
void Camera::setI(int state) { I = state; }
void Camera::setO(int state) { O = state; }

//******************************************************************************

mat4 Camera::processMovement(double frametime)
{
    if (H == PRESSED)
    {
        // H and not L --> move left
        if (L == RELEASED)
            longitude += frametime;
    }
    else if (L == PRESSED)
    {
        // L and not H --> move right
        longitude -= frametime;
    }
    
    mat4 longitudeRot = rotate(mat4(1), longitude, y_axis);
    
    if (J == PRESSED)
    {
        // J and not K --> move down
        if (K == RELEASED && (latitude -= frametime) < -PI/2)
            latitude = -PI/2;
    }
    else if (K == PRESSED)
    {
        // K and not J --> move up
        if ((latitude += frametime) > PI/2)
            latitude = PI/2;
    }
    
    mat4 latitudeRot = rotate(mat4(1), latitude, x_axis);
    
    if (I == PRESSED)
    {
        // I and not O --> zoom in
        if (O == RELEASED && (altitude -= frametime) < MINIMUM_ALTITUDE)
            altitude = MINIMUM_ALTITUDE;
    }
    else if (O == PRESSED)
    {
        // O and not I --> zoom out
        altitude += frametime;
    }
    
    mat4 altitudeTrans = translate(mat4(1), vec3(0, 0, -altitude));
    
    // resulting transformation
    return altitudeTrans * latitudeRot * longitudeRot;
}
