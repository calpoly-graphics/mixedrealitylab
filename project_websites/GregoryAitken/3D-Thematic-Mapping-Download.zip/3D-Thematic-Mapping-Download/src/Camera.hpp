//
//  Camera.hpp
//  3D-Thematic-Mapping
//
//  Created by Gregory Aitken on 5/29/18.
//

#ifndef Camera_hpp
#define Camera_hpp

// value_ptr for glm
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>

using namespace std;
using namespace glm;

static vec3 x_axis = vec3(1, 0, 0);
static vec3 y_axis = vec3(0, 1, 0);

#define PI 3.14159f

#define PRESSED 1
#define RELEASED 0

#define INITIAL_ALTITUDE 3
#define MINIMUM_ALTITUDE 1.1

//******************************************************************************

class Camera
{
    
private:
    
    // vim movement keys
    int H, J, K, L;
    float longitude, latitude;
    
    // zoom in/out
    int I, O;
    float altitude;
    
public:
    
    // constructor
    Camera();
    
    // setters
    void setH(int state);
    void setJ(int state);
    void setK(int state);
    void setL(int state);
    void setI(int state);
    void setO(int state);
    
    mat4 processMovement(double frametime);
    
};

#endif /* Camera_hpp */
