/*
 * Author:      Gregory Aitken
 * University:  Cal Poly SLO
 * Term:        Spring 2018
 * Course:      Intro to Computer Graphics
 * Instructor:  Christian Eckhardt
 *
 * Final Project: 3D Thematic Mapping
 *
 * Data from database: World Development Indicators
 * Last updated: 05/21/2018
 *
 * CPE/CSC 471 base code provided by Wood/Dunn/Eckhardt
 *
 */

#include "Application.hpp"

#define WIN_WIDTH 1920
#define WIN_HEIGHT 1080

//******************************************************************************

static string processArguments(int argc, char **argv, char *programName)
{
    if (argc == 2)
        return argv[1];
    else
    {
        cerr << "\nUsage: ./" << programName << " pathToResourceDirectory\n" << endl;
        exit(EXIT_FAILURE);
    }
}

static void runProgram(Application *application, WindowManager *windowManager)
{
    // loop until the user closes the window
    while(!glfwWindowShouldClose(windowManager->getHandle()))
    {
        // render scene
        application->render();
        
        // swap front and back buffers
        glfwSwapBuffers(windowManager->getHandle());
        
        // poll for and process events
        glfwPollEvents();
    }
    
    // quit program
    windowManager->shutdown();
}

int main(int argc, char **argv)
{
    char *programName = strrchr(argv[0], '/') + 1;
    string resourceDirectory = processArguments(argc, argv, programName);
    
    // initialize countries
    map<string, Country> *countries = initCountries(resourceDirectory);
    
    // process data
    map<string, Indicator> *indicators = processData(resourceDirectory, countries);
    
	Application *application = new Application();
    
	// establish window, GL context, etc.
	WindowManager *windowManager = new WindowManager();
	windowManager->init(WIN_WIDTH, WIN_HEIGHT, programName);
	windowManager->setEventCallbacks(application);
	application->setWindowManager(windowManager);
    
	// initialize scene
	application->init(resourceDirectory);
	application->initGeom(resourceDirectory, countries, indicators);
    
    runProgram(application, windowManager);
    
	return EXIT_SUCCESS;
}
