//
//  Application.cpp
//  3D-Thematic-Mapping
//
//  Created by Gregory Aitken on 5/29/18.
//

#include "Application.hpp"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define POPULATION_TOTAL "SP.POP.TOTL"
#define POPULATION_DENSITY "EN.POP.DNST"

#define ENERGY_USE_PER_CAPITA "EG.USE.PCAP.KG.OE"
#define CO2_EMISSIONS_PER_CAPITA "EN.ATM.CO2E.PC"

string indicator_code = POPULATION_TOTAL;
short year = 2016;

//******************************************************************************

// handle camera movement
void Application::keyCallback(GLFWwindow *window, int key, int scancode, int action, int mods)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
    else if (key == GLFW_KEY_H)
    {
        // move left
        if (action == GLFW_PRESS)
            camera.setH(PRESSED);
        else if (action == GLFW_RELEASE)
            camera.setH(RELEASED);
    }
    else if (key == GLFW_KEY_L)
    {
        // move right
        if (action == GLFW_PRESS)
            camera.setL(PRESSED);
        else if (action == GLFW_RELEASE)
            camera.setL(RELEASED);
    }
    else if (key == GLFW_KEY_J)
    {
        // move down
        if (action == GLFW_PRESS)
            camera.setJ(PRESSED);
        else if (action == GLFW_RELEASE)
            camera.setJ(RELEASED);
    }
    else if (key == GLFW_KEY_K)
    {
        // move up
        if (action == GLFW_PRESS)
            camera.setK(PRESSED);
        else if (action == GLFW_RELEASE)
            camera.setK(RELEASED);
    }
    else if (key == GLFW_KEY_I)
    {
        // zoom in
        if (action == GLFW_PRESS)
            camera.setI(PRESSED);
        else if (action == GLFW_RELEASE)
            camera.setI(RELEASED);
    }
    else if (key == GLFW_KEY_O)
    {
        // zoom out
        if (action == GLFW_PRESS)
            camera.setO(PRESSED);
        else if (action == GLFW_RELEASE)
            camera.setO(RELEASED);
    }
}

//******************************************************************************

// callback for mouse when clicked
void Application::mouseCallback(GLFWwindow *window, int button, int action, int mods)
{
}

// if the window is resized capture the new size and reset the viewport
void Application::resizeCallback(GLFWwindow *window, int in_width, int in_height)
{
    // get the window size - may be different than pixels for retina
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);
}

double Application::get_last_elapsed_time()
{
    static double lasttime = glfwGetTime();
    double actualtime = glfwGetTime();
    double difference = actualtime - lasttime;
    lasttime = actualtime;
    return difference;
}

// setter
void Application::setWindowManager(WindowManager *wm)
{
    windowManager = wm;
}

//******************************************************************************

// general OpenGL initialization
void Application::init(string resourceDirectory)
{
    GLSL::checkVersion();
    
    // set background color
    glClearColor(1, 1, 1, 1);
    
    // enable z-buffer test
    glEnable(GL_DEPTH_TEST);
    
    //**************************************************************************
    
    // initialize the globe program
    globe_prog = make_shared<Program>();
    globe_prog->setVerbose(true);
    globe_prog->setShaderNames(resourceDirectory + "/vertex_shader_globe.glsl", resourceDirectory + "/fragment_shader_globe.glsl");
    
    if (!globe_prog->init())
    {
        cerr << "One or more shaders failed to compile... exiting!" << endl;
        exit(1);
    }
    
    globe_prog->addUniform("M");
    globe_prog->addUniform("V");
    globe_prog->addUniform("P");
    globe_prog->addAttribute("vertPos");
    globe_prog->addAttribute("vertNor");
    globe_prog->addAttribute("vertTex");
    
    //**************************************************************************
    
    // initialize the cylinders program
    cylinders_prog = make_shared<Program>();
    cylinders_prog->setVerbose(true);
    cylinders_prog->setShaderNames(resourceDirectory + "/vertex_shader_cylinders.glsl", resourceDirectory + "/fragment_shader_cylinders.glsl");
    
    if (!cylinders_prog->init())
    {
        cerr << "One or more shaders failed to compile... exiting!" << endl;
        exit(1);
    }
    
    cylinders_prog->addUniform("V");
    cylinders_prog->addUniform("P");
    cylinders_prog->addAttribute("vertPos");
    cylinders_prog->addAttribute("vertNor");
    cylinders_prog->addAttribute("vertTex");
    cylinders_prog->addAttribute("instanceInfo");
}

//******************************************************************************

void Application::initGeom(string resourceDirectory, map<string, Country> *countries, map<string, Indicator> *indicators)
{
    // initialize sphere mesh
    sphere = make_shared<Shape>();
    sphere->loadMesh(resourceDirectory + SPHERE_FILE);
    sphere->resize();
    sphere->init();
    
    //**************************************************************************
    
    // generate cylinder object
    glGenVertexArrays(1, &CylinderVertexArrayID);
    glBindVertexArray(CylinderVertexArrayID);
    
    //**************************************************************************
    
    // generate cylinder position buffer
    glGenBuffers(1, &CylinderPositionBufferID);
    glBindBuffer(GL_ARRAY_BUFFER, CylinderPositionBufferID);
    
    int i;
    float theta;
    
    // 3 circles plus a center point with 3 coordinates per vertex
    GLfloat cylinder_position_buffer[3 * (3 * VERTICES_PER_CIRCLE + 1)];
    
    // create 3 circles
    for (i = 0; i < 3 * VERTICES_PER_CIRCLE; i++)
    {
        theta = (2 * PI / VERTICES_PER_CIRCLE) * i;
        
        cylinder_position_buffer[3*i + 0] = CYLINDER_RADIUS * cos(theta); // x
        cylinder_position_buffer[3*i + 1] = CYLINDER_RADIUS * sin(theta); // y
        cylinder_position_buffer[3*i + 2] = CYLINDER_BASE + ((i < VERTICES_PER_CIRCLE) ? 0 : CYLINDER_HEIGHT); // z
    }
    
    // center point is last
    cylinder_position_buffer[3*i + 0] = 0; // x
    cylinder_position_buffer[3*i + 1] = 0; // y
    cylinder_position_buffer[3*i + 2] = CYLINDER_BASE + CYLINDER_HEIGHT; // z
    
    glBufferData(GL_ARRAY_BUFFER, sizeof(cylinder_position_buffer), cylinder_position_buffer, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*) 0);
    
    //**************************************************************************
    
    // generate cylinder normal buffer
    glGenBuffers(1, &CylinderNormalBufferID);
    glBindBuffer(GL_ARRAY_BUFFER, CylinderNormalBufferID);
    
    // 3 circles plus a center point with 3 coordinates per vertex
    GLfloat cylinder_normal_buffer[3 * (3 * VERTICES_PER_CIRCLE + 1)];
    
    // round surface
    for (i = 0; i < 2 * VERTICES_PER_CIRCLE; i++)
    {
        cylinder_normal_buffer[3*i + 0] = cylinder_position_buffer[3*i + 0]; // x
        cylinder_normal_buffer[3*i + 1] = cylinder_position_buffer[3*i + 1]; // y
        cylinder_normal_buffer[3*i + 2] = 0; // z
    }
    
    // flat surface
    for (i = 2 * VERTICES_PER_CIRCLE; i < (3 * VERTICES_PER_CIRCLE + 1); i++)
    {
        cylinder_normal_buffer[3*i + 0] = 0; // x
        cylinder_normal_buffer[3*i + 1] = 0; // y
        cylinder_normal_buffer[3*i + 2] = 1; // z
    }
    
    glBufferData(GL_ARRAY_BUFFER, sizeof(cylinder_normal_buffer), cylinder_normal_buffer, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, (void*) 0);
    
    //**************************************************************************
    
    // generate cylinder index buffer
    glGenBuffers(1, &CylinderIndexBufferID);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, CylinderIndexBufferID);
    
    // 3 circles and a triangle with 3 indices per vertex
    GLushort cylinder_index_buffer[3 * 3 * VERTICES_PER_CIRCLE];
    
    // create side faces
    for (i = 0; i < (VERTICES_PER_CIRCLE - 1); i++)
    {
        cylinder_index_buffer[6*i + 0] = i;
        cylinder_index_buffer[6*i + 1] = i + 1;
        cylinder_index_buffer[6*i + 2] = i + VERTICES_PER_CIRCLE + 1;
        
        cylinder_index_buffer[6*i + 3] = i;
        cylinder_index_buffer[6*i + 4] = i + VERTICES_PER_CIRCLE;
        cylinder_index_buffer[6*i + 5] = i + VERTICES_PER_CIRCLE + 1;
    }
    
    // last face is different
    cylinder_index_buffer[6*i + 0] = i;
    cylinder_index_buffer[6*i + 1] = 0;
    cylinder_index_buffer[6*i + 2] = VERTICES_PER_CIRCLE;
    
    cylinder_index_buffer[6*i + 3] = i;
    cylinder_index_buffer[6*i + 4] = i + VERTICES_PER_CIRCLE;
    cylinder_index_buffer[6*i + 5] = VERTICES_PER_CIRCLE;
    
    // create top triangles
    for (i = 2 * VERTICES_PER_CIRCLE; i < (3 * VERTICES_PER_CIRCLE - 1); i++)
    {
        cylinder_index_buffer[3*i + 0] = 3 * VERTICES_PER_CIRCLE;
        cylinder_index_buffer[3*i + 1] = i;
        cylinder_index_buffer[3*i + 2] = i + 1;
    }
    
    // last triangle is different
    cylinder_index_buffer[3*i + 0] = 3 * VERTICES_PER_CIRCLE;
    cylinder_index_buffer[3*i + 1] = i;
    cylinder_index_buffer[3*i + 2] = 2 * VERTICES_PER_CIRCLE;
    
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cylinder_index_buffer), cylinder_index_buffer, GL_STATIC_DRAW);
    
    //**************************************************************************
    
    // generate cylinder instance info buffer
    glGenBuffers(1, &CylinderInstanceInfoBufferID);
    glBindBuffer(GL_ARRAY_BUFFER, CylinderInstanceInfoBufferID);
    
    vec3 cylinder_instance_info_buffer[NUMBER_OF_COUNTRIES];
    
    auto countries_iterator = countries->begin();
    
    for (i = 0; countries_iterator != countries->end(); countries_iterator++, i++)
    {
        cylinder_instance_info_buffer[i].x = countries_iterator->second.latitude;
        cylinder_instance_info_buffer[i].y = countries_iterator->second.longitude;
        cylinder_instance_info_buffer[i].z = -2;
    }
    
    set<Datapoint, bool (*)(Datapoint,Datapoint)> datapoints = indicators->at(indicator_code).years.at(year);
    
    for (auto datapoints_iterator = datapoints.begin(); datapoints_iterator != datapoints.end(); datapoints_iterator++)
    {
        cylinder_instance_info_buffer[datapoints_iterator->country->index].z = datapoints_iterator->value / indicators->at(indicator_code).max_magnitude;
    }
    
    glBufferData(GL_ARRAY_BUFFER, sizeof(cylinder_instance_info_buffer), cylinder_instance_info_buffer, GL_STATIC_DRAW);
    
    int attribute_location = glGetAttribLocation(cylinders_prog->pid, "instanceInfo");
    
    for (i = 0; i < NUMBER_OF_COUNTRIES; i++)
    {
        // enable it
        glEnableVertexAttribArray(attribute_location + i);
        
        // set up the vertex attribute
        glVertexAttribPointer(attribute_location + i,       // location
                              3, GL_FLOAT, GL_FALSE,        // vec3
                              sizeof(vec3),                 // stride
                              (void*)(sizeof(vec3) * i));   // start offset
        
        // make it instanced
        glVertexAttribDivisor(attribute_location + i, 1);
    }
    
    glBindVertexArray(0);
    
    //**************************************************************************
    
    int width, height, channels;
    char filepath[1000];
    
    // map texture
    string str = resourceDirectory + MAP_FILE;
    strcpy(filepath, str.c_str());
    unsigned char* data = stbi_load(filepath, &width, &height, &channels, 4);
    glGenTextures(1, &Texture);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, Texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    
    // set texture to correct sampler in fragment shader
    GLuint TexLocation = glGetUniformLocation(globe_prog->pid, "tex");
    
    // bind uniform sampler to texture unit
    glUseProgram(globe_prog->pid);
    glUniform1i(TexLocation, 0);
}

//******************************************************************************

void Application::render()
{
    double frametime = get_last_elapsed_time();
    
    // get current frame buffer size
    int width, height;
    glfwGetFramebufferSize(windowManager->getHandle(), &width, &height);
    float aspect = width/(float)height;
    glViewport(0, 0, width, height);
    
    // clear framebuffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    mat4 Model, View, Projection;
    View = camera.processMovement(frametime);
    Projection = perspective(PI/4, aspect, 0.1f, 1000.0f);
    
    // globe
    globe_prog->bind();
    
    mat4 OrientLatitude = rotate(mat4(1), EQUATOR_OFFSET, x_axis);
    mat4 OrientLongitude = rotate(mat4(1), PRIME_MERIDIAN_OFFSET, y_axis);
    Model = OrientLongitude * OrientLatitude;
    
    glUniformMatrix4fv(globe_prog->getUniform("M"), 1, GL_FALSE, &Model[0][0]);
    glUniformMatrix4fv(globe_prog->getUniform("V"), 1, GL_FALSE, &View[0][0]);
    glUniformMatrix4fv(globe_prog->getUniform("P"), 1, GL_FALSE, &Projection[0][0]);
    
    sphere->draw(globe_prog, false);
    
    globe_prog->unbind();
    
    // cylinders
    cylinders_prog->bind();
    
    glUniformMatrix4fv(cylinders_prog->getUniform("V"), 1, GL_FALSE, &View[0][0]);
    glUniformMatrix4fv(cylinders_prog->getUniform("P"), 1, GL_FALSE, &Projection[0][0]);
    
    glBindVertexArray(CylinderVertexArrayID);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, CylinderIndexBufferID);
    glDrawElementsInstanced(GL_TRIANGLES, 3 * 3 * VERTICES_PER_CIRCLE, GL_UNSIGNED_SHORT, (void*) 0, NUMBER_OF_COUNTRIES);
    glBindVertexArray(0);
    
    cylinders_prog->unbind();
}
