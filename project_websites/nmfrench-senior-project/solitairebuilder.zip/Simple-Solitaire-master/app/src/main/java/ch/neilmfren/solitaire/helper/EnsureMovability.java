package ch.neilmfren.solitaire.helper;

import android.os.AsyncTask;
import android.os.Bundle;

import java.util.ArrayList;

import ch.neilmfren.solitaire.SharedData;
import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.dialogs.DialogEnsureMovability;
import ch.neilmfren.solitaire.games.Pyramid;

import static ch.neilmfren.solitaire.SharedData.currentGame;

import static ch.neilmfren.solitaire.SharedData.ensureMovability;
import static ch.neilmfren.solitaire.SharedData.gameLogic;
import static ch.neilmfren.solitaire.SharedData.moveToStack;

import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.stopUiUpdates;



public class EnsureMovability {

    FindMoves findMoves ;
    DialogEnsureMovability dialog;

    private boolean paused = false;

    private ShowDialog showDialog;

    public void setShowDialog(ShowDialog callback){
        showDialog = callback;
    }

    public void start(){
        dialog = new DialogEnsureMovability();
        showDialog.show(dialog);

        findMoves = new FindMoves();
        findMoves.execute();
    }

    public void stop(){
        dialog.dismiss();
        findMoves.cancel(true);
    }

    public boolean isRunning(){
        return SharedData.stopUiUpdates;
    }

    public void pause(){
        if (isRunning()) {
            paused = true;
            dialog.dismiss();
            findMoves.interrupt();
        }
    }

    public void saveInstanceState(Bundle bundle){
        if (isRunning() || paused){
            bundle.putBoolean("BUNDLE_ENSURE_MOVABILITY", true);
        }
    }

    public void loadInstanceState(Bundle bundle){
        if (bundle.containsKey("BUNDLE_ENSURE_MOVABILITY")){
            gameLogic.newGame();
        }
    }

    public void resume(){
        if (paused) {
            paused = false;
            gameLogic.load(true);
            gameLogic.newGame();
        }
    }

    private void dismissDialog(){
        dialog.dismiss();
    }

    private static class FindMoves extends AsyncTask<Object, Void, Boolean> {
        private int counter = 0;
        private boolean mainStackAlreadyFlipped = false;
        private boolean isInterrupted = false;

        @Override
        protected Boolean doInBackground(Object... objects) {
            int minPossibleMovements = prefs.getSavedEnsureMovabilityMinMoves();

            try {
                while (true) {
                    if (isCancelled()) {
                        return false;
                    }

                    if (counter == minPossibleMovements || currentGame.winTest()) {
                        return true;
                    }

                    CardAndStack cardAndStack = currentGame.hintTest();

                    if (cardAndStack != null) {

                        Stack destination = cardAndStack.getStack();
                        Card card = cardAndStack.getCard();
                        Stack origin = card.getStack();

                        int size = origin.getSize() - card.getIndexOnStack();

                        ArrayList<Card> cardsToMove = new ArrayList<>(size);

                        for (int l = card.getIndexOnStack(); l < origin.getSize(); l++) {
                            cardsToMove.add(origin.getCard(l));
                        }

                        //TODO manage this in another way
                        if (currentGame instanceof Pyramid) {
                            currentGame.cardTest(destination, card);
                        }

                        //logText("Moving " + cardsToMove.get(0).getValue() + " to stack " + cardsToMove.get(0).getStackId());
                        //logText("Counter: " + counter);
                        moveToStack(cardsToMove, destination);

                        if (origin.getSize() > 0 && origin.getId() <= currentGame.getLastTableauId() && !origin.getTopCard().isUp()) {
                            origin.getTopCard().flip();
                        }

                        currentGame.testAfterMove();

                        mainStackAlreadyFlipped = false;
                        counter++;
                    } else if (currentGame.hasMainStack()) {
                        int result = currentGame.mainStackTouch();

                        if (result == 0 || (result == 2 && mainStackAlreadyFlipped)) {
                            nextTry();
                        } else if (result == 2) {
                            mainStackAlreadyFlipped = true;
                        }

                    } else {
                        nextTry();
                    }
                }
            } catch (Exception e) {
                stopUiUpdates = false;
                return false;
            }
        }

        private void nextTry() {
            if (isCancelled()) {
                return;
            }

            counter = 0;
            mainStackAlreadyFlipped = false;
            gameLogic.newGameForEnsureMovability();
        }

        @Override
        protected void onPostExecute(Boolean result) {
            stopUiUpdates = false;

            if (result && !isInterrupted) {
                try {
                    ensureMovability.dismissDialog();
                } catch (IllegalStateException ignored) {
                    //Meh
                }

                gameLogic.redeal();
            }
        }

        @Override
        protected void onCancelled() {
            //will be called after the user presses the "cancel" button in the dialog and after
            //executing doInBackground() the last time

            stopUiUpdates = false;

            if (!isInterrupted) {
                gameLogic.redeal();
            }
        }

        public void interrupt() {
            isInterrupted = true;
            cancel(true);
        }

    }

    public interface ShowDialog{
        void show(DialogEnsureMovability dialog);
    }
}
