package ch.neilmfren.solitaire.dialogs;

import android.content.Context;
import android.graphics.Typeface;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogPreference;

import static ch.neilmfren.solitaire.SharedData.*;



public class DialogPreferenceMenuHideGames extends CustomDialogPreference implements View.OnClickListener {

    private ArrayList<LinearLayout> linearLayouts = new ArrayList<>();
    private ArrayList<CheckBox> checkBoxes = new ArrayList<>();
    private ArrayList<Integer> gameOrder;

    public DialogPreferenceMenuHideGames(Context context, AttributeSet attrs) {
        super(context, attrs);
        setDialogLayoutResource(R.layout.dialog_menu_show_games);
        setDialogIcon(null);
    }

    @Override
    protected void onBindDialogView(View view) {
        LinearLayout container = (LinearLayout) view.findViewById(R.id.layoutContainer);

        linearLayouts.clear();
        checkBoxes.clear();

        ArrayList<Integer> results = lg.getMenuShownList();
        gameOrder = lg.getOrderedGameList();

        TypedValue typedValue = new TypedValue();
        getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, typedValue, true);
        int padding = (int) (getContext().getResources().getDimension(R.dimen.dialog_menu_layout_padding));
        int margin = (int) (getContext().getResources().getDimension(R.dimen.dialog_menu_button_margin));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.setMargins(margin, 0, margin, 0);

        ArrayList<String> sortedGameList = lg.getOrderedGameNameList(getContext().getResources());

        for (int i=0;i<lg.getGameCount();i++){
            LinearLayout entry = new LinearLayout(getContext());
            entry.setBackgroundResource(typedValue.resourceId);
            entry.setPadding(padding,padding,padding,padding);
            entry.setOnClickListener(this);

            CheckBox checkBox = new CheckBox(getContext());
            checkBox.setLayoutParams(layoutParams);
            int index = gameOrder.indexOf(i);
            checkBox.setChecked(results.get(index) == 1);

            TextView textView = new TextView(getContext());
            textView.setTypeface(null, Typeface.BOLD);
            textView.setText(sortedGameList.get(i));

            entry.addView(checkBox);
            entry.addView(textView);

            checkBoxes.add(checkBox);
            linearLayouts.add(entry);

            container.addView(entry);
        }


        super.onBindDialogView(view);
    }

    @SuppressWarnings("SuspiciousMethodCalls")
    public void onClick(View view) {
        int index = linearLayouts.indexOf(view);
        boolean checked = checkBoxes.get(index).isChecked();
        checkBoxes.get(index).setChecked(!checked);
    }

    @Override
    protected void onDialogClosed(boolean positiveResult) {
        super.onDialogClosed(positiveResult);

        if (positiveResult) {
            ArrayList<Integer> list = new ArrayList<>();

            for (int i=0;i<lg.getGameCount();i++){
                int index = gameOrder.get(i);
                list.add(checkBoxes.get(index).isChecked() ? 1 : 0);
            }

            prefs.saveMenuGamesList(list);
        }
    }
}
