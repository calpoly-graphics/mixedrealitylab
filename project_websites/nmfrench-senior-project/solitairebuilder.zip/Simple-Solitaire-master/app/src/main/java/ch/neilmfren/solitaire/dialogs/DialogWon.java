package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Locale;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogFragment;
import ch.neilmfren.solitaire.helper.User;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;



public class DialogWon extends CustomDialogFragment {

    private static String KEY_SCORE = "PREF_KEY_SCORE";
    private static String KEY_BONUS = "BONUS";
    private static String KEY_TOTAL = "TOTAL";

    private FirebaseDatabase db;

    private long score, bonus, total;

    @Override
    @NonNull
    public Dialog onCreateDialog(Bundle savedState) {
        final GameManager gameManager = (GameManager) getActivity();
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View view = inflater.inflate(R.layout.dialog_won, null);

        final EditText et = (EditText) view.findViewById(R.id.editText2);
        et.requestFocus();

        final Button b = (Button) view.findViewById(R.id.btnAddHighscore);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view1) {
                if(et.getText().toString().length() > 0) {
                    User u = new User(et.getText().toString(), scores.getRecentScore(0, 0), scores.getRecentScore(0, 1), scores.getRecentScore(0, 2));
                    db = FirebaseDatabase.getInstance();
                    DatabaseReference dbRef = db.getReference("highscores").child(lg.getGameName());
                    dbRef.push().setValue(u);
                    Log.d("HIGHSCORES", scores.getRecentScore(0, 0) + " " + scores.getRecentScore(0, 1) + " " + scores.getRecentScore(0, 2));
                    b.setEnabled(false);
                    et.setEnabled(false);
                }
            }
        });


        builder.setCustomTitle(view)
                .setItems(R.array.won_menu, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // "which" argument contains index of selected item
                        switch (which) {
                            case 0:
                                gameLogic.newGame();
                                break;
                            case 1:
                                gameLogic.redeal();
                                break;
                            case 2:
                                if (gameManager.hasLoaded) {
                                    timer.save();
                                    gameLogic.setWonAndReloaded();
                                    gameLogic.save();
                                }

                                gameManager.finish();
                                break;
                        }
                    }
                })
                .setNegativeButton(R.string.game_cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //cancel
                    }
                });

        LinearLayout layoutScores = (LinearLayout) view.findViewById(R.id.dialog_won_layout_scores);

        //only show the calculation of the score if bonus is enabled
        if (currentGame.isBonusEnabled()) {
            layoutScores.setVisibility(View.VISIBLE);
            TextView text1 = (TextView) view.findViewById(R.id.dialog_won_text1);
            TextView text2 = (TextView) view.findViewById(R.id.dialog_won_text2);
            TextView text3 = (TextView) view.findViewById(R.id.dialog_won_text3);

            score = (savedState!=null && savedState.containsKey(KEY_SCORE)) ? savedState.getLong(KEY_SCORE) : scores.getPreBonus();
            bonus = (savedState!=null && savedState.containsKey(KEY_BONUS)) ? savedState.getLong(KEY_BONUS) : scores.getBonus();
            total = (savedState!=null && savedState.containsKey(KEY_TOTAL)) ? savedState.getLong(KEY_TOTAL) : scores.getScore();

            text1.setText(String.format(Locale.getDefault(),getContext().getString(R.string.dialog_win_score), score));
            text2.setText(String.format(Locale.getDefault(),getContext().getString(R.string.dialog_win_bonus), bonus));
            text3.setText(String.format(Locale.getDefault(),getContext().getString(R.string.dialog_win_total), total));
        } else {
            layoutScores.setVisibility(View.GONE);
        }

        AlertDialog dialog = builder.create();

        return applyFlags(dialog);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putLong(KEY_SCORE,score);
        outState.putLong(KEY_BONUS,bonus);
        outState.putLong(KEY_TOTAL,total);
    }

    @Override
    public void onResume() {
        super.onResume();
        getDialog().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
    }


}