package ch.neilmfren.solitaire.helper;

import java.util.ArrayList;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.Stack;

import static ch.neilmfren.solitaire.SharedData.*;
import static java.lang.Math.abs;



public class MovingCards {

    private ArrayList<Card> currentCards = new ArrayList<>();                                       //array list containing the current cards to move
    private float offsetX, offsetY;
    private boolean moveStarted;

    public void reset() {
        currentCards.clear();
    }


    public void add(Card card, float offsetX, float offsetY) {
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        Stack stack = card.getStack();
        moveStarted = false;

        for (int i = stack.getIndexOfCard(card); i < stack.getSize(); i++) {
            stack.getCard(i).saveOldLocation();
            currentCards.add(stack.getCard(i));
        }
    }


    public void move(float X, float Y) {
        for (Card card : currentCards) {
            card.setLocationWithoutMovement(X - offsetX, (Y - offsetY)
                    + currentCards.indexOf(card) * Stack.defaultSpacing / 2);
        }
    }

    public boolean moveStarted(float X, float Y) {
        return moveStarted || didMoveStart(X, Y);
    }


    private boolean didMoveStart(float X, float Y) {
        if (abs(currentCards.get(0).getX() + offsetX - X) > Card.width / 4 || abs(currentCards.get(0).getY() + offsetY - Y) > Card.height / 4) {
            moveStarted = true;
            return true;
        }

        return false;
    }


    public void moveToDestination(Stack destination) {
        gameLogic.checkFirstMovement();
        sounds.playSound(Sounds.names.CARD_SET);

        Stack origin = currentCards.get(0).getStack();

        moveToStack(currentCards, destination);

        if (origin.getSize() > 0 && origin.getId() <= currentGame.getLastTableauId() && !origin.getTopCard().isUp()) {
            origin.getTopCard().flipWithAnim();
        }

        currentCards.clear();
        gameLogic.checkForAutoCompleteButton(false);
    }


    public void returnToPos() {
        for (Card card : currentCards)
            card.returnToOldLocation();

        currentCards.clear();
    }


    public boolean hasSingleCard() {
        return getSize() < 2;
    }

    public Card first() {
        return currentCards.get(0);
    }

    public int getSize() {
        return currentCards.size();
    }

    public boolean hasCards() {
        return !currentCards.isEmpty();
    }
}
