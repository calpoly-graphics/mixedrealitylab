

package ch.neilmfren.solitaire.helper;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.graphics.PointF;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;

import java.util.Random;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CustomImageView;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.classes.WaitForAnimationHandler;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;



public class Animate {

    public WaitForAnimationHandler handlerAfterWon;
    private GameManager gm;
    private float speedFactor;
    int phase = 1;

    public Animate(GameManager gameManager) {
        this.gm = gameManager;
        speedFactor = prefs.getSavedMovementSpeed();

        handlerAfterWon = new WaitForAnimationHandler(gm, new WaitForAnimationHandler.MessageCallBack() {
            @Override
            public void doAfterAnimation() {
                if (phase == 1) {
                    wonAnimationPhase2();
                    phase = 2;
                    handlerAfterWon.sendDelayed();
                } else {
                    phase = 1;
                    gm.showWonDialog();
                }
            }

            @Override
            public boolean additionalHaltCondition() {
                return false;
            }
        });
    }

    public void updateMovementSpeed() {
        speedFactor = prefs.getSavedMovementSpeed();
    }


    public void winAnimation() {
        float posX = gm.layoutGame.getWidth() / 2 - Card.width / 2;
        float posY = gm.layoutGame.getHeight() / 2 - Card.height / 2;

        for (Card card : cards) {
            moveCardSlow(card, posX, posY);
        }

        sounds.playWinSound();
        handlerAfterWon.sendDelayed();
    }


    public void wonAnimationPhase2() {
        int direction = 0;
        int counter = 0;
        Random rand = new Random();

        PointF newPositions[] = new PointF[cards.length];

        for (int i = 0; i < cards.length; i++) {
            switch (direction) {
                case 0:
                default://right side
                    newPositions[i] = new PointF(gm.layoutGame.getWidth(), counter);
                    counter += Card.height;

                    if (counter >= gm.layoutGame.getHeight()) {
                        direction = 1;
                        counter = rand.nextInt(Card.height);
                    }

                    break;
                case 1://bottom side
                    newPositions[i] = new PointF(counter, gm.layoutGame.getHeight() + Card.height);
                    counter += Card.width;

                    if (counter >= gm.layoutGame.getWidth()) {
                        direction = 2;
                        counter = rand.nextInt(Card.width);
                    }

                    break;
                case 2://left side
                    newPositions[i] = new PointF(-Card.width, counter);
                    counter += Card.height;

                    if (counter >= gm.layoutGame.getHeight()) {
                        direction = 3;
                        counter = rand.nextInt(Card.height);
                    }
                    break;
                case 3://top side
                    newPositions[i] = new PointF(counter, -Card.height);
                    counter += Card.width;

                    if (counter >= gm.layoutGame.getWidth()) {
                        direction = 0;
                        counter = rand.nextInt(Card.width);
                    }
                    break;
            }
        }

        for (int i = 0; i < cards.length; i++) {
            moveCardSlow(cards[i], newPositions[i].x, newPositions[i].y);
        }
    }


    public void cardHint(final Card card, final int offset, final Stack destination) {
        card.bringToFront();
        card.saveOldLocation();
        PointF pointAtStack = destination.getPosition(offset);
        float dist_x = pointAtStack.x - card.getX();
        float dist_y = pointAtStack.y - card.getY();
        int distance = (int) Math.sqrt((double) ((dist_x * dist_x) + (dist_y * dist_y)));

        TranslateAnimation animation = new TranslateAnimation(0, dist_x, 0, dist_y);

        try {
            animation.setDuration((long) (distance * 100 / Card.width / speedFactor));
        } catch (ArithmeticException e) {
            animation.setDuration(100);
            Log.e("Animate moveCard()", e.toString());
        }

        animation.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationStart(Animation animation) {
            }

            public void onAnimationEnd(Animation animation) {
                PointF pointAtStack = destination.getPosition(offset);
                card.view.setX(pointAtStack.x);
                card.view.setY(pointAtStack.y);
                hideCard(card);
            }

            public void onAnimationRepeat(Animation animation) {
            }
        });

        card.view.startAnimation(animation);
    }


    private void hideCard(final Card card) {
        Animation card_fade_out = AnimationUtils.loadAnimation(
                gm.getApplicationContext(), R.anim.card_fade_out);

        card_fade_out.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationStart(Animation animation) {
            }

            public void onAnimationEnd(Animation animation) {
                card.view.setVisibility(View.INVISIBLE);
                showCard(card);
            }

            public void onAnimationRepeat(Animation animation) {
            }
        });

        card.view.startAnimation(card_fade_out);
    }


    private void showCard(final Card card) {
        Animation card_fade_in = AnimationUtils.loadAnimation(
                gm.getApplicationContext(), R.anim.card_fade_in);

        card_fade_in.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationStart(Animation animation) {
                card.returnToOldLocation();
                card.view.setVisibility(View.VISIBLE);
            }

            public void onAnimationEnd(Animation animation) {
            }

            public void onAnimationRepeat(Animation animation) {
            }
        });

        card.view.startAnimation(card_fade_in);
    }


    public void moveCardSlow(final Card card, final float pX, final float pY) {
        final CustomImageView view = card.view;

        if (card.isInvisible()){
            return;
        }

        int distance = (int) Math.sqrt(Math.pow(pX - view.getX(), 2) + Math.pow(pY - view.getY(), 2));

        TranslateAnimation animation = new TranslateAnimation(0, pX - view.getX(), 0, pY - view.getY());

        try {
            animation.setDuration((long) (distance * 100 / Card.width));
        } catch (ArithmeticException e) {
            animation.setDuration(200);
            Log.e("Animate moveCard()", e.toString());
        }

        animation.setFillEnabled(true);

        view.setDestination(pX, pY);
        view.startAnimation(animation);
    }


    public void moveCard(final Card card, final float pX, final float pY) {
        final CustomImageView view = card.view;
        int distance = (int) Math.sqrt(Math.pow(pX - view.getX(), 2) + Math.pow(pY - view.getY(), 2));

        TranslateAnimation animation = new TranslateAnimation(0, pX - view.getX(), 0, pY - view.getY());

        //there were some reports about an exception here, so simply set duration with a fixed value
        //if the exception occurs
        try {
            animation.setDuration((long) (distance * 100 / Card.width / speedFactor));
        } catch (ArithmeticException e) {
            animation.setDuration(100);
            Log.e("Animate moveCard()", e.toString());
        }

        animation.setFillEnabled(true);

        view.setDestination(pX, pY);
        view.startAnimation(animation);
    }

    public boolean cardIsAnimating() {
        for (Card card : cards) {
            if (card.view.isAnimating()) {
                return true;
            }
        }

        return false;
    }

    public void reset() {
        for (Card card : cards) {
            card.view.stopAnim();
        }
    }


    public void flipCard(final Card card, final boolean mode) {
        AnimatorSet shrinkSet = (AnimatorSet) AnimatorInflater.loadAnimator(
                gm, R.animator.card_to_middle);
        shrinkSet.addListener(new Animator.AnimatorListener() {
            public void onAnimationStart(Animator animation) {
            }

            public void onAnimationEnd(Animator animation) {
                flipCard2(card, mode);
            }

            public void onAnimationCancel(Animator animation) {
            }

            public void onAnimationRepeat(Animator animation) {
            }
        });

        shrinkSet.setTarget(card.view);
        shrinkSet.start();
    }


    private void flipCard2(final Card card, final boolean mode) {
        AnimatorSet growSet = (AnimatorSet) AnimatorInflater.loadAnimator(
                gm, R.animator.card_from_middle);
        growSet.addListener(new Animator.AnimatorListener() {
            public void onAnimationStart(Animator animation) {
                if (mode)   //flip up
                    card.setCardFront();
                else //flip down
                    card.setCardBack();
            }

            public void onAnimationEnd(Animator animation) {
            }

            public void onAnimationCancel(Animator animation) {
            }

            public void onAnimationRepeat(Animator animation) {
            }
        });

        growSet.setTarget(card.view);
        growSet.start();
    }


    public void showAutoCompleteButton() {
        Animation fade_in = AnimationUtils.loadAnimation(
                gm.getApplicationContext(), R.anim.button_fade_in);

        fade_in.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationStart(Animation animation) {

                gm.buttonAutoComplete.setVisibility(View.VISIBLE);
            }

            public void onAnimationEnd(Animation animation) {
            }

            public void onAnimationRepeat(Animation animation) {
            }
        });

        gm.buttonAutoComplete.startAnimation(fade_in);
    }
}