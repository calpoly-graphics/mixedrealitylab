
package ch.neilmfren.solitaire.helper;

import android.os.Bundle;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.HelperCardMovement;
import ch.neilmfren.solitaire.games.Pyramid;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.currentGame;
import static ch.neilmfren.solitaire.SharedData.gameLogic;
import static ch.neilmfren.solitaire.SharedData.movingCards;
import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.showToast;



public class AutoMove extends HelperCardMovement {

    private boolean testAfterMove = false;
    private boolean movedFirstCard = false;
    private boolean mainStackAlreadyFlipped = false;

    public AutoMove(GameManager gm){
        super(gm,"AUTO_MOVE");
    }

    @Override
    public void start(){
        movedFirstCard = false;
        testAfterMove = false;
        mainStackAlreadyFlipped = false;

        super.start();
    }

    @Override
    protected void saveState(Bundle bundle) {
    }

    @Override
    protected void loadState(Bundle bundle) {
    }

    @Override
    protected boolean stopCondition() {
        return gameLogic.hasWon() || currentGame.winTest();
    }

    @Override
    protected void moveCard() {

        if (testAfterMove) {
            currentGame.testAfterMove();
            testAfterMove = false;
            nextIteration();
        }
        else {
            CardAndStack cardAndStack = currentGame.hintTest();

            if (cardAndStack != null) {
                mainStackAlreadyFlipped = false;
                movedFirstCard = true;
                movingCards.reset();

                //needed because in Pyramid, I save in cardTest() if cards need to move to the waste stack
                //TODO manage this in another way
                if (currentGame instanceof Pyramid){
                    currentGame.cardTest(cardAndStack.getStack(),cardAndStack.getCard());
                }

                movingCards.add(cardAndStack.getCard(), 0, 0);
                movingCards.moveToDestination(cardAndStack.getStack());

                testAfterMove = true;
                nextIteration();
            }
            else if (prefs.getImproveAutoMove() && currentGame.hasMainStack()) {
                switch (currentGame.mainStackTouch()){
                    case 0:
                        stop();
                    case 1:
                        testAfterMove = true;
                        nextIteration();
                        break;
                    case 2:
                        if (mainStackAlreadyFlipped) {
                            stop();
                        } else {
                            mainStackAlreadyFlipped = true;
                            testAfterMove = true;
                            nextIteration();
                        }
                        break;
                }
            }
            else {
                if (!movedFirstCard) {
                    showToast(gm.getString(R.string.dialog_no_movement_possible),gm);
                }

                stop();
            }
        }
    }
}
