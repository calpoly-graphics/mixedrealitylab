package ch.neilmfren.solitaire;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.BulletSpan;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

import ch.neilmfren.solitaire.classes.WaitForAnimationHandler;
import ch.neilmfren.solitaire.helper.AutoMove;
import ch.neilmfren.solitaire.helper.BackgroundMusic;
import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.games.Game;
import ch.neilmfren.solitaire.helper.Animate;
import ch.neilmfren.solitaire.helper.AutoComplete;
import ch.neilmfren.solitaire.helper.Bitmaps;
import ch.neilmfren.solitaire.helper.CardHighlight;
import ch.neilmfren.solitaire.helper.DealCards;
import ch.neilmfren.solitaire.helper.EnsureMovability;
import ch.neilmfren.solitaire.helper.GameLogic;
import ch.neilmfren.solitaire.helper.Hint;
import ch.neilmfren.solitaire.helper.MovingCards;
import ch.neilmfren.solitaire.helper.Preferences;
import ch.neilmfren.solitaire.helper.RecordList;
import ch.neilmfren.solitaire.helper.Scores;
import ch.neilmfren.solitaire.helper.Sounds;
import ch.neilmfren.solitaire.helper.Timer;



public class SharedData {

    public final static int OPTION_UNDO = 1, OPTION_NO_RECORD = 2, OPTION_REVERSED_RECORD = 3;

    //Strings
    public static String GAME = "game";
    public static String RESTART_DIALOG = "dialogRestart";
    public static String WON_DIALOG = "dialogWon";


    public static Game currentGame;

    public static Card[] cards;
    public static Stack[] stacks;

    public static Preferences prefs;
    public static Scores scores;

    public static GameLogic gameLogic;
    public static Animate animate;

    public static AutoComplete autoComplete;
    public static Timer timer;
    public static Sounds sounds;
    public static RecordList recordList;
    public static AutoMove autoMove;
    public static Hint hint;
    public static DealCards dealCards;

    public static WaitForAnimationHandler handlerTestIfWon;
    public static WaitForAnimationHandler handlerTestAfterMove;

    public static MovingCards movingCards = new MovingCards();
    public static LoadGame lg = new LoadGame();
    public static Bitmaps bitmaps = new Bitmaps();
    public static CardHighlight cardHighlight = new CardHighlight();
    public static BackgroundMusic backgroundSound = new BackgroundMusic();
    public static EnsureMovability ensureMovability;

    public static int activityCounter = 0;
    public static boolean stopUiUpdates = false;
    public static boolean isDialogVisible = false;

    private static Toast toast;


    public static void reinitializeData(Context context) {
        //Bitmaps
        if (!bitmaps.checkResources()) {
            bitmaps.setResources(context.getResources());
        }

        if (prefs == null){
            prefs = new Preferences(context);
        }

        if (lg.getGameCount()==0){
            lg.loadAllGames();
        }


    }


    public static void moveToStack(Card card, Stack destination) {
        moveToStack(card, destination, 0);
    }


    public static void moveToStack(Card card, Stack destination, int option) {
        ArrayList<Card> cards = new ArrayList<>();
        cards.add(card);

        ArrayList<Stack> destinations = new ArrayList<>();
        destinations.add(destination);

        moveToStack(cards, destinations, option);
    }


    public static void moveToStack(ArrayList<Card> cards, Stack destination) {
        moveToStack(cards, destination, 0);
    }


    public static void moveToStack(ArrayList<Card> cards, Stack destination, int option) {
        ArrayList<Stack> destinations = new ArrayList<>();

        for (int i = 0; i < cards.size(); i++)
            destinations.add(destination);

        moveToStack(cards, destinations, option);
    }

    public static void moveToStack(ArrayList<Card> cards, ArrayList<Stack> destinations) {
        moveToStack(cards, destinations, 0);
    }


    public static void moveToStack(ArrayList<Card> cards, ArrayList<Stack> destinations, int option) {

        if (!stopUiUpdates) {
            if (option == OPTION_UNDO) {
                scores.undo(cards, destinations);
            } else if (option == 0) {
                scores.move(cards, destinations);
                recordList.add(cards);
            } else if (option == OPTION_REVERSED_RECORD) {
                //reverse the cards and add the reversed list to the record
                ArrayList<Card> cardsReversed = new ArrayList<>();

                for (int i = 0; i < cards.size(); i++) {
                    cardsReversed.add(cards.get(cards.size() - 1 - i));
                }

                recordList.add(cardsReversed);
                scores.move(cards, destinations);
            }
            //else if (option == OPTION_NO_RECORD), do nothing
        }


        for (int i = 0; i < cards.size(); i++) {
            //this means to flip a card
            if (cards.get(i).getStack() == destinations.get(i)) {
                cards.get(i).flip();
            }
        }

        for (int i = 0; i < cards.size(); i++) {
            if (cards.get(i).getStack() != destinations.get(i)) {
                cards.get(i).removeFromCurrentStack();
                destinations.get(i).addCard(cards.get(i));
            }
        }

        for (Stack stack : destinations){
            stack.updateSpacing();
        }

        for (Card card : cards) {
            card.bringToFront();
        }

        //following stuff in handlers, because they should wait until possible card movements are over.
        if (option == 0 && !stopUiUpdates) {
            handlerTestAfterMove.sendDelayed();
        }
    }


    public static void logText(String text) {
        Log.e("hey", text);
    }

    public static int min(int value1, int value2) {
        return value1 < value2 ? value1 : value2;
    }

    public static float min(float value1, float value2) {
        return value1 < value2 ? value1 : value2;
    }

    public static int max(int value1, int value2) {
        return value1 > value2 ? value1 : value2;
    }

    public static float max(float value1, float value2) {
        return value1 > value2 ? value1 : value2;
    }

    public static boolean leftHandedModeEnabled() {
        return prefs.getSavedLeftHandedMode();
    }

    public static boolean isLargeTablet(Context context) {
        return prefs.getSavedForcedTabletLayout() || ((context.getResources().getConfiguration().screenLayout
                        & Configuration.SCREENLAYOUT_SIZE_MASK) >= Configuration.SCREENLAYOUT_SIZE_LARGE);
    }

    public static String stringFormat(String text){
        return String.format(Locale.getDefault(),"%s", text);
    }

    public static int max(ArrayList<Integer> list ){
        int max = 0;

        for (int value : list){
            if (value > max){
                max = value;
            }
        }

        return max;
    }

    public static int min(ArrayList<Integer> list ){
        int min = list.get(0);

        for (int value : list){
            if (value < min){
                min = value;
            }
        }

        return min;
    }

    public static Random getPrng(){
        return new Random();






        //return new SecureRandom();        //or maybe use this
    }


    @SuppressLint("ShowToast")
    public static void showToast(String text, Context context) {
        if (toast == null) {
            toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
        } else
            toast.setText(text);

        toast.show();
    }


    static public CharSequence createBulletParagraph(CharSequence[] strings){

        SpannableString spanns[] = new SpannableString[strings.length];

        //apply the bullet characters
        for (int i=0;i<strings.length;i++){
            spanns[i] = new SpannableString(strings[i] + (i<strings.length-1 ? "\n" : ""));
            spanns[i].setSpan(new BulletSpan(15), 0, strings[i].length(), 0);
        }

        //set up the textView
        return TextUtils.concat(spanns);
    }
}