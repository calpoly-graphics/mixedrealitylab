package ch.neilmfren.solitaire.helper;

import java.util.ArrayList;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.WaitForAnimationHandler;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;



public class RecordList {

    public static int maxRecords;
    public ArrayList<Entry> entries = new ArrayList<>();
    private WaitForAnimationHandler handler;

    private boolean isWorking = false;

    public void reset() {                                                                                  //delete the content on reset
        entries.clear();
    }


    public RecordList(GameManager gm){
        setMaxRecords();

        handler = new WaitForAnimationHandler(gm, new WaitForAnimationHandler.MessageCallBack() {
            @Override
            public void doAfterAnimation() {
                handleMessage();
            }

            @Override
            public boolean additionalHaltCondition() {
                return false;
            }
        });
    }


    public void add(ArrayList<Card> cards) {
        if (entries.size() >= maxRecords) {
            entries.remove(0);
        }

        entries.add(new Entry(cards));
    }


    public void add(ArrayList<Card> cards, Stack origin) {
        if (entries.size() >= maxRecords) {
            entries.remove(0);
        }

        entries.add(new Entry(cards, origin));
    }



    public void add(ArrayList<Card> cards, ArrayList<Stack> origins) {
        if (entries.size() >= maxRecords) {
            entries.remove(0);
        }

        entries.add(new Entry(cards, origins));
    }


    public void addToLastEntry(ArrayList<Card> cards, ArrayList<Stack> origins) {
        if (entries.size() == 0) {
            entries.add(new Entry(cards, origins));
        } else {
            entries.get(entries.size() - 1).addInFront(cards, origins);
        }
    }


    public void addToLastEntry(Card card, Stack origin) {
        ArrayList<Card> cards = new ArrayList<>();
        ArrayList<Stack> origins = new ArrayList<>();

        cards.add(card);
        origins.add(origin);

        addToLastEntry(cards,origins);
    }


    public void undo() {
        if (!entries.isEmpty()) {
            isWorking = true;
            sounds.playSound(Sounds.names.CARD_RETURN);

            if (!prefs.getDisableUndoCosts()) {
                scores.update(-currentGame.getUndoCosts());
            }

            entries.get(entries.size() - 1).undo();

            int amount = prefs.getSavedTotalNumberUndos() + 1;
            prefs.saveTotalNumberUndos(amount);
        }
    }

    public void undoMore() {
        if (!entries.isEmpty()) {
            entries.get(entries.size() - 1).undoMore();
        }
    }


    public void addFlip(Card card) {

        if (entries.size() > 0)
            entries.get(entries.size() - 1).addFlip(card);
    }


    public void save() {
        prefs.saveRecordListEntriesSize(entries.size());

        for (int i = 0; i < entries.size(); i++) {
            entries.get(i).save(Integer.toString(i));
        }
    }


    public void load() {
        reset();

        for (int i = 0; i < prefs.getSavedRecordListEntriesSize(); i++) {
            entries.add(new Entry(Integer.toString(i)));
        }
    }

    public void deleteLast() {
        if (entries.size() > 0) {
            entries.remove(entries.size() - 1);
        }
    }

    public boolean hasMoreToUndo(){
        if (entries.isEmpty()){
            return false;
        }

        if (entries.get(entries.size()-1).hasMoreToDo()){
            return true;
        } else {
            entries.remove(entries.size() - 1);
            isWorking = false;

            //check if the undo movement makes autocomplete undoable
            if (autoComplete.buttonIsShown() && !currentGame.autoCompleteStartTest()) {
                autoComplete.hideButton();
            }

            currentGame.afterUndo();
            return false;
        }
    }

    public boolean isWorking(){
        return isWorking;
    }

    public static class Entry {
        private ArrayList<Integer> moveOrder = new ArrayList<>();
        private ArrayList<Card> currentCards = new ArrayList<>();
        private ArrayList<Stack> currentOrigins = new ArrayList<>();
        private ArrayList<Card> flipCards = new ArrayList<>();

        private boolean alreadyDecremented = false;

        public ArrayList<Card> getCurrentCards(){
            return currentCards;
        }

        public ArrayList<Stack> getCurrentOrigins(){
            return currentOrigins;
        }


        Entry(String pos) {
            ArrayList<Integer> cardList = prefs.getSavedRecordListCards(pos);
            ArrayList<Integer> originList = prefs.getSavedRecordListOrigins(pos);
            ArrayList<Integer> orderList = prefs.getSavedRecordListOrders(pos);

            for (int i = 0; i < cardList.size(); i++) {
                currentCards.add(cards[cardList.get(i)]);
                currentOrigins.add(stacks[originList.get(i)]);

                if (orderList.size()>i){
                    moveOrder.add(orderList.get(i));
                } else {
                    moveOrder.add(0);
                }
            }

            //compatibility to older way of saving: changed from one possible flip card to multiple
            try { //new way
                ArrayList<Integer> flipCardList = prefs.getSavedRecordListFlipCards(pos);

                for (Integer i : flipCardList) {
                    flipCards.add(cards[i]);
                }
            } catch (Exception e) { //old way
                int flipCardID = prefs.getSavedFlipCardId(pos);

                if (flipCardID > 0)
                    addFlip(cards[flipCardID]);
            }
        }


        Entry(ArrayList<Card> cards) {
            currentCards.addAll(cards);

            for (Card card : cards) {
                currentOrigins.add(card.getStack());
                moveOrder.add(0);
            }
        }


        Entry(ArrayList<Card> cards, Stack origin) {
            currentCards.addAll(cards);

            for (int i = 0; i < currentCards.size(); i++) {
                currentOrigins.add(origin);
                moveOrder.add(0);
            }
        }


        Entry(ArrayList<Card> cards, ArrayList<Stack> origins) {
            currentCards.addAll(cards);
            currentOrigins.addAll(origins);

            for (int i = 0; i < currentCards.size(); i++) {
                moveOrder.add(0);
            }
        }


        void save(String pos) {
            ArrayList<Integer> listCards = new ArrayList<>();
            ArrayList<Integer> listFlipCards = new ArrayList<>();
            ArrayList<Integer> listOrigins = new ArrayList<>();

            for (int i = 0; i < currentCards.size(); i++) {
                listCards.add(currentCards.get(i).getId());
                listOrigins.add(currentOrigins.get(i).getId());
            }

            prefs.saveRecordListCards(listCards,pos);
            prefs.saveRecordListOrigins(listOrigins,pos);
            prefs.saveRecordListOrders(moveOrder,pos);

            for (Card card : flipCards) {
                listFlipCards.add(card.getId());
            }

            prefs.saveRecordListFlipCards(listFlipCards,pos);
        }



        void undo() {
            alreadyDecremented = false;

            for (Card card : flipCards) {
                card.flipWithAnim();
            }

            recordList.handler.sendDelayed();
        }


        void undoMore() {
            //Check if the movement resulted in a increment of the redeal counter, if so, revert it
            if (currentGame.hasLimitedRecycles() && !alreadyDecremented)  {
                ArrayList<Stack> discardStacks = currentGame.getDiscardStacks();

                for (int i=0;i<currentCards.size();i++){

                    if (currentCards.get(i).getStack() == currentGame.getDealStack() && discardStacks.contains(currentOrigins.get(i))) {
                        currentGame.decrementRecycleCounter();
                        alreadyDecremented = true;
                        break;
                    }
                }
            }

            ArrayList<Card> cardsWorkCopy = new ArrayList<>();
            ArrayList<Stack> originsWorkCopy = new ArrayList<>();
            ArrayList<Integer> moveOrderWorkCopy = new ArrayList<>();

            int minMoveOrder = min(moveOrder);

            for (int i =0;i<currentCards.size();i++){
                if (moveOrder.get(i) == minMoveOrder) {
                    cardsWorkCopy.add(currentCards.get(i));
                    originsWorkCopy.add(currentOrigins.get(i));
                    moveOrderWorkCopy.add(moveOrder.get(i));
                }
            }

            moveToStack(cardsWorkCopy,originsWorkCopy, OPTION_UNDO);

            for (int i=0;i<cardsWorkCopy.size();i++){
                currentCards.remove(cardsWorkCopy.get(i));
                currentOrigins.remove(originsWorkCopy.get(i));
                moveOrder.remove(moveOrderWorkCopy.get(i));
            }
        }


        void addInFront(ArrayList<Card> cards, ArrayList<Stack> stacks) {
            ArrayList<Card> tempCards = currentCards;
            ArrayList<Stack> tempOrigins = currentOrigins;
            ArrayList<Integer> tempMoveOrders = moveOrder;

            currentCards = new ArrayList<>(cards);
            currentOrigins = new ArrayList<>(stacks);
            moveOrder = new ArrayList<>();

            for (int i=0;i<currentCards.size();i++){
                moveOrder.add(0);
            }

            //Check for each card, if it is already in the entry
            for (int i = 0; i < tempCards.size(); i++) {
                currentCards.add(tempCards.get(i));
                currentOrigins.add(tempOrigins.get(i));
                moveOrder.add(tempMoveOrders.get(i)+1);                                             //increment the orders by one
            }
        }


        void addFlip(Card card) {                                                                   //add a card to flip
            flipCards.add(card);
        }

        boolean hasMoreToDo(){
            return currentCards.size()!=0;
        }
    }

    public void setMaxRecords(){
        maxRecords = prefs.getSavedMaxNumberUndos();

        while (entries.size() > maxRecords) {
            entries.remove(0);
        }
    }

    private void handleMessage(){
        if (recordList.hasMoreToUndo()){
            recordList.undoMore();
            handler.sendDelayed();
        }
    }
}
