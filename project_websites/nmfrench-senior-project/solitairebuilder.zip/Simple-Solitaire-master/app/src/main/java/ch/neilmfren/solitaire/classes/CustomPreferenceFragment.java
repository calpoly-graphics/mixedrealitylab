package ch.neilmfren.solitaire.classes;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.preference.PreferenceFragment;

import static ch.neilmfren.solitaire.SharedData.reinitializeData;



public class CustomPreferenceFragment extends PreferenceFragment {

    @Override
    public void onAttach(Context context) {
        reinitializeData(context);
        super.onAttach(context);
    }

    @Override
    public void onAttach(Activity activity){
        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.M){
            reinitializeData(activity);
        }
        super.onAttach(activity);
    }
}
