package ch.neilmfren.solitaire.classes;

import android.content.Context;



public class CustomImageView extends android.support.v7.widget.AppCompatImageView {

    private boolean animating, moveAtEnd;
    private float destX, destY;

    private boolean isCard, isStack;

    public CustomImageView(Context context) {
        super(context);
    }


    public CustomImageView(Context context, OnTouchListener listener, Object object, int ID) {
        super(context);

        if (listener != null){
            setOnTouchListener(listener);
        }

        setId(ID);

        switch (object) {
            case CARD:
                isCard = true;
                break;
            case STACK:
                isStack = true;
        }
    }

    @Override
    protected void onAnimationStart() {
        super.onAnimationStart();
        animating = true;
    }


    @Override
    protected void onAnimationEnd() {
        super.onAnimationEnd();
        animating = false;

        if (moveAtEnd) {
            moveAtEnd = false;
            clearAnimation();
            setX(destX);
            setY(destY);
        }
    }


    public void setDestination(float pX, float pY) {
        moveAtEnd = true;
        destX = pX;
        destY = pY;
    }

    public void stopAnim() {
        animating = false;
        clearAnimation();
    }

    public boolean isAnimating() {
        return animating;
    }

    public boolean belongsToCard() {
        return isCard;
    }

    public boolean belongsToStack() {
        return isStack;
    }

    public enum Object {
        CARD, STACK
    }
}
