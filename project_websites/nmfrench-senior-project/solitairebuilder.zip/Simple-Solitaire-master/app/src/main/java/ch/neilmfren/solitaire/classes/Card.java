package ch.neilmfren.solitaire.classes;

import android.graphics.Bitmap;
import android.graphics.PointF;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import static ch.neilmfren.solitaire.SharedData.*;



public class Card {

    public enum movements {INSTANT, NONE, DEFAULT}
    public static int width, height;                                                                //width and height calculated in relation of the screen dimensions in Main activity
    public static Bitmap background;
    private static Bitmap[] drawables = new Bitmap[52];
    public CustomImageView view;                                                                    //the image view of the card, for easier code not private
    private int color;                                                                              //1=clubs 2=hearts 3=Spades 4=diamonds
    private int value;                                                                              //1=ace 2,3,4,5,6,7,8,9,10, 11=joker 12=queen 13=king
    private Stack stack;                                                                            //saves the stack where the card is placed
    private int id;                                                                                 //internal id
    private boolean isUp;                                                                           //indicates if the card is placed upwards or backwards
    private boolean isInvisible;
    private PointF oldLocation = new PointF();                                                      //old location so cards can be moved back if they can't placed on a new stack

    public static int ACE = 1;
    public static int JOKER = 11;
    public static int QUEEN = 12;
    public static int KING = 13;

    //no enum, I want to explicitly set the values, because they are saved in the sharedPref and
    private static final int STATE_FACED_DOWN = 0;
    public static final int STATE_FACED_UP = 1;
    public static final int STATE_INVISBLE = 2;


    public Card(int id) {
        this.id = id;
        color = currentGame.cardDrawablesOrder[(id % 52) / 13];
        value = (id % 13) + 1;
    }

    public void setImageBitmap(Bitmap bitmap){
        if (!stopUiUpdates){
            view.setImageBitmap(bitmap);
        }
    }


    public static void updateCardDrawableChoice() {
        boolean fourColors = prefs.getSavedFourColorMode();

        for (int i = 0; i < 13; i++) {
            drawables[i] = bitmaps.getCardFront(i, fourColors ? 1 : 0);
            drawables[13 + i] = bitmaps.getCardFront(i, 2);
            drawables[26 + i] = bitmaps.getCardFront(i, 3);
            drawables[39 + i] = bitmaps.getCardFront(i, fourColors ? 5 : 4);
        }

        if (cards == null) {
            return;
        }

        for (Card card : cards) {
            if (card.isUp()) {
                card.setCardFront();
            }
        }
    }


    public static void updateCardBackgroundChoice() {
        int positionX = prefs.getSavedCardBackground();
        int positionY = prefs.getSavedCardBackgroundColor();
        background = bitmaps.getCardBack(positionX, positionY);

        if (cards == null) {
            return;
        }

        for (Card card : cards) {
            if (!card.isUp()) {
                card.setCardBack();
            }
        }
    }


    public static void save() {
        List<Integer> list = new ArrayList<>(cards.length);

        for (Card card : cards) {
            int state = card.isUp ? STATE_FACED_UP : STATE_FACED_DOWN;

            if (card.isInvisible){
                state = STATE_INVISBLE;
            }

            list.add(state);
        }

        prefs.saveCards(list);
    }


    public static void load() {
        List<Integer> list = prefs.getSavedCards();

        for (int i = 0; i < cards.length; i++) {
            switch (list.get(i)){
                case STATE_FACED_UP:
                    cards[i].flipUp();
                    break;
                case STATE_FACED_DOWN:
                    cards[i].flipDown();
                    break;
                case STATE_INVISBLE:
                    cards[i].view.setVisibility(View.GONE);
                    cards[i].isInvisible = true;
                    //cards[i].removeFromGame();
                    break;
            }
        }
    }


    public void setCardFront() {
        setImageBitmap(drawables[(color - 1) * 13 + value - 1]);
    }


    public void setCardBack() {
        setImageBitmap(background);
    }


    public void setColor() {
        color = currentGame.cardDrawablesOrder[(id % 52) / 13];
    }


    public void setLocation(float pX, float pY) {

        if (isInvisible){
            setLocationWithoutMovement(pX, pY);
        }

        if (!stopUiUpdates) {
            if (view.getX() != pX || view.getY() != pY) {
                animate.moveCard(this, pX, pY);
            }
        }
    }


    public void setLocationWithoutMovement(float pX, float pY) {
        if (!stopUiUpdates) {
            view.bringToFront();
            view.setX(pX);
            view.setY(pY);
        }
    }


    public void saveOldLocation() {
        oldLocation.x = view.getX();
        oldLocation.y = view.getY();
    }


    public void returnToOldLocation() {
        view.setX(oldLocation.x);
        view.setY(oldLocation.y);
    }


    public void flipUp() {
        isUp = true;

        if (!stopUiUpdates) {
            setCardFront();
        }
    }


    public void flipDown() {
        isUp = false;

        if (!stopUiUpdates) {
            setCardBack();
        }
    }


    public void flip() {
        if (isUp())
            flipDown();
        else
            flipUp();
    }


    public void flipWithAnim() {
        if (isUp()) {
            isUp = false;
            //sounds.playSound(Sounds.names.CARD_FLIP_BACK);
            scores.undo(this, getStack());

            if (!stopUiUpdates) {
                animate.flipCard(this, false);
            }
        } else {
            isUp = true;
            //sounds.playSound(Sounds.names.CARD_FLIP);
            scores.move(this, getStack());
            recordList.addFlip(this);

            if (!stopUiUpdates) {
                animate.flipCard(this, true);
            }
        }
    }


    public boolean test(Stack destination) {
        if (prefs.isDeveloperOptionMoveCardsEverywhereEnabled()){
            return true;
        }

        return !((!isUp() || (destination.getSize() != 0 && !destination.getTopCard().isUp())) && !autoComplete.isRunning()) && currentGame.cardTest(destination, this);
    }

    public int getColor() {
        return color;
    }

    public boolean isTopCard() {
        return getStack().getTopCard() == this;
    }

    public boolean isFirstCard() {
        return getStack().getCard(0) == this;
    }

    public int getIndexOnStack() {
        return getStack().getIndexOfCard(this);
    }

    public boolean isUp() {                                                                         //returns if the card is up
        return isUp;
    }

    public int getId() {
        return id;
    }

    public int getValue() {
        return value;
    }

    public Stack getStack() {
        return stack;
    }

    public void setStack(Stack stack) {
        this.stack = stack;
    }

    public float getX() {
        return view.getX();
    }

    public void setX(float X) {
        view.setX(X);
    }

    public float getY() {
        return view.getY();
    }

    public void setY(float Y) {
        view.setY(Y);
    }

    public int getStackId() {
        return stack.getId();
    }

    public boolean isInvisible(){
        return isInvisible;
    }

    public void removeFromCurrentStack(){
        if (stack!=null) {
            stack.removeCard(this);
            stack = null;
        }
    }

    public Card getCardOnTop(){
        if (getIndexOnStack() < stack.getSize() -1){
            return stack.getCard(getIndexOnStack()+1);
        } else {
            return this;
        }
    }

    public Card getCardBelow(){
        return getIndexOnStack() == 0 ? this : stack.getCard(getIndexOnStack()-1);
    }

    public void bringToFront(){
        if (!stopUiUpdates){
            view.bringToFront();
        }
    }

    public void removeFromGame(){
        view.setVisibility(View.GONE);
        isInvisible = true;
        moveToStack(this, currentGame.offScreenStack);
    }

    public void addBackToGame(Stack moveTo){
        isInvisible = false;
        flipUp();
        view.setVisibility(View.VISIBLE);
        moveToStack(this, moveTo);
    }
}