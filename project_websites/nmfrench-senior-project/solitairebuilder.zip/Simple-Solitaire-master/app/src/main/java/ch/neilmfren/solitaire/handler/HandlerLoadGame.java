package ch.neilmfren.solitaire.handler;

import android.os.Handler;
import android.os.Message;

import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;



public class HandlerLoadGame extends Handler {

    public void handleMessage(Message msg) {
        super.handleMessage(msg);
        gameLogic.load(false);
    }
}
