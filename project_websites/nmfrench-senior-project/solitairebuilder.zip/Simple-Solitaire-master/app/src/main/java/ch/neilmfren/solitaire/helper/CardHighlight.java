package ch.neilmfren.solitaire.helper;

import android.view.View;
import android.widget.RelativeLayout;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.games.Game;
import ch.neilmfren.solitaire.ui.GameManager;

import static android.view.View.GONE;



public class CardHighlight {


    int padding, width, height;
    private boolean moveStarted;


    public void set(GameManager gm, Card card) {
        Stack stack = card.getStack();

        padding = (int) (Card.width * 0.25);
        width = Card.width + padding;
        height = (int) (stack.getTopCard().getY() + Card.height - card.getY() + padding);

        gm.highlight.setLayoutParams(new RelativeLayout.LayoutParams(width, height));
        gm.highlight.setX(card.getX() - padding / 2);
        gm.highlight.setY(card.getY() - padding / 2);
        gm.highlight.setVisibility(View.VISIBLE);
        gm.highlight.bringToFront();

        for (int i = card.getIndexOnStack(); i < stack.getSize(); i++) {
            stack.getCard(i).bringToFront();
        }

        moveStarted = false;
    }


    public void move(GameManager gm, Card card) {
        if (!moveStarted) {
            moveStarted = true;

            height = (int) (card.getStack().getTopCard().getY() + Card.height - card.getY() + padding);
            gm.highlight.setLayoutParams(new RelativeLayout.LayoutParams(width, height));
        }

        gm.highlight.setX(card.getX() - padding / 2);
        gm.highlight.setY(card.getY() - padding / 2);
    }

    public void hide(GameManager gm) {
        gm.highlight.setVisibility(GONE);
    }
}
