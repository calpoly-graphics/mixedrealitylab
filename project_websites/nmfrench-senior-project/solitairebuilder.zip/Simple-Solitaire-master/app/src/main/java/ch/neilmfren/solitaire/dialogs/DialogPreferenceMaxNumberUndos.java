package ch.neilmfren.solitaire.dialogs;

import android.content.Context;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogPreference;

import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.showToast;
import static ch.neilmfren.solitaire.SharedData.stringFormat;



public class DialogPreferenceMaxNumberUndos extends CustomDialogPreference {

    private EditText input;

    public DialogPreferenceMaxNumberUndos(Context context, AttributeSet attrs) {
        super(context, attrs);
        setDialogLayoutResource(R.layout.dialog_max_number_undos);
        setDialogIcon(null);
    }

    @Override
    protected void onBindDialogView(View view) {
        input = (EditText) view.findViewById(R.id.settings_max_number_undos_input);

        input.setText(stringFormat(Integer.toString(prefs.getSavedMaxNumberUndos())));


        super.onBindDialogView(view);
    }



    @Override
    protected void onDialogClosed(boolean positiveResult) {
        // When the user selects "OK", persist the new value
        if (positiveResult) {
            try {
                //Saving zero would cause force closes, so just catch it here
                if (Integer.parseInt(input.getText().toString()) < 1) {
                    showToast(getContext().getString(R.string.settings_number_input_error),getContext());
                    return;
                }

                prefs.saveMaxNumberUndos(Integer.parseInt(input.getText().toString()));
            } catch (Exception e){
                showToast(getContext().getString(R.string.settings_number_input_error),getContext());
            }
        }
    }
}
