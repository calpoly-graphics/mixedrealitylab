package ch.neilmfren.solitaire.helper;

import android.os.Bundle;

import java.util.ArrayList;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.HelperCardMovement;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;



public class Hint extends HelperCardMovement{

    private static final int MAX_NUMBER_OF_HINTS = 3;                                               //max number of hints which are shown when pressing the button

    private int counter = 0;                                                                        //counter to know how many hints were shown
    private boolean showedFirstHint = false;
    private ArrayList<Card> visited = new ArrayList<>(MAX_NUMBER_OF_HINTS);                         //array for already shown cards in hint

    public Hint(GameManager gm){
        super(gm, "HINT");
    }

    @Override
    public void start() {
        showedFirstHint = false;
        visited.clear();
        counter = 0;

        super.start();
    }

    @Override
    protected void saveState(Bundle bundle) {
        bundle.putInt("BUNDLE_HINT_COUNTER",counter);

        ArrayList<Integer> list = new ArrayList<>(visited.size());

        for (Card card: visited){
            list.add(card.getId());
        }

        bundle.putIntegerArrayList("BUNDLE_HINT_VISITED", list);
    }

    @Override
    protected void loadState(Bundle bundle) {
        counter = bundle.getInt("BUNDLE_HINT_COUNTER");
        ArrayList<Integer> list = bundle.getIntegerArrayList("BUNDLE_HINT_VISITED");

        visited.clear();

        if (list != null) {
            for (Integer i : list) {
                visited.add(cards[i]);
            }
        }
    }


    private void makeHint(Card card, Stack destination) {
        Stack origin = card.getStack();
        int index = origin.getIndexOfCard(card);
        ArrayList<Card> currentCards = new ArrayList<>();

        if (counter == 0 && !prefs.getDisableHintCosts()) {
            scores.update(-currentGame.getHintCosts());
        }

        visited.add(card);

        for (int i = index; i < origin.getSize(); i++) {
            currentCards.add(origin.getCard(i));
        }

        for (int i = 0; i < currentCards.size(); i++) {
            animate.cardHint(currentCards.get(i), i, destination);
        }
    }

    @Override
    protected boolean stopCondition() {
        return counter >= Hint.MAX_NUMBER_OF_HINTS;
    }

    protected void moveCard(){

        CardAndStack cardAndStack = currentGame.hintTest(visited);

        if (cardAndStack == null) {
            if (!showedFirstHint){
                showToast(gm.getString(R.string.dialog_no_hint_available),gm);
            }

            stop();
        }
        else {
            if (!showedFirstHint) {
                sounds.playSound(Sounds.names.HINT);
                showedFirstHint = true;

                int amount = prefs.getSavedTotalHintsShown() + 1;
                prefs.saveTotalHintsShown(amount);
            }

            makeHint(cardAndStack.getCard(), cardAndStack.getStack());
            counter++;
            nextIteration();
        }
    }


}