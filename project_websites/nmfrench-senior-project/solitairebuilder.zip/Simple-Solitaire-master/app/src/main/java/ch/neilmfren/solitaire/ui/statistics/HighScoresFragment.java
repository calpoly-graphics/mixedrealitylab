package ch.neilmfren.solitaire.ui.statistics;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.helper.Scores;

import static ch.neilmfren.solitaire.SharedData.currentGame;
import static ch.neilmfren.solitaire.SharedData.scores;



public class HighScoresFragment extends Fragment{

    private String dollar;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_statistics_tab2, container, false);

        //if the app got killed while the statistics are open and then the user restarts the app,
        //my helper classes aren't initialized so they can't be used. In this case, simply
        //close the statistics
        try {
            loadData();
        } catch (NullPointerException e) {
            getActivity().finish();
            return view;
        }

        TableLayout tableLayout = (TableLayout) view.findViewById(R.id.statisticsTableHighScores);
        TextView textNoEntries = (TextView) view.findViewById(R.id.statisticsTextNoEntries);

        if (scores.getHighScore(0, 0) != 0) {
            textNoEntries.setVisibility(View.GONE);
        }

        for (int i = 0; i < Scores.MAX_SAVED_SCORES; i++) {                                         //for each entry in highScores, add a new view with it
            if (scores.getHighScore(i, 0) == 0) {                                                //if the score is zero, don't show it
                continue;
            }

            TableRow row = (TableRow) LayoutInflater.from(getContext()).inflate(R.layout.statistics_scores_row, null);

            TextView textView1 = (TextView) row.findViewById(R.id.row_cell_1);
            TextView textView2 = (TextView) row.findViewById(R.id.row_cell_2);
            TextView textView3 = (TextView) row.findViewById(R.id.row_cell_3);
            TextView textView4 = (TextView) row.findViewById(R.id.row_cell_4);

            textView1.setText(String.format(Locale.getDefault(),"%s %s", scores.getHighScore(i, 0),dollar));
            long time = scores.getHighScore(i, 1);
            textView2.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d",time / 3600, (time % 3600) / 60, (time % 60)));
            textView3.setText(DateFormat.getDateInstance(DateFormat.SHORT).format(scores.getHighScore(i, 2)));
            textView4.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(scores.getHighScore(i, 2)));

            tableLayout.addView(row);
        }

        return view;
    }


    private void loadData() {
        dollar = currentGame.isPointsInDollar() ? "$" : "";
    }
}