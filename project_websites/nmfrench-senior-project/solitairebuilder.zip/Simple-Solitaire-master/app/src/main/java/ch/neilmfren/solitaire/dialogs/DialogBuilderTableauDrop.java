package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogFragment;
import ch.neilmfren.solitaire.ui.builder.Builder;

public class DialogBuilderTableauDrop extends CustomDialogFragment {


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        final Builder parentActivity = (Builder) getActivity();

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        final View inflatedView = getActivity().getLayoutInflater().inflate(R.layout.dialog_tableau_creator, (ViewGroup) getView());

        builder.setTitle("Enter tableau details here")
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Spinner emptySpinner = (Spinner) inflatedView.findViewById(R.id.table_builder_empty_spinner);
                        String selectedEmpty = emptySpinner.getSelectedItem().toString();

                        Spinner nonEmptySpinner = (Spinner) inflatedView.findViewById(R.id.table_builder_not_empty_spinner);
                        String selectedNonEmpty = nonEmptySpinner.getSelectedItem().toString();


                        Log.d("SPINNER", selectedEmpty + ", " + selectedNonEmpty);
                    }
                })
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //TODO cancel
                    }
                });

        builder.setView(inflatedView);

        return applyFlags(builder.create());
    }
}
