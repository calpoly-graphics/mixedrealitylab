package ch.neilmfren.solitaire.games;

import android.content.Context;
import android.widget.RelativeLayout;

import java.util.ArrayList;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;
import static ch.neilmfren.solitaire.classes.Stack.ArrowDirection.LEFT;
import static ch.neilmfren.solitaire.games.Game.testMode.ALTERNATING_COLOR;
import static ch.neilmfren.solitaire.games.Game.testMode.SAME_FAMILY;
import static ch.neilmfren.solitaire.games.Game.testMode2.*;
import static ch.neilmfren.solitaire.games.Game.testMode3.ASCENDING;
import static ch.neilmfren.solitaire.games.Game.testMode3.DESCENDING;



@SuppressWarnings("all")
public class DummyGame extends Game {


    public DummyGame() {
        //set how may cards you need. One deck contains 52 cards
        setNumberOfDecks(1);

        //set how many stacks you have, the array will be initialized with the given value
        setNumberOfStacks(13);

        //if you game has a main stack, set its id here. Cards will be automatically dealt from there.
        setMainStackIDs(12);

        //if there is a discard stack, set it's id, because I need the id for the undo movement
        //(cards should be faced up when returning to discard)
        setDiscardStackIDs(11);

        //if your game has NO main stack, set where the cards are dealt from
        setDealFromID(1);

        //set the tableau. All cards from stacks 0 to the last tableau stack
        //are stacked with an offset, so you can see every card on it.
        //Every card on a stack with a higher id will be put exactly on the stacks coordinates,
        //without an offset.
        setLastTableauID(6);

        //use this to set your card families in the following way:
        //1=clubs 2=hearts 3=spades 4=diamonds
        //if you don't call it, the default will be used: 1,2,3,4.
        //if you have more than one deck, the following decks are set the same way
        //for example: in Spider I want to set the difficulty: Easy would mean
        //every family is the same color, so I use this:
        setCardFamilies(1, 1, 1, 1);

        //you can set up how the cards on a stack are stacked. With an offset to the right, down and so on
        //Put an int array with values for each stack that should getHighScore a direction
        //int value at array pos 0 will be assigned to stack[0] and so on
        //tableau stacks are set to "down" by default, so you don't need to call this method for them
        //but if you use this method, don't forget to set the tableau stacks to "1" again
        //
        //the directions are:
        // 0 no visible offset (like the main stacks)
        // 1 down (like every tableau stack)
        // 2 up
        // 3 left (like the discard stack on Golf
        // 4 right (like the stack on golf in left handed mode
        setDirections(new int[]{1, 1, 1, 0, 0, 1, 1, 3});

        //use this if the cards on a stack should'nt overlap another stack (if the other stack is in the stacking direction.
        //Pass the id of the other stack in the array. A 1 on index 0 means, that stacks[0] should'nt overlap stacks[1].
        // A -1 stands for no border, so the border will be the screen width/height
        setDirectionBorders(new int[]{1, 1, 1, -1, -1});

        //sets an arrow as the background of a stack, use the constants LEFT and RIGHT for the direction.
        //it will automatically flip the direction, if left handed mode is enabled
        setArrow(stacks[1], LEFT);

        //if your game needs to have limited recycles, so after a few tries of moving the cards from
        //the discard stack back to the main stack, it won't be possible anymore, use this method
        //It will automatically show the remaining recycles on the main stack.
        setLimitedRecycles(5);

        //if you used setLimitedRecycles(), you can also use toggleRecycles like this to disable the limitation
        //from the settings

    }


    private void methodsYouCanUse() {

        //test the cards of a given stack from the gives index up to top if the cards are in the
        //right order. Use for the card order the constants SAME_FAMILIY, SAME_COLOR or ALTERNATING_COLOR
        testCardsUpToTop(stacks[5], 5, testMode.SAME_FAMILY);

        //used in movements: detect if the top card on the given stack is equal to the give card.
        //you can use this for example to test in a hint: do not show hints if the card on the other
        //stack has the same value/color, because that would be useless.
        //You can use the constants SAME_VALUE_AND_COLOR and SAME_VALUE_AND_FAMILY
        sameCardOnOtherStack(cards[5], stacks[2], SAME_VALUE_AND_COLOR);

        //use this
        canCardBePlaced(stacks[2], cards[2], ALTERNATING_COLOR, DESCENDING);

        canCardBePlaced(stacks[2], cards[2], SAME_FAMILY, ASCENDING);

        //BEFORE USING THESE METHODS:
        //you have to call setNumberOfDecks() in the constructor, or else the returned classes aren't
        //initialized yet

        //return the mainStack
        getMainStack();

        //return the last tableau stack or it's id
        getLastTableauId();
        getLastTableauStack();

        //return the stack, where cards are dealt from
        getDealStack();

        //return the discard stack
        getDiscardStack();
    }


    public void setStacks(RelativeLayout layoutGame, boolean isLandscape, Context context) {

        //use this to set the cards width according to last two values.
        //second last is for portrait mode, last one for landscape.
        //the layout width will be divided by these values according to orientation to use as card widths.
        //Card height is 1.5*widht and the dimensions are applied to every card and stack
        //
        //use values as +1, +2 added to the number of stacks in the longest row of your layout, so there is
        //enough space left to use as spacing between the stacks.
        setUpCardWidth(layoutGame, isLandscape, 7 + 1, 7 + 2);

        //use this to automatically set up the dimensions (then the call above isn't nessessary).
        //It will take the layout and a value for width and one value for height. The values
        //represent the limiting values for the orientation. For example here: There are 7 rows, so 7
        //stacks have to fit on the horizontal axis, but also 4 cards in the height. The method uses
        //these values to calculate the right dimensions for the cards, so everything fits fine on the screen
        setUpCardDimensions(layoutGame, 7, 4);

        //now we order the stacks on the field. First calculate a spacing variable, to know how much
        //space will be between the stacks. It just uses the layout width minus the number of stacks
        //in a row, divided with the number of spaces between the stacks (which should be the number
        //of stacks +1) It also uses a maximum value of Card.widht/2, so the cards won't be too far apart
        int spacing = setUpHorizontalSpacing(layoutGame, 7, 8);

        //now getHighScore the start position to place the stacks, so they are centered around the middle of
        //the screen. I use this way: Get the half of the layout width, minus how many stacks are on the
        //left to it times the card width, minus how many spacings are left to it times the spacing
        //width. (Do not use the spacing from the left screen edge to the first stack).
        //So it should look like this:
        int startPos = layoutGame.getWidth() / 2 - 3 * Card.width - 3 * spacing;
        //Then set the stack coordinates like this:
        //X cor is the start pos + loop index times (spacing + card width)
        //Y cor can be like in the example code. In landscape use a bit less spacing from the
        //screen edge. The +1 is only so Android Studio doesnt show an error
        for (int i = 0; i < 6; i++) {
            stacks[i].setX(startPos + i * (spacing + Card.width));
            stacks[i].view.setY((isLandscape ? Card.width / 4 : Card.width / 2) + 1);
        }
        //Also set other stacks like the main pile or something
        stacks[6].setX(stacks[0].getX());
        stacks[6].setY(stacks[0].getY() + Card.height + spacing);

        //Last step: Set the drawables of the stacks. Default one is just gray.
        //So maybe show on some a big A for ace or make them transparent or something
        stacks[6].setImageBitmap(Stack.background1);               //shows an A
        stacks[6].setImageBitmap(Stack.backgroundTalon);           //shows a circle arrow
        stacks[6].setImageBitmap(Stack.backgroundTransparent);     //no background at all
    }


    public boolean winTest() {
        //For example on Klondike all foundation stacks have to be full, so everyone of them
        //needs to habe 13 cards. If not, game isn't won yet. If yes, game is won
        for (int i = 7; i <= 10; i++)
            if (stacks[i].getSize() != 13)
                return false;

        return true;
    }


    public void dealCards() {
        //Simple example: Deal the first card from the main stack to another one.
        //Use the OPTION_NO_RECORD, or else the player can undo this movement.
        //After that, flip the card up
        moveToStack(getDealStack().getTopCard(), stacks[0], OPTION_NO_RECORD);
        stacks[0].getTopCard().flipUp();
    }


    @Override
    public boolean testIfMainStackTouched(float X, float Y) {
        return currentGame.getMainStack().isOnLocation(X, Y);
    }


    public int onMainStackTouch() {

        //first test the coordinates if they are really on the main stack.
        //(I put this test here because in Spider Solitaire, the cards from "main" are placed on
        // multiple stacks).
        if (getMainStack().getSize() > 0) {                                                         //if it has cards
            moveToStack(getMainStack().getTopCard(), getDiscardStack());                            //move the card to the discard stack
            return 1;
        }
        //if it empty, do something like move all cards from the discard pile to the main
        // Stack again. In this example from Klondike, the cards are moved in reversed order than
        //they would be movend with the moveToStack(), so I move them one by one and update
        //the recordList and score
        else if (stacks[11].getSize() != 0) {                                                       //if there are cards on stack11 which can be moved
            recordList.add(stacks[11].currentCards);                                                //save the record in normal order

            while (stacks[11].getSize() > 0)                                                        //then place the top card from stack11 to stack12 until it is empty
                moveToStack(stacks[11].getTopCard(), getMainStack(), OPTION_NO_RECORD);

            return 2;
        }

        return 0;
    }


    public boolean cardTest(Stack stack, Card card) {
        //Example from Klondike.

        if (stack.getId() < 7) {                                                                    //tableau stacks
            if (stack.isEmpty()) {                                                                   //if it's empty, you can place a king
                return card.getValue() == 13;
            } else {
                return canCardBePlaced(stack, card, ALTERNATING_COLOR, DESCENDING);                 //Cards on the tableau can be placed in alternating color and descending order
            }
        } else if (stack.getId() < 11 && movingCards.hasSingleCard()) {                             //if its an foundation stack and only one card is moving
            if (stack.isEmpty()) {                                                                  //place if it's an ace
                return card.getValue() == 1;
            } else {
                return canCardBePlaced(stack, card, SAME_FAMILY, ASCENDING);                        //Cards on the foundation can be placed in same family and ascending order
            }
        } else
            return false;
    }


    public boolean addCardToMovementGameTest(Card card) {
        //in case of Klondike it's easy: If a card is faced up, every card on top of it in the stack
        //has the correct order. So return true if a card is up. But because faced down cards aren't even
        //tested here, just return true
        return true;
    }


    public CardAndStack hintTest(ArrayList<Card> visited) {
        //Short example from Klondike
        Card card;                                                                                  //card to test

        for (int i = 0; i <= 6; i++) {                                                              //loop through every stack on the tableau as origin

            Stack origin = stacks[i];                                                               //set the stack as origin

            if (origin.isEmpty() || !origin.getTopCard().isUp())                                    //continue if it's empty or no card is flipped up
                continue;


            card = origin.getTopCard();                                                             //in this part, getHighScore the top card of a stack

            if (!visited.contains(card)) {                                                          //if this card hasn't been visited
                for (int j = 7; j <= 10; j++) {                                                     //loop through every foundation stack as destination
                    if (card.test(stacks[j])) {                                                     //then test

                        return new CardAndStack(card, stacks[j]);
                    }
                }
            }

        }

        return null;
    }


    public boolean autoCompleteStartTest() {
        //Example from Klondike: If every card is faced up, return true. Return false otherwiese
        for (int i = 0; i < 7; i++)
            if (stacks[i].getSize() > 0 && !stacks[i].getCard(0).isUp())
                return false;

        return true;
    }


    public CardAndStack autoCompletePhaseOne() {
        //Example Code: Only game using this is Golf, because the discard stack is no foundation field,
        // the calculation has to be in phase one

        if (!getMainStack().isEmpty()) {
            getMainStack().getTopCard().flipUp();
            return new CardAndStack(getMainStack().getTopCard(), getDiscardStack());
        }

        return null;    //don't forget to return null at the end! so phase two can start
    }


    public CardAndStack autoCompletePhaseTwo() {
        for (int i = 7; i <= 10; i++) {                                                             //foundation fields
            Stack destination = stacks[i];                                                          //getHighScore the destination for more visibility

            for (int j = 0; j <= 6; j++) {                                                          //tableau fields
                Stack origin = stacks[j];                                                           //getHighScore the origin for more visibility

                if (origin.getSize() > 0 && origin.getTopCard().test(destination)) {                //test if there are still cards on it and if the card test is successful
                    return new CardAndStack(origin.getTopCard(), destination);                      //and return
                }
            }

            for (int j = 11; j <= 12; j++) {                                                        //stock
                Stack origin = stacks[j];                                                           //getHighScore the origin for more visibility

                for (int k = 0; k < origin.getSize(); k++) {                                        //loop through every card
                    if (origin.getCard(k).test(destination)) {                                      //then test every card
                        origin.getCard(k).flipUp();                                                 //because cards are from stock, flip up
                        return new CardAndStack(origin.getCard(k), destination);
                    }
                }
            }
        }

        return null;  //don't forget to return null at the end! so the win animation can start
    }


    public int addPointsToScore(ArrayList<Card> cards, int[] originIDs, int[] destinationIDs, boolean isUndoMovement) {
        int originID = originIDs[0];
        int destinationID = destinationIDs[0];

        if ((originID < 7 || originID == 14) && destinationID >= 7 && destinationID <= 10)          //transfer from tableau to foundations
            return 60;
        if ((originID == 11 || originID == 12 || originID == 13) && destinationID < 7)              //stock to tableau
            return 45;
        if (destinationID < 7 && originID >= 7 && originID <= 10)                                   //foundation to tableau
            return -75;
        if (originID == destinationID)                                                              //turn a card over
            return 25;
        if (originID >= 11 && originID < 14 && destinationID == 14)                                 //returning cards to stock
            return -200;

        return 0;
    }


    public void testAfterMove() {
    }


    public void reset() {
        super.reset();
    }



    public Stack doubleTapTest(Card card) {

        //example code from klondike

        //foundation stacks
        if (card.isTopCard()) {
            for (int j = 7; j < 11; j++) {
                if (card.test(stacks[j]))
                    return stacks[j];
            }
        }

        //tableau stacks
        for (int j = 0; j < 7; j++) {

            if (card.getStackId() < 7 && sameCardOnOtherStack(card, stacks[j], SAME_VALUE_AND_COLOR))
                continue;

            if (card.getValue() == 13 && card.isFirstCard() && card.getStackId() <= 6)
                continue;

            if (card.test(stacks[j])) {
                return stacks[j];
            }
        }

        //empty tableau stacks
        for (int j = 0; j < 7; j++) {
            if (stacks[j].isEmpty() && card.test(stacks[j]))
                return stacks[j];
        }

        return null;
    }


    public void save() {

    }

    public void load() {

    }


    //called after undo movement
    public void afterUndo(){
        //check stuff here
    }


    @Override
    protected boolean excludeCardFromMixing(Card card) {


        Stack stack = card.getStack();

        if (!card.isUp()) {
            return false;
        }

        if (foundationStacksContain(stack.getId())){
            return true;
        }

        return false;
    }
}
