package ch.neilmfren.solitaire.games;

import android.content.Context;
import android.util.Log;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.HashMap;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.ui.builder.CustomGame;
import ch.neilmfren.solitaire.ui.builder.CustomView;

import static ch.neilmfren.solitaire.SharedData.OPTION_NO_RECORD;
import static ch.neilmfren.solitaire.SharedData.OPTION_REVERSED_RECORD;
import static ch.neilmfren.solitaire.SharedData.moveToStack;
import static ch.neilmfren.solitaire.SharedData.stacks;

public class FirebaseGame extends Game{

    private CustomGame g;
    private int totalStacks;

    private HashMap<Integer, CustomView> indexToViewMap = new HashMap<>();

    public FirebaseGame(CustomGame g) {
        this.g = g;

        setNumberOfDecks(1);
        setMyStacks();

        setMixingCardsTestMode(null);
        setCardFamilies(1, 2, 3, 4);
    }

    public void setMyStacks() {

        ArrayList<CustomView> tableaus = new ArrayList<>();
        ArrayList<CustomView> foundation = new ArrayList<>();
        ArrayList<CustomView> discard = new ArrayList<>();
        ArrayList<CustomView> main = new ArrayList<>();


        for(CustomView cv : g.getViews()) {
            switch(cv.getType()) {
                case 0:
                    tableaus.add(cv);
                    break;
                case 1:
                    main.add(cv);
                    break;
                case 2:
                    discard.add(cv);
                    break;
                case 3:
                    foundation.add(cv);
                    break;
            }
        }

        int sum = tableaus.size() + foundation.size() + discard.size() + main.size();
        totalStacks = sum;

        Log.d("MAIN_STACK", "Setting number of stacks: " + totalStacks);

        setNumberOfStacks(sum);

        int currOffset = 0;

        if(tableaus.size() > 0) {
            int[] tabs = getIntArray(currOffset, tableaus.size());

            Log.d("FIREBASE_GAME", "Setting last tab id");

            setLastTableauID(tabs[tabs.length - 1]);

            addToMap(tabs, tableaus);

            setTableauStackIDs(tabs);
            currOffset += tableaus.size();


        }

        if(foundation.size() > 0) {
            int[] tabs = getIntArray(currOffset, foundation.size());

            addToMap(tabs, foundation);

            setFoundationStackIDs(tabs);
            currOffset += foundation.size();
        }

        if(discard.size() > 0) {
            int[] tabs = getIntArray(currOffset, discard.size());

            addToMap(tabs, discard);

            setDiscardStackIDs(tabs);
            currOffset += discard.size();
        }

        if(main.size() > 0) {
            int[] tabs = getIntArray(currOffset, main.size());

            addToMap(tabs, main);

            Log.d("MAIN_STACK", "Setting main stack " + tabs[0] + ", " + tabs.length);

            setMainStackIDs(tabs);
            //Log.d("MAIN_STACK", "Main stack: " + ms.getId());

            currOffset += main.size();
        }
    }

    private void addToMap(int[] indices, ArrayList<CustomView> views) {

        for(int i = 0; i < indices.length; i++) {
            indexToViewMap.put(indices[i], views.get(i));
        }

    }

    private int[] getIntArray(int offset, int until) {
        int[] nums = new int[until];

        for(int i = 0; i < until; i++) {
            nums[i] = i + offset;
        }
        return nums;
    }

    @Override
    public void setStacks(RelativeLayout layoutGame, boolean isLandscape, Context context) {

        setUpCardWidth(layoutGame, isLandscape, 7 + 1, 7 + 2);

        double width = layoutGame.getWidth();
        double height = layoutGame.getHeight();

        for(int i = 0; i < totalStacks; i++) {
            CustomView cv = indexToViewMap.get(i);

            stacks[i].setX((float) (cv.getPx() * width));
            stacks[i].setY((float) (cv.getPy() *  height));
        }



    }

    @Override
    public boolean winTest() {
        if(getMainStack().isEmpty()) {
            return true;
        }
        return false;
    }

    @Override
    public void dealCards() {
        Log.d("MAIN_STACK", "DEAL CARDS CALLED");



        for(int i = 0; i < getLastTableauId(); i++) {
            moveToStack(getMainStack().getTopCard(), stacks[i], OPTION_NO_RECORD);
            stacks[i].getCard(0).flipUp();
        }
    }

    @Override
    public boolean cardTest(Stack stack, Card card) {
        if(stack.getId() <= getLastTableauId()) {
            if(stack.isEmpty()) {
                return true;
            } else  {
                return canCardBePlaced(stack, card, testMode.ALTERNATING_COLOR, testMode3.DESCENDING);
            }
        }
        return false;
    }

    @Override
    public boolean addCardToMovementGameTest(Card card) {
        return true;
    }

    @Override
    public CardAndStack hintTest(ArrayList<Card> visited) {
        return null;
    }

    @Override
    public int addPointsToScore(ArrayList<Card> cards, int[] originIDs, int[] destinationIDs, boolean isUndoMovement) {
        return 0;
    }

    @Override
    public int onMainStackTouch() {
        Log.d("MAIN_STACK", "" + getMainStack().getId());


        if(getMainStack().isEmpty()) {
            Log.d("MAIN_STACK", "Main stack is empty");
            return 0;
        }

        Log.d("MAIN_STACK", "TOUCHED MAIN STACK");

        ArrayList<Card> cards = new ArrayList<>();
        ArrayList<Stack> destinations = new ArrayList<>();

        for(int i = 0; i <= getLastTableauId(); i++) {
            Log.d("MAIN_STACK", "i " + i);
            getMainStack().getCardFromTop(i).flipUp();
            cards.add(getMainStack().getCardFromTop(i));
            destinations.add(stacks[i]);
        }

        moveToStack(cards, destinations, OPTION_REVERSED_RECORD);

        return 1;
    }

    @Override
    Stack doubleTapTest(Card card) {
        return null;
    }
}
