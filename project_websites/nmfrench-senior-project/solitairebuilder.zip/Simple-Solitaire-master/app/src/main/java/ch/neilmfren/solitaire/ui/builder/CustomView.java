package ch.neilmfren.solitaire.ui.builder;

public class CustomView {

    private double px;
    private double py;
    private int type;

    // for Firebase serialization
    public CustomView() {}

    public CustomView(int type, double px, double py) {
        this.type = type;
        this.px = px;
        this.py = py;
    }

    public double getPx() {
        return px;
    }

    public void setPx(double px) {
        this.px = px;
    }

    public double getPy() {
        return py;
    }

    public void setPy(double py) {
        this.py = py;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
