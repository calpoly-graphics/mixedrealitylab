package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.SharedData;
import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CustomDialogFragment;
import ch.neilmfren.solitaire.classes.HelperCardMovement;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.helper.EnsureMovability;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.animate;
import static ch.neilmfren.solitaire.SharedData.cards;
import static ch.neilmfren.solitaire.SharedData.ensureMovability;
import static ch.neilmfren.solitaire.SharedData.gameLogic;
import static ch.neilmfren.solitaire.SharedData.logText;
import static ch.neilmfren.solitaire.SharedData.stacks;



public class DialogEnsureMovability extends CustomDialogFragment implements View.OnClickListener{

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_ensure_movability, null);

        Button cancelButton = (Button) view.findViewById(R.id.dialog_ensure_movability_cancel);
        cancelButton.setOnClickListener(this);

        builder.setView(view);
        return applyFlags(builder.create());
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        setCancelable(false);
    }

    @Override
    public void onClick(View view) {
        ensureMovability.stop();
    }

}
