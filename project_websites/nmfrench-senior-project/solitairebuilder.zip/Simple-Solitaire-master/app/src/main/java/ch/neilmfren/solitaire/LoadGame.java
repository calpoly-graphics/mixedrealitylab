package ch.neilmfren.solitaire;

import android.app.Activity;
import android.content.res.Resources;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import ch.neilmfren.solitaire.games.AcesUp;
import ch.neilmfren.solitaire.games.Calculation;
import ch.neilmfren.solitaire.games.Canfield;
import ch.neilmfren.solitaire.games.FirebaseGame;
import ch.neilmfren.solitaire.games.FortyEight;
import ch.neilmfren.solitaire.games.Freecell;
import ch.neilmfren.solitaire.games.Game;
import ch.neilmfren.solitaire.games.Golf;
import ch.neilmfren.solitaire.games.GrandfathersClock;
import ch.neilmfren.solitaire.games.Gypsy;
import ch.neilmfren.solitaire.games.Klondike;
import ch.neilmfren.solitaire.games.Maze;
import ch.neilmfren.solitaire.games.Mod3;
import ch.neilmfren.solitaire.games.NapoleonsTomb;
import ch.neilmfren.solitaire.games.Pyramid;
import ch.neilmfren.solitaire.games.SimpleSimon;
import ch.neilmfren.solitaire.games.Spider;
import ch.neilmfren.solitaire.games.Spiderette;
import ch.neilmfren.solitaire.games.TestGame;
import ch.neilmfren.solitaire.games.TriPeaks;
import ch.neilmfren.solitaire.games.Vegas;
import ch.neilmfren.solitaire.games.Yukon;
import ch.neilmfren.solitaire.ui.builder.CustomGame;

import static ch.neilmfren.solitaire.SharedData. prefs;
import static ch.neilmfren.solitaire.SharedData.reinitializeData;



public class LoadGame {

    private String gameName;
    private String sharedPrefName;
    private ArrayList<AllGameInformation> allGameInformation = new ArrayList<>();
    private ArrayList<CustomGame> customGames = new ArrayList<>();
    private int GAME_COUNT;


    public Game loadClass(Activity activity, int index) {

        sharedPrefName = allGameInformation.get(index).getSharedPrefName();
        gameName = allGameInformation.get(index).getName(activity.getResources());

        Log.d("LOAD_GAME","Trying to start game with index " + index);


        switch (index) {
            case 0: return new AcesUp();
            case 1: return new Calculation();
            case 2: return new Canfield();
            case 3: return new FortyEight();
            case 4: return new Freecell();
            case 5: return new Golf();
            case 6: return new GrandfathersClock();
            case 7: return new Gypsy();
            case 8: return new Klondike();
            case 9: return new Maze();
            case 10: return new Mod3();
            case 11: return new NapoleonsTomb();
            case 12: return new Pyramid();
            case 13: return new SimpleSimon();
            case 14: return new Spider();
            case 15: return new Spiderette();
            case 16: return new TriPeaks();
            case 17: return new Vegas();
            case 18: return new Yukon();
            default:
                return new FirebaseGame(customGames.get(index - 19));
        }
    }


    public void loadAllGames(){
        allGameInformation.clear();

        allGameInformation.add(new AllGameInformation(R.string.games_AcesUp,"AcesUp", false, 40));
        allGameInformation.add(new AllGameInformation(R.string.games_Calculation,"Calculation", false, 30));
        allGameInformation.add(new AllGameInformation(R.string.games_Canfield,"Canfield", false, 40));
        allGameInformation.add(new AllGameInformation(R.string.games_FortyEight,"FortyEight", false, 50));
        allGameInformation.add(new AllGameInformation(R.string.games_Freecell,"Freecell", false, 15));
        allGameInformation.add(new AllGameInformation(R.string.games_Golf,"Golf", true, 40));
        allGameInformation.add(new AllGameInformation(R.string.games_GrandfathersClock,"GrandfathersClock", true, 50));
        allGameInformation.add(new AllGameInformation(R.string.games_Gypsy,"Gypsy", false, 80));
        allGameInformation.add(new AllGameInformation(R.string.games_Klondike,"Klondike", true, 30));
        allGameInformation.add(new AllGameInformation(R.string.games_Maze,"Maze", false, 20));
        allGameInformation.add(new AllGameInformation(R.string.games_mod3,"mod3", true, 70));
        allGameInformation.add(new AllGameInformation(R.string.games_NapoleonsTomb,"NapoleonsTomb", false, 20));
        allGameInformation.add(new AllGameInformation(R.string.games_Pyramid,"Pyramid", true, 40));
        allGameInformation.add(new AllGameInformation(R.string.games_SimpleSimon,"SimpleSimon", false, 25));
        allGameInformation.add(new AllGameInformation(R.string.games_Spider,"Spider", false, 50));
        allGameInformation.add(new AllGameInformation(R.string.games_Spiderette,"Spiderette", false, 30));
        allGameInformation.add(new AllGameInformation(R.string.games_TriPeaks,"TriPeaks", true, 40));
        allGameInformation.add(new AllGameInformation(R.string.games_Vegas,"Vegas", false, 30));
        allGameInformation.add(new AllGameInformation(R.string.games_Yukon,"Yukon", true, 80));
        //allGameInformation.add(new AllGameInformation(R.string.games_Test,"TEST", true, 80));

        if(prefs == null) {
            Log.d("LOAD_GAME", "prefs is null");
        } else {
            Log.d("LOAD_GAME", "prefs not null");
        }

        prefs.clearFirebaseGameCache();



        //int index = allGameInformation.size();

        List<CustomGame> loadedGames = prefs.getFirebaseGameCache();
        customGames.clear();


        if(loadedGames != null) {
            Log.d("LOAD_GAME", "loaded games not null");
            for(CustomGame g : prefs.getFirebaseGameCache()) {
                Log.d("LOAD_GAME", "Adding firebase game to game list, " + g.getViews().size());
                AllGameInformation toAdd = new AllGameInformation(g.getGi().getName(), g.getGi().getName().replaceAll(" ", ""), true, 80);
                allGameInformation.add(toAdd);
                customGames.add(g);
            }
        } else {
            Log.d("LOAD_GAME", "loaded games null");
        }






        Log.d("LOAD_GAME", "Total games: " + allGameInformation.size());

        GAME_COUNT = allGameInformation.size();
    }


    public ArrayList<Integer> getMenuShownList(){
        ArrayList<Integer> result = prefs.getSavedMenuGamesList();

        if (result.size() == 12) {                                                                  //canfield
            result.add(1, 1);
        }
        if (result.size() == 13) {                                                                  //grand fathers clock
            result.add(5, 1);
        }
        if (result.size() == 14) {                                                                  //vegas
            result.add(13, 1);
        }
        if (result.size() == 15) {                                                                  //calculation
            result.add(1, 1);
        }
        if (result.size() == 16) {                                                                  //Napoleons Tomb
            result.add(10, 1);
        }
        if (result.size() == 17) {                                                                  //Maze
            result.add(9, 1);
        }
        if (result.size() == 18) {                                                                  //Spiderette
            result.add(15, 1);
        }

        if (result.size() < getGameCount()){
            for (int i=result.size();i<getGameCount();i++){
                result.add(1);
            }
        }

        return result;
    }


    public ArrayList<Integer> getOrderedGameList(){
        ArrayList<Integer> result = prefs.getSavedMenuOrderList();

        if (result.isEmpty()){                                                                      //get default order
            for (int i=0;i<getGameCount();i++){
                result.add(i);
            }
        }

        if (result.size() < getGameCount()){                                                        //add new games at the end
            for (int i=result.size();i<getGameCount();i++){
                result.add(i);
            }
        }

        return result;
    }

    public int getGameCount(){
        return GAME_COUNT;
    }


    public String[] getDefaultGameNameList(Resources res){
        String[] list = new String[allGameInformation.size()];

        for (int i = 0; i< allGameInformation.size(); i++){
            list[i] = allGameInformation.get(i).getName(res);
        }

        return list;
    }


    public ArrayList<String> getOrderedGameNameList(Resources res){

        ArrayList<Integer> savedList = getOrderedGameList();
        ArrayList<String> returnList = new ArrayList<>(allGameInformation.size());
        String[] defaultList = getDefaultGameNameList(res);

        for (int i=0;i<getGameCount();i++){
            returnList.add(defaultList[savedList.indexOf(i)]);
        }

        return returnList;
    }


    public String[] getSharedPrefNameList(){
        String[] list = new String[allGameInformation.size()];

        for (int i = 0; i< allGameInformation.size(); i++){
            list[i] = allGameInformation.get(i).getSharedPrefName();
        }

        return list;
    }


    public ArrayList<AllGameInformation> getOrderedGameInfoList(){
        ArrayList<Integer> savedList = getOrderedGameList();
        ArrayList<AllGameInformation> returnList = new ArrayList<>(allGameInformation.size());

        for (int i=0;i<getGameCount();i++){
            returnList.add(allGameInformation.get(savedList.indexOf(i)));
        }

        return returnList;
    }



    public String getSharedPrefNameOfGame(int index){
        return allGameInformation.get(index).getSharedPrefName();
    }

    public String getGameName() {
        return gameName;
    }

    public String getGameName(Resources res, int index) {
        return allGameInformation.get(index).getName(res);
    }

    public String getSharedPrefName() {
        return sharedPrefName;
    }


    public class AllGameInformation {

        private int shownNameResID;
        private String sharedPrefName;
        private String shownName = null;
        private boolean canStartWinnableGame;
        private int ensureMovabilityMoves;

        AllGameInformation(int shownNameResID, String sharedPrefName, boolean canStartWinnableGame, int ensureMovabilityMoves){
            this.shownNameResID = shownNameResID;
            this.sharedPrefName = sharedPrefName;
            this.canStartWinnableGame = canStartWinnableGame;
            this.ensureMovabilityMoves = ensureMovabilityMoves;
        }

        AllGameInformation(String shownName, String sharedPrefName, boolean canStartWinnableGame, int ensureMovabilityMoves) {
            this.shownName = shownName;
            this.sharedPrefName = sharedPrefName;
            this.canStartWinnableGame = canStartWinnableGame;
            this.ensureMovabilityMoves = ensureMovabilityMoves;
        }

        public String getName(Resources res){
            if(shownName != null) {
                return shownName;
            }
            return res.getString(shownNameResID);
        }

        public String getSharedPrefName(){
            return sharedPrefName;
        }

        public boolean canStartWinnableGame() {
            return canStartWinnableGame;
        }

        public int getEnsureMovabilityMoves(){
            return ensureMovabilityMoves;
        }
    }
}
