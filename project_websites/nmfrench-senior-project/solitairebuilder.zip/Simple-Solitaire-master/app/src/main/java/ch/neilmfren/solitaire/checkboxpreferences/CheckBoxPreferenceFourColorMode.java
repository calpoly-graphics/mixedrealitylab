
package ch.neilmfren.solitaire.checkboxpreferences;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.preference.CheckBoxPreference;
import android.util.AttributeSet;

import ch.neilmfren.solitaire.classes.CustomCheckBoxPreference;

import static ch.neilmfren.solitaire.SharedData.prefs;



public class CheckBoxPreferenceFourColorMode extends CustomCheckBoxPreference {

    public CheckBoxPreferenceFourColorMode(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public CheckBoxPreferenceFourColorMode(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public CheckBoxPreferenceFourColorMode(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CheckBoxPreferenceFourColorMode(Context context) {
        super(context);
    }

    @Override
    protected void onClick() {
        boolean value = !isChecked();
        prefs.putFourColorMode(value);
        setChecked(value);
    }

    public void update(){
        setChecked(prefs.getSavedFourColorMode());
    }
}
