package ch.neilmfren.solitaire.dialogs;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.DialogPreference;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.BulletSpan;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;


import java.util.ArrayList;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogPreference;
import ch.neilmfren.solitaire.ui.settings.Settings;

import static android.content.Context.MODE_PRIVATE;
import static android.view.View.GONE;
import static ch.neilmfren.solitaire.SharedData.createBulletParagraph;
import static ch.neilmfren.solitaire.SharedData.lg;
import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.showToast;
import static ch.neilmfren.solitaire.helper.Preferences.DEFAULT_CURRENT_GAME;
import static ch.neilmfren.solitaire.helper.Preferences.DEFAULT_SETTINGS_ONLY_FOR_THIS_GAME;
import static ch.neilmfren.solitaire.helper.Preferences.PREF_KEY_SETTINGS_ONLY_FOR_THIS_GAME;



public class DialogPreferenceOnlyForThisGame extends CustomDialogPreference {

    private Context context;
    private CheckBox widget;


    public DialogPreferenceOnlyForThisGame(Context context, AttributeSet attrs) {
        super(context, attrs);
        setDialogLayoutResource(R.layout.dialog_settings_only_for_this_game);
        setDialogIcon(null);
        setDialogTitle(null);
        this.context = context;
    }

    @Override
    protected void onBindDialogView(View view) {
        TextView textView1 = (TextView) view.findViewById(R.id.textViewDialogOnlyForThisGame1);
        TextView textView2 = (TextView) view.findViewById(R.id.textViewDialogOnlyForThisGame2);
        TextView textView3 = (TextView) view.findViewById(R.id.textViewDialogOnlyForThisGame3);

        //settings were opened from the main menu
        if (isNotInGame()) {
            String sharedPrefNames[] = lg.getSharedPrefNameList();
            String gameNames[] = lg.getDefaultGameNameList(context.getResources());

            ArrayList<String> gamesWithIndividualSettings = new ArrayList<>(sharedPrefNames.length);

            for (int i=0; i<sharedPrefNames.length; i++) {
                SharedPreferences savedGameData = context.getSharedPreferences(sharedPrefNames[i], MODE_PRIVATE);

                if (savedGameData.getBoolean(PREF_KEY_SETTINGS_ONLY_FOR_THIS_GAME, DEFAULT_SETTINGS_ONLY_FOR_THIS_GAME)) {
                    gamesWithIndividualSettings.add(gameNames[i]);
                }
            }

            textView1.setText(R.string.settings_dialog_only_for_this_game_information_2);
            textView2.setText(createBulletParagraph(gamesWithIndividualSettings.toArray(new CharSequence[gamesWithIndividualSettings.size()])));
            textView3.setText(R.string.settings_dialog_only_for_this_game_information_3);
        //settings are switching to individual settings
        } else if (!prefs.hasSettingsOnlyForThisGame()) {

            //build the list with bullet characters
            CharSequence strings[] = new CharSequence[]{
                    context.getString(R.string.settings_dialog_only_for_this_game_enable_2),
                    context.getString(R.string.settings_dialog_only_for_this_game_enable_3),
                    context.getString(R.string.settings_dialog_only_for_this_game_enable_4)
            };

            //set up the textView
            textView1.setText(R.string.settings_dialog_only_for_this_game_enable_1);
            textView2.setText(createBulletParagraph(strings));
            textView3.setText(R.string.settings_dialog_only_for_this_game_enable_5);
        //settings are switching back to normal settings
        } else {
            textView1.setText(R.string.settings_dialog_only_for_this_game_disable);
            textView2.setVisibility(GONE);
            textView3.setVisibility(GONE);
        }

        super.onBindDialogView(view);
    }

    @Override
    protected void onDialogClosed(boolean positiveResult) {
        if (positiveResult){
            if (!isNotInGame()){
                if (!prefs.hasSettingsOnlyForThisGame()) {
                    //copy all relevant settings before switching to game-individual settings
                    prefs.copyToGameIndividualSettings();

                    prefs.setSettingsOnlyForThisGame(true);

                } else {
                    prefs.setSettingsOnlyForThisGame(false);
                }

                if (widget != null) {
                    widget.setChecked(!widget.isChecked());
                }
            } else {
                //reset the setting for individual game settings for all games
                for (String name : lg.getSharedPrefNameList()) {
                    SharedPreferences savedGameData = context.getSharedPreferences(name, MODE_PRIVATE);

                    if (savedGameData.getBoolean(PREF_KEY_SETTINGS_ONLY_FOR_THIS_GAME,DEFAULT_SETTINGS_ONLY_FOR_THIS_GAME)){
                        savedGameData.edit().putBoolean(PREF_KEY_SETTINGS_ONLY_FOR_THIS_GAME,false).apply();
                    }
                }

                ((Settings) getContext()).hidePreferenceOnlyForThisGame();
                showToast(context.getString(R.string.settings_dialog_only_for_this_game_removed_all), context);
            }
        }


        super.onDialogClosed(positiveResult);
    }


    @Override
    protected View onCreateView(ViewGroup parent) {
        View view = super.onCreateView(parent);
        view.setBackgroundResource(R.color.colorDrawerSelected);

        //get rid of the stupid single line restriction for the title
        TextView textView = (TextView) view.findViewById(android.R.id.title);
        if (textView != null) {
            textView.setSingleLine(false);
        }

        widget = (CheckBox) view.findViewById(R.id.preference_only_for_this_game_switch);

        if (isNotInGame()) {
            if (widget != null) {
                widget.setVisibility(GONE);
            }

            if (getNumberOfGamesWithIndividualSettings() > 0){
                setTitle(context.getString(R.string.settings_dialog_only_for_this_game_information_1));
            }

        } else {
            setTitle(String.format(context.getString(R.string.settings_apply_only_for_this_game),lg.getGameName()));

            if (widget != null) {
                widget.setChecked(prefs.hasSettingsOnlyForThisGame());
            }
        }

        return view;
    }

    private int getNumberOfGamesWithIndividualSettings(){
        int numberOfGamesWithIndividualSettings = 0;

        for (String name : lg.getSharedPrefNameList()) {
            SharedPreferences savedGameData = context.getSharedPreferences(name, MODE_PRIVATE);

            if (savedGameData.getBoolean(PREF_KEY_SETTINGS_ONLY_FOR_THIS_GAME,DEFAULT_SETTINGS_ONLY_FOR_THIS_GAME)){
                numberOfGamesWithIndividualSettings ++;
            }
        }

        return numberOfGamesWithIndividualSettings;
    }

    private boolean isNotInGame(){
        return prefs.getSavedCurrentGame() == DEFAULT_CURRENT_GAME;
    }

    public boolean canBeHidden(){
        return isNotInGame() && getNumberOfGamesWithIndividualSettings() == 0;
    }
}
