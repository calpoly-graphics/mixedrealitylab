package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogFragment;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;



public class DialogInGameMenu extends CustomDialogFragment {

    @Override
    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final GameManager gameManager = (GameManager) getActivity();
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle(lg.getGameName())
                .setItems(R.array.restart_menu, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // "which" argument contains index of selected item
                        switch (which) {
                            case 0:
                                if (prefs.getShowDialogNewGame()) {
                                    prefs.putShowDialogNewGame(false);
                                    DialogStartNewGame dialogStartNewGame = new DialogStartNewGame();
                                    dialogStartNewGame.show(getFragmentManager(), "START_NEW_GAME_DIALOG");
                                } else {
                                    gameLogic.newGame();
                                }
                                break;
                            case 1:
                                if (prefs.getShowDialogRedeal()) {
                                    prefs.putShowDialogRedeal(false);
                                    DialogRedeal dialogRedeal = new DialogRedeal();
                                    dialogRedeal.show(getFragmentManager(), "REDEAL_DIALOG");
                                } else {
                                    gameLogic.redeal();
                                }
                                break;
                            case 2:
                                if (gameManager.hasLoaded) {
                                    timer.save();
                                    gameLogic.setWonAndReloaded();
                                    gameLogic.save();
                                }

                                gameManager.finish();
                                break;
                        }
                    }
                })
                .setNegativeButton(R.string.game_cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //just cancel
                    }
                });

        return applyFlags(builder.create());
    }


}