package ch.neilmfren.solitaire.ui.loader;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomAppCompatActivity;
import ch.neilmfren.solitaire.ui.builder.CustomGame;
import ch.neilmfren.solitaire.ui.builder.CustomView;
import ch.neilmfren.solitaire.ui.builder.GameInformation;

import static ch.neilmfren.solitaire.SharedData.lg;
import static ch.neilmfren.solitaire.SharedData.prefs;

public class FirebaseLoader extends CustomAppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_firebase_loader);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar!=null) {
            Log.d("ACTION", "found actionbar");
            actionBar.setDisplayHomeAsUpEnabled(true);
        } else {
            Log.d("ACTIONBAR", "no actionBar");
        }


         addCard();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        finish();
        return true;
    }

    private void addCard() {
        final LinearLayout item = (LinearLayout) findViewById(R.id.firebase_loader_linear_layout);

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference gameRef = db.getReference("games");

        gameRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    final String gameName = ds.child("name").getValue(String.class);
                    final String gameDesc = ds.child("desc").getValue(String.class);

                    final List<CustomView> customViewList = new ArrayList<>();
                    for(DataSnapshot viewChild : ds.child("views").getChildren()) {
                        CustomView v = viewChild.getValue(CustomView.class);
                        customViewList.add(v);
                    }

                    View child = getLayoutInflater().inflate(R.layout.fragment_game_card, null);
                    item.addView(child);

                    ViewGroup c1 = (ViewGroup) child;
                    ViewGroup c2 = (ViewGroup) c1.getChildAt(0);
                    ViewGroup c3 = (ViewGroup) c2.getChildAt(0);

                    TextView t = (TextView) c3.getChildAt(0);
                    TextView t1 = (TextView) c2.getChildAt(2);

                    ImageView add = (ImageView) c3.getChildAt(1);

                    add.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Log.d("LOAD_GAME", "ADD GAME BUTTON CLICKED");

                            GameInformation gi = new GameInformation(gameName, gameDesc);
                            CustomGame cg = new CustomGame(gi, customViewList);

                            prefs.addFirebaseGameToCache(cg);

                            //prefs.saveNewFirebaseGame(gameName);
                            lg.loadAllGames();

                            finish();
                        }
                    });


                    t.setText(gameName);
                    t1.setText(gameDesc);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

}
