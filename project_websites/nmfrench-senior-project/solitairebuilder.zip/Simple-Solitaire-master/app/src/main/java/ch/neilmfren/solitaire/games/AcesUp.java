
package ch.neilmfren.solitaire.games;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.RelativeLayout;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.Stack;

import static ch.neilmfren.solitaire.SharedData.*;



public class AcesUp extends Game {

    public AcesUp() {
        setNumberOfDecks(1);
        setNumberOfStacks(6);

        setTableauStackIDs(0,1,2,3);
        setFoundationStackIDs(4);
        setMainStackIDs(5);

        setMixingCardsTestMode(null);
        setDirections(1, 1, 1, 1, 0, 0);

    }


    public void setStacks(RelativeLayout layoutGame, boolean isLandscape, Context context) {

        setUpCardWidth(layoutGame, isLandscape, 7 + 1, 7 + 2);

        int spacing = setUpHorizontalSpacing(layoutGame, 7, 8);

        int startPos = (int) (layoutGame.getWidth() / 2 - 3.5 * Card.width - 2.5 * spacing);

        stacks[4].setX(startPos);
        stacks[4].view.setY((isLandscape ? Card.height / 4 : Card.height / 2) + 1);

        for (int i = 0; i < 4; i++) {
            stacks[i].setX(stacks[4].getX() + spacing + Card.width * 3 / 2 + i * (spacing + Card.width));
            stacks[i].setY(stacks[4].getY());
        }

        stacks[5].setX(stacks[3].getX() + Card.width + Card.width / 2 + spacing);
        stacks[5].setY(stacks[4].getY());
    }


    public boolean winTest() {
        if (!getMainStack().isEmpty()) {
            return false;
        }

        for (int i = 0; i < 4; i++) {
            if (stacks[i].getSize() != 1 || stacks[i].getTopCard().getValue() != 1) {
                return false;
            }
        }

        return true;
    }

    public void dealCards() {

        for (int i = 0; i < 4; i++) {
                moveToStack(getMainStack().getTopCard(), stacks[i], OPTION_NO_RECORD);
                stacks[i].getCard(0).flipUp();
        }
    }

    public int onMainStackTouch() {
        if (getMainStack().isEmpty()) {
            return 0;
        }

        ArrayList<Card> cards = new ArrayList<>();
        ArrayList<Stack> destinations = new ArrayList<>();

        for (int i = 0; i < 4; i++) {
            getMainStack().getCardFromTop(i).flipUp();
            cards.add(getMainStack().getCardFromTop(i));
            destinations.add(stacks[i]);
        }

        moveToStack(cards, destinations, OPTION_REVERSED_RECORD);

        return 1;
    }

    public boolean cardTest(Stack stack, Card card) {
        if (stack.getId() < 4 && stack.isEmpty()) {
            return true;
        } else if (stack.getId() == getMainStack().getId() || card.getValue() == 1) {
            return false;
        } else if (stack.getId() == 4) {
            for (int i = 0; i < 4; i++) {
                if (stacks[i].isEmpty() || i == card.getStack().getId()) {
                    continue;
                }

                Card cardOnStack = stacks[i].getTopCard();

                if (cardOnStack.getColor() == card.getColor() && (cardOnStack.getValue() > card.getValue() || cardOnStack.getValue() == 1)) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean addCardToMovementGameTest(Card card) {
        return card.isTopCard() && card.getStack() != stacks[4];
    }

    public CardAndStack hintTest(ArrayList<Card> visited) {

        for (int j = 0; j < 4; j++) {
            if (stacks[j].isEmpty() || visited.contains(stacks[j].getTopCard())
                    || (stacks[j].getSize() == 1 && stacks[j].getTopCard().getValue() == 1)) {
                continue;
            }

            Card cardToTest = stacks[j].getTopCard();
            boolean success = false;

            if (cardToTest.getValue() == 1) {
                for (int i = 0; i < 4; i++) {
                    if (i == j || !stacks[i].isEmpty()) {
                        continue;
                    }

                    return new CardAndStack(cardToTest, stacks[i]);
                }
            } else {
                for (int i = 0; i < 4; i++) {
                    if (stacks[i].isEmpty() || i == j) {
                        continue;
                    }

                    Card cardOnStack = stacks[i].getTopCard();

                    if (cardOnStack.getColor() == cardToTest.getColor()
                            && (cardOnStack.getValue() > cardToTest.getValue() || cardOnStack.getValue() == 1)) {
                        success = true;
                    }
                }

                if (success) {
                    return new CardAndStack(cardToTest, stacks[4]);
                }
            }
        }


        return null;
    }

    public Stack doubleTapTest(Card card) {

        boolean success = false;

        if (card.getValue() != 1) {                                                                   //do not move aces to discard stack
            for (int i = 0; i < 4; i++) {
                if (stacks[i].isEmpty() || i == card.getStack().getId()) {
                    continue;
                }

                Card cardOnStack = stacks[i].getTopCard();

                if (cardOnStack.getColor() == card.getColor()
                        && (cardOnStack.getValue() > card.getValue() || cardOnStack.getValue() == 1)) {
                    success = true;
                }
            }

            if (success) {
                return stacks[4];
            }
        }

        if (!card.isFirstCard()) {
            for (int i = 0; i < 4; i++) {
                if (i == card.getStackId() || !stacks[i].isEmpty()) {
                    continue;
                }

                return stacks[i];
            }
        }

        return null;
    }

    public int addPointsToScore(ArrayList<Card> cards, int[] originIDs, int[] destinationIDs, boolean isUndoMovement) {
        if (destinationIDs[0] == 4) {
            return 50;
        }

        return 0;
    }
}
