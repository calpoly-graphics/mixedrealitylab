package ch.neilmfren.solitaire.checkboxpreferences;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.preference.CheckBoxPreference;
import android.util.AttributeSet;

import ch.neilmfren.solitaire.classes.CustomCheckBoxPreference;

import static ch.neilmfren.solitaire.SharedData.prefs;



public class CheckBoxPreferenceHideScore extends CustomCheckBoxPreference {

    public CheckBoxPreferenceHideScore(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public CheckBoxPreferenceHideScore(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public CheckBoxPreferenceHideScore(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CheckBoxPreferenceHideScore(Context context) {
        super(context);
    }

    @Override
    protected void onClick() {
        boolean value = !isChecked();
        prefs.putHideScore(value);
        setChecked(value);
    }

    public void update(){
        setChecked(prefs.getSavedHideScore());
    }
}
