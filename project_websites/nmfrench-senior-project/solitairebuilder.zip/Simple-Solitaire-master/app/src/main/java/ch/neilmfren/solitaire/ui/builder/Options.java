package ch.neilmfren.solitaire.ui.builder;

public enum Options {

    TABLEAU_ALLOW_ANY,
    TABLEAU_ALLOW_KING,
    TABLEAU_ALLOW_ACE,

}
