package ch.neilmfren.solitaire.helper;

import android.support.annotation.NonNull;

public class User {
    long time;
    long date;
    long score;

    String username;

    public User() {

    }

    public User(String s, long score, long time, long date) {
        this.time = time;
        this.date = date;
        this.score = score;
        this.username = s;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public long getScore() {
        return score;
    }

    public void setScore(long score) {
        this.score = score;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
