package ch.neilmfren.solitaire.ui.builder;

import android.content.ClipData;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomAppCompatActivity;
import ch.neilmfren.solitaire.classes.CustomImageView;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.dialogs.DialogBuilderFinalInfo;
import ch.neilmfren.solitaire.dialogs.DialogBuilderTableauDrop;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.showToast;

public class Builder extends CustomAppCompatActivity implements View.OnTouchListener{

    private LinearLayout menuBar;
    private ImageView hideMenu;
    private ViewGroup rootLayout;
    private RelativeLayout gameLayout;

    private static final String I1_TAG = "TAG";

    private HashMap<View, CustomView> viewHashMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_builder);


        menuBar = findViewById(R.id.builderLayoutMenuBar);
        hideMenu = findViewById(R.id.builderHideMenu);
        rootLayout = findViewById(R.id.builder_layout);
        rootLayout.setBackgroundResource(R.drawable.background_color_green);
        //rootLayout.setOnDragListener(new MyDragListener());

        gameLayout = (RelativeLayout) findViewById(R.id.builderLayoutGameOverlay);
        gameLayout.setOnDragListener(new MyDragListener());

        ActionBar actionBar = getSupportActionBar();

        if (actionBar!=null) {
            Log.d("ACTION", "found actionbar");
            actionBar.setDisplayHomeAsUpEnabled(true);
        } else {
            Log.d("ACTIONBAR", "no actionBar");
        }

        Stack.loadBackgrounds();

        ImageView iv = (ImageView) findViewById(R.id.builder_pile);
        iv.setImageBitmap(Stack.background1);
        iv.setOnTouchListener(new MyTouchListener());

        ImageView iv1 = (ImageView) findViewById(R.id.builder_pile1);
        iv1.setImageBitmap(Stack.background2);
        iv1.setOnTouchListener(new MyTouchListener());

        ImageView iv2 = (ImageView) findViewById(R.id.builder_pile2);
        iv2.setImageBitmap(Stack.background3);
        iv2.setOnTouchListener(new MyTouchListener());

        ImageView iv3 = (ImageView) findViewById(R.id.builder_pile3);
        iv3.setImageBitmap(Stack.background4);
        iv3.setOnTouchListener(new MyTouchListener());


    }


    // create the builder export button
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_builder, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case R.id.builder_export:
                DialogBuilderFinalInfo di = new DialogBuilderFinalInfo();
                di.show(getSupportFragmentManager(), "DIALOG_FINAL_INFO");
                break;
            case android.R.id.home:
                finish();
                break;
        }
        return true;
    }

    public void hideClickNonOnClick(){
        if(menuBar.getVisibility() == VISIBLE) {
            menuBar.setVisibility(GONE);
        } else {
            menuBar.setVisibility(VISIBLE);
        }
        boolean isLandscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        updateHideMenuButton(isLandscape);
    }

    public void hideClick(View view) {
        switch(view.getId()) {
            case R.id.builderHideMenu:
                if(menuBar.getVisibility() == VISIBLE) {
                    menuBar.setVisibility(GONE);
                } else {
                    menuBar.setVisibility(VISIBLE);
                }
                boolean isLandscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
                updateHideMenuButton(isLandscape);
        }
    }

    private void updateHideMenuButton(boolean isLandscape){
        boolean menuBarVisible = menuBar.getVisibility() == VISIBLE;
        if (prefs.getHideMenuButton()){
            hideMenu.setVisibility(GONE);
        } else {
            hideMenu.setVisibility(VISIBLE);

            if (!isLandscape) {
                if (prefs.getSavedMenuBarPosPortrait().equals("bottom")) {
                    hideMenu.setImageResource(menuBarVisible ? R.drawable.icon_arrow_down : R.drawable.icon_arrow_up);
                } else {
                    hideMenu.setImageResource(menuBarVisible ? R.drawable.icon_arrow_up : R.drawable.icon_arrow_down);
                }
            } else {
                if (prefs.getSavedMenuBarPosLandscape().equals("right")) {
                    hideMenu.setImageResource(menuBarVisible ? R.drawable.icon_arrow_right : R.drawable.icon_arrow_left);
                } else {
                    hideMenu.setImageResource(menuBarVisible ? R.drawable.icon_arrow_left : R.drawable.icon_arrow_right);
                }
            }
        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        CustomImageView v = (CustomImageView) view;
        return false;
    }

    public void postToFirebase(String gameName, String gameDesc) {
        GameInformation g = new GameInformation(gameName, gameDesc);

        FirebaseDatabase db = FirebaseDatabase.getInstance();

        DatabaseReference gameRef = db.getReference("games").child(g.getName());

        gameRef.setValue(g);

        double parentWidth = gameLayout.getMeasuredWidth();
        double parentHeight = gameLayout.getMeasuredHeight();

        DatabaseReference viewPositions = gameRef.child("views");
        for (int i = 0; i < gameLayout.getChildCount(); i++) {
            View v = gameLayout.getChildAt(i);

            if (v instanceof ImageView && v.getId() != R.id.builderHideMenu) {
                ImageView iv = (ImageView) v;

                int imgId = Integer.parseInt(iv.getContentDescription().toString());

                switch (imgId) {
                    case 0:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                }

                double percentX = iv.getX() / parentWidth;
                double percentY = iv.getY() / parentHeight;

                CustomView c = new CustomView(imgId, percentX, percentY);
                viewPositions.push().setValue(c);
            }
        }
        finish();
    }

    private final class ChoiceTouchListener implements View.OnTouchListener {
        private int _xDelta;
        private int _yDelta;

        public boolean onTouch(View view, MotionEvent event) {
            final int X = (int) event.getRawX();
            final int Y = (int) event.getRawY();
            switch (event.getAction() & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_DOWN:
                    RelativeLayout.LayoutParams lParams = (RelativeLayout.LayoutParams) view.getLayoutParams();
                    _xDelta = X - lParams.leftMargin;
                    _yDelta = Y - lParams.topMargin;
                    break;
                case MotionEvent.ACTION_UP:
                    break;
                case MotionEvent.ACTION_POINTER_DOWN:
                    break;
                case MotionEvent.ACTION_POINTER_UP:
                    break;
                case MotionEvent.ACTION_MOVE:
                    RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) view
                            .getLayoutParams();
                    layoutParams.leftMargin = X - _xDelta;
                    layoutParams.topMargin = Y - _yDelta;
                    layoutParams.rightMargin = -250;
                    layoutParams.bottomMargin = -250;
                    view.setLayoutParams(layoutParams);
                    break;
            }
            rootLayout.invalidate();
            return true;
        }
    }

    private final class MyTouchListener implements View.OnTouchListener {



        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                ClipData data = ClipData.newPlainText("", "");
                View.DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                view.startDrag(data, shadowBuilder, view, 0);
                hideClickNonOnClick();
                return true;
            } else {
                return false;
            }
        }
    }

    private final class OverlayDragListener implements View.OnDragListener{
        @Override
        public boolean onDrag(View v, DragEvent dragEvent) {
            int action = dragEvent.getAction();
            switch(action) {
                case DragEvent.ACTION_DROP:
                    View view = (View) dragEvent.getLocalState();
                    view.setX(dragEvent.getX());
                    view.setY(dragEvent.getY());



                    DialogBuilderTableauDrop dd = new DialogBuilderTableauDrop();
                    dd.show(getSupportFragmentManager(), "DIALOG_TABLEAU_DROP");

                    break;
            }
            return true;
        }
    }

    private final class MyDragListener implements View.OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent dragEvent) {
            int action = dragEvent.getAction();
            switch(action) {
                case DragEvent.ACTION_DRAG_STARTED:
                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    break;
                case DragEvent.ACTION_DROP:
                    View view = (View) dragEvent.getLocalState();


                    RelativeLayout container = (RelativeLayout) v;

                    Log.d("DRAG", "Dropped in container");

                    ImageView imageView = (ImageView) view;

                    Log.d("DRAG", "Content desc: " + imageView.getContentDescription());

                    BitmapDrawable drawable = (BitmapDrawable) imageView.getDrawable();
                    Bitmap bitmap = drawable.getBitmap();

                    ImageView newView = new ImageView(getApplicationContext());
                    newView.setImageBitmap(bitmap);
                    newView.setOnTouchListener(new OverlayTouchListener());
                    newView.setContentDescription(imageView.getContentDescription());

                    Log.d("DRAG", imageView.getWidth() + ", " + imageView.getHeight());

                    newView.setX(dragEvent.getX() - imageView.getWidth() / 3);
                    newView.setY(dragEvent.getY() - imageView.getHeight() / 2);

                    container.addView(newView);
                    hideClickNonOnClick();

                    if(imageView.getContentDescription().equals("0")) {
                        DialogBuilderTableauDrop dd = new DialogBuilderTableauDrop();
                        dd.show(getSupportFragmentManager(), "DIALOG_TABLEAU_DROP");
                    }
                    break;
            }
            return true;
        }
    }

    private final class OverlayTouchListener implements View.OnTouchListener {
        private int x_offset;
        private int y_offset;

        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = (int) motionEvent.getAction();
            final int X = (int) motionEvent.getRawX();
            final int Y = (int) motionEvent.getRawY();
            switch(action) {
                case MotionEvent.ACTION_DOWN:

                    Log.d("DRAG", x_offset + ", " + y_offset);
                    break;
                case MotionEvent.ACTION_MOVE:

                    view.setX(X - view.getWidth() / 2);
                    view.setY(Y - view.getHeight() * 3 / 2);
                    break;
            }
            //rootLayout.invalidate();
            return true;
        }
    }

    public void addToCustomView(View v, int options) {

    }

}
