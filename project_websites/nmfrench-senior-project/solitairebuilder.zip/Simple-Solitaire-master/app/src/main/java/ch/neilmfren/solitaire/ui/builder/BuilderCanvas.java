package ch.neilmfren.solitaire.ui.builder;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import ch.neilmfren.solitaire.R;

public class BuilderCanvas extends View implements View.OnTouchListener{

    Rect originalRect , draggableRect;
    int left, right, top, bottom, newX, newY, size;
    Drawable originalDrawable,draggableDrawable;

    public BuilderCanvas(Context context)
    {
        super(context, null);
        size = 20;
        originalRect= new Rect();
        originalRect.set(200, 200, 240, 240); //left , top , right , bottom
        draggableRect= new Rect();
        draggableRect.set(200, 200, 240, 240);
        originalDrawable = getResources().getDrawable(R.drawable.icon_arrow_down);
        draggableDrawable = getResources().getDrawable(R.drawable.icon_arrow_down);
        originalDrawable.setBounds(originalRect); // since it wont move no need to do that in onDraw()
        newX = 220;
        newY=220;
        this.setOnTouchListener(this);
    }
    public BuilderCanvas(Context context, AttributeSet attrs)
    {    super(context, attrs);    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        originalDrawable.draw(canvas);
        draggableRect.set(newX-size, newY-size, newX+size, newY+size);
        draggableDrawable.setBounds(draggableRect);
        draggableDrawable.draw(canvas);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event)
    {
        newX = (int)event.getX();
        newY = (int)event.getY();
        invalidate(); // force redraw

        //if you need special touch events
//      //on touch down
//      if( event.getAction() == MotionEvent.ACTION_DOWN )
//      {   }
//      //on touch move
//      if( event.getAction() == MotionEvent.ACTION_MOVE )
//      {   }
//      //on touch up
//      if( event.getAction() == MotionEvent.ACTION_UP )
//      {   }

        return true; // always return true to let touch listener listen to next touch
    }
}
