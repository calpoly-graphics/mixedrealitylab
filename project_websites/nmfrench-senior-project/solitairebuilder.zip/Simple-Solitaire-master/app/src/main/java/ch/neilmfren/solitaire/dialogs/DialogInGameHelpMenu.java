package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogFragment;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.autoMove;
import static ch.neilmfren.solitaire.SharedData.currentGame;
import static ch.neilmfren.solitaire.SharedData.gameLogic;
import static ch.neilmfren.solitaire.SharedData.hint;
import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.showToast;



public class DialogInGameHelpMenu extends CustomDialogFragment {

    @Override
    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final GameManager gameManager = (GameManager) getActivity();
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        builder.setTitle(R.string.settings_support)
                .setItems(R.array.help_menu, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // "which" argument contains index of selected item
                        switch (which) {
                            case 0:
                                if (!gameLogic.hasWon()) {
                                    hint.start();
                                }
                                break;
                            case 1:
                                if (!gameLogic.hasWon()) {
                                    autoMove.start();
                                }
                                break;
                            case 2:
                                if (!gameLogic.hasWon()) {
                                    if (currentGame.hintTest() == null) {
                                        if (prefs.getShowDialogMixCards()) {
                                            prefs.putShowDialogMixCards(false);
                                            DialogMixCards dialogMixCards = new DialogMixCards();
                                            dialogMixCards.show(getFragmentManager(), "MIX_DIALOG");
                                        } else {
                                            currentGame.mixCards();
                                        }
                                    } else {
                                        showToast(getString(R.string.dialog_mix_cards_not_available), getActivity());
                                    }
                                }
                                break;
                        }
                    }
                })
                .setNegativeButton(R.string.game_cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //just cancel
                    }
                });

        return applyFlags(builder.create());
    }
}