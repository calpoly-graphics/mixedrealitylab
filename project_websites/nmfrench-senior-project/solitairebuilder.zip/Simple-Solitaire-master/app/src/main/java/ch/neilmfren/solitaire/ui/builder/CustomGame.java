package ch.neilmfren.solitaire.ui.builder;

import java.util.ArrayList;
import java.util.List;

public class CustomGame {

    private GameInformation gi;
    private List<CustomView> views;


    public CustomGame() {}

    public CustomGame(GameInformation gi, List<CustomView> views) {
        this.gi = gi;
        this.views = new ArrayList<>();
        this.views.addAll(views);
    }

    public GameInformation getGi() {
        return gi;
    }

    public void setGi(GameInformation gi) {
        this.gi = gi;
    }

    public List<CustomView> getViews() {
        return views;
    }

    public void setViews(List<CustomView> views) {
        this.views = views;
    }
}
