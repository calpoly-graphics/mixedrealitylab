package ch.neilmfren.solitaire.games;

import android.content.Context;
import android.widget.RelativeLayout;

import java.util.ArrayList;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.Stack;

import static ch.neilmfren.solitaire.SharedData.OPTION_NO_RECORD;
import static ch.neilmfren.solitaire.SharedData.moveToStack;
import static ch.neilmfren.solitaire.SharedData.stacks;

public class TestGame extends Game{

    public TestGame() {
        setNumberOfDecks(1);

        setNumberOfStacks(3);

        setMainStackIDs(2);

        setLastTableauID(1);
    }

    @Override
    public void setStacks(RelativeLayout layoutGame, boolean isLandscape, Context context) {


        double width = layoutGame.getWidth();
        double height = layoutGame.getHeight();

        for(int i = 0; i < 3; i++) {
            if(i == 0 ){
                stacks[i].setX((float) (0 * width));
                stacks[i].setY((float) (0 * height));
            }

            if(i == 1 ){
                stacks[i].setX((float) (0.5 * width));
                stacks[i].setY((float) (0.5 * height));
            }

            if(i == 2 ){
                stacks[i].setX((float) (0.9 * width));
                stacks[i].setY((float) (0.9 * height));
            }
        }

    }

    @Override
    public boolean winTest() {
        return false;
    }

    @Override
    public void dealCards() {
        moveToStack(getDealStack().getTopCard(), stacks[0], OPTION_NO_RECORD);
        stacks[0].getTopCard().flipUp();
    }

    @Override
    public boolean cardTest(Stack stack, Card card) {
        return false;
    }

    @Override
    public boolean addCardToMovementGameTest(Card card) {
        return false;
    }

    @Override
    public CardAndStack hintTest(ArrayList<Card> visited) {
        return null;
    }

    @Override
    public int addPointsToScore(ArrayList<Card> cards, int[] originIDs, int[] destinationIDs, boolean isUndoMovement) {
        return 0;
    }

    @Override
    public int onMainStackTouch() {
        return 0;
    }

    @Override
    Stack doubleTapTest(Card card) {
        return null;
    }
}
