package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogFragment;
import ch.neilmfren.solitaire.ui.builder.Builder;

public class DialogBuilderFinalInfo extends CustomDialogFragment{

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        final Builder parentActivity = (Builder) getActivity();

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        final View inflatedView = getActivity().getLayoutInflater().inflate(R.layout.dialog_final_game_info, (ViewGroup) getView());

        builder.setTitle("Enter your final game details")
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        EditText gameNameText = inflatedView.findViewById(R.id.dialog_final_game_info_name);
                        EditText gameDescText = inflatedView.findViewById(R.id.dialog_final_game_info_desc);
                        parentActivity.postToFirebase(gameNameText.getText().toString(), gameDescText.getText().toString());
                    }
                })
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });

        builder.setView(inflatedView);

        return applyFlags(builder.create());
    }
}
