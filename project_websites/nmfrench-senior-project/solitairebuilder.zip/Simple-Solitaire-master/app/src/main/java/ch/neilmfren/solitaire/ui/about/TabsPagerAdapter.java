
package ch.neilmfren.solitaire.ui.about;

import android.content.Context;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Logger;

import ch.neilmfren.solitaire.R;



public class TabsPagerAdapter extends FragmentPagerAdapter {

    private final String[] TITLES;

    //private FirebaseDatabase db;


    TabsPagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        //db = FirebaseDatabase.getInstance();
        //db.setLogLevel(Logger.Level.DEBUG);
        TITLES = new String[]{context.getString(R.string.about_tab_1) , context.getString(R.string.about_tab_2), context.getString(R.string.about_tab_3)};
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return TITLES[position];
    }

    @Override
    public int getCount() {
        return TITLES.length;
    }

    @Override
    public android.support.v4.app.Fragment getItem(int index) {
        return null;
    }



}