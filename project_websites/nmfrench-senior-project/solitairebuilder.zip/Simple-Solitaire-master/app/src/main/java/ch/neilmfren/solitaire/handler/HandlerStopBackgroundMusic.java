package ch.neilmfren.solitaire.handler;

import android.os.Handler;
import android.os.Message;


import static ch.neilmfren.solitaire.SharedData.activityCounter;
import static ch.neilmfren.solitaire.SharedData.backgroundSound;



public class HandlerStopBackgroundMusic extends Handler {


    public void handleMessage(Message msg) {
        super.handleMessage(msg);

        if (activityCounter==0){
            backgroundSound.pausePlaying();
        }
    }
}