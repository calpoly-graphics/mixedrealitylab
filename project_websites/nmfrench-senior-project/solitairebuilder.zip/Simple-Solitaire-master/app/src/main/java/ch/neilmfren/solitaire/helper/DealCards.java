package ch.neilmfren.solitaire.helper;

import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

import ch.neilmfren.solitaire.classes.Card;
import ch.neilmfren.solitaire.classes.CardAndStack;
import ch.neilmfren.solitaire.classes.HelperCardMovement;
import ch.neilmfren.solitaire.classes.Stack;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.animate;
import static ch.neilmfren.solitaire.SharedData.currentGame;
import static ch.neilmfren.solitaire.SharedData.gameLogic;
import static ch.neilmfren.solitaire.SharedData.handlerTestAfterMove;
import static ch.neilmfren.solitaire.SharedData.logText;
import static ch.neilmfren.solitaire.SharedData.max;
import static ch.neilmfren.solitaire.SharedData.moveToStack;
import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.scores;
import static ch.neilmfren.solitaire.SharedData.sounds;



public class DealCards extends HelperCardMovement {

    private int phase = 1;

    public DealCards(GameManager gm) {
        super(gm, "DEAL_CARDS");
    }

    public void start() {
        phase = 1;
        super.start();
    }

    @Override
    protected void saveState(Bundle bundle) {
        bundle.putInt("BUNDLE_DEAL_CARDS_PHASE", phase);
    }

    @Override
    protected void loadState(Bundle bundle) {
        phase = bundle.getInt("BUNDLE_DEAL_CARDS_PHASE");
    }

    @Override
    protected void moveCard() {
        switch (phase){
            case 1:
                currentGame.dealNewGame();
                sounds.playSound(Sounds.names.DEAL_CARDS);
                phase = 2;
                nextIteration();
                break;
            case 2: default:
                handlerTestAfterMove.sendNow();
                stop();
                break;
        }
    }
}
