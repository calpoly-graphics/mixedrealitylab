package ch.neilmfren.solitaire.ui.statistics;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.Locale;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.helper.Scores;

import static ch.neilmfren.solitaire.SharedData.currentGame;
import static ch.neilmfren.solitaire.SharedData.prefs;
import static ch.neilmfren.solitaire.SharedData.scores;



public class StatisticsFragment extends Fragment{

    private TextView textWonGames, textWinPercentage, textAdditionalStatisticsTitle, textAdditionalStatisticsValue,
            textTotalTimePlayed, textTotalPointsEarned, textTotalHintsShown, textTotalNumberUndos;

    private CardView winPercentageCardView;

    private TableRow tableRowAdditionalText;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_statistics_tab1, container, false);

        winPercentageCardView = (CardView) view.findViewById(R.id.statisticsCardViewWinPercentage);

        textWonGames = (TextView) view.findViewById(R.id.statisticsTextViewGamesWon);
        textWinPercentage = (TextView) view.findViewById(R.id.statisticsTextViewWinPercentage);
        textAdditionalStatisticsTitle = (TextView) view.findViewById(R.id.statisticsAdditionalText);
        textAdditionalStatisticsValue = (TextView) view.findViewById(R.id.statisticsAdditionalTextValue);
        textTotalTimePlayed = (TextView) view.findViewById(R.id.statisticsTotalTimePlayed);
        textTotalPointsEarned = (TextView) view.findViewById(R.id.statisticsTotalPointsEarned);
        textTotalHintsShown = (TextView) view.findViewById(R.id.statisticsTotalHintsShown);
        textTotalNumberUndos = (TextView) view.findViewById(R.id.statisticsTotalUndoMovements);
        tableRowAdditionalText = (TableRow) view.findViewById(R.id.statisticsAdditionalRow);

        //if the app got killed while the statistics are open and then the user restarts the app,
        //my helper classes aren't initialized so they can't be used. In this case, simply
        //close the statistics
        try {
            loadData();
        } catch (NullPointerException e) {
            getActivity().finish();
            return view;
        }

        ((StatisticsActivity)getActivity()).setCallback(new StatisticsActivity.HideWinPercentage() {
            @Override
            public void sendNewState(boolean state) {
                updateWinPercentageView(state);
            }
        });

        winPercentageCardView.setVisibility(prefs.getSavedStatisticsHideWinPercentage() ? View.GONE : View.VISIBLE);

        return view;
    }


    private void loadData() {
        int wonGames = prefs.getSavedNumberOfWonGames();
        int totalGames = prefs.getSavedNumberOfPlayedGames();
        int totalHintsShown = prefs.getSavedTotalHintsShown();
        int totalNumberUndos = prefs.getSavedTotalNumberUndos();

        long totalTime = prefs.getSavedTotalTimePlayed();
        long totalPoints = prefs.getSavedTotalPointsEarned();


        textWonGames.setText(String.format(Locale.getDefault(), getString(R.string.statistics_text_won_games), wonGames, totalGames));
        textWinPercentage.setText(String.format(Locale.getDefault(), getString(R.string.statistics_win_percentage), totalGames > 0 ? ((float) wonGames * 100 / totalGames) : 0.0));
        textTotalTimePlayed.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", totalTime / 3600, (totalTime % 3600) / 60, totalTime % 60));
        textTotalHintsShown.setText(String.format(Locale.getDefault(), "%d", totalHintsShown));
        textTotalNumberUndos.setText(String.format(Locale.getDefault(), "%d", totalNumberUndos));
        textTotalPointsEarned.setText(String.format(Locale.getDefault(), currentGame.isPointsInDollar() ? "%d $" : "%d", totalPoints));

        boolean added = currentGame.setAdditionalStatisticsData(getResources(), textAdditionalStatisticsTitle, textAdditionalStatisticsValue);

        if (added) {
            tableRowAdditionalText.setVisibility(View.VISIBLE);
        }
    }

    private void updateWinPercentageView(boolean hide){
        if (winPercentageCardView != null){
            winPercentageCardView.setVisibility(hide ? View.GONE : View.VISIBLE);
        }
    }
}