package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;


import java.util.ArrayList;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogPreference;
import yuku.ambilwarna.AmbilWarnaDialog;

import static ch.neilmfren.solitaire.SharedData.*;



public class DialogPreferenceBackgroundColor extends CustomDialogPreference implements View.OnClickListener {

    int backgroundType;
    int backgroundValue;
    int savedCustomColor;
    private ArrayList<LinearLayout> linearLayouts;
    private Context context;
    private ImageView image;

    public DialogPreferenceBackgroundColor(Context context, AttributeSet attrs) {
        super(context, attrs);
        setDialogLayoutResource(R.layout.dialog_background_color);
        setDialogIcon(null);
        this.context = context;
    }

    @Override
    protected void onBindDialogView(View view) {

        backgroundType = prefs.getSavedBackgroundColorType();
        backgroundValue = prefs.getSavedBackgroundColor();
        savedCustomColor = prefs.getSavedBackgroundCustomColor();

        linearLayouts = new ArrayList<>();
        linearLayouts.add((LinearLayout) view.findViewById(R.id.dialogBackgroundColorBlue));
        linearLayouts.add((LinearLayout) view.findViewById(R.id.dialogBackgroundColorGreen));
        linearLayouts.add((LinearLayout) view.findViewById(R.id.dialogBackgroundColorRed));
        linearLayouts.add((LinearLayout) view.findViewById(R.id.dialogBackgroundColorYellow));
        linearLayouts.add((LinearLayout) view.findViewById(R.id.dialogBackgroundColorOrange));
        linearLayouts.add((LinearLayout) view.findViewById(R.id.dialogBackgroundColorPurple));

        for (LinearLayout linearLayout : linearLayouts) {
            linearLayout.setOnClickListener(this);
        }

        super.onBindDialogView(view);
    }


    @SuppressWarnings("SuspiciousMethodCalls")
    public void onClick(View view) {
        if (view == ((AlertDialog) getDialog()).getButton(AlertDialog.BUTTON_POSITIVE)) {
            AmbilWarnaDialog dialog = new AmbilWarnaDialog(context, savedCustomColor, new AmbilWarnaDialog.OnAmbilWarnaListener() {
                @Override
                public void onOk(AmbilWarnaDialog dialog, int color) {
                    backgroundType = 2;
                    backgroundValue = savedCustomColor = color;

                    prefs.saveBackgroundColorType(backgroundType);
                    prefs.saveBackgroundCustomColor(backgroundValue);
                    updateSummary();
                    getDialog().dismiss();
                }

                @Override
                public void onCancel(AmbilWarnaDialog dialog) {
                    // cancel was selected by the user
                }
            });
            dialog.show();
        } else if (view == ((AlertDialog) getDialog()).getButton(AlertDialog.BUTTON_NEGATIVE)) {
            getDialog().dismiss();
        } else {
            backgroundValue = linearLayouts.indexOf(view) + 1;
            backgroundType = 1;

            prefs.saveBackgroundColorType(backgroundType);
            prefs.saveBackgroundColor(backgroundValue);

            updateSummary();
            getDialog().dismiss();
        }
    }

    @Override
    protected void showDialog(Bundle state) {
        super.showDialog(state);

        ((AlertDialog) getDialog()).getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(this);
        ((AlertDialog) getDialog()).getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(this);
    }


    @Override
    protected View onCreateView(ViewGroup parent) {
        View view = super.onCreateView(parent);

        image = (ImageView) view.findViewById(R.id.widget_layout_color_imageView);
        updateSummary();

        return view;
    }


    public void updateSummary() {

        if (prefs.getSavedBackgroundColorType() == 1) {
            int drawableID;
            int stringID;
            switch (prefs.getSavedBackgroundColor()) {
                case 1:
                default:
                    stringID = R.string.blue;
                    drawableID = R.drawable.background_color_blue;
                    break;
                case 2:
                    stringID = R.string.green;
                    drawableID = R.drawable.background_color_green;
                    break;
                case 3:
                    stringID = R.string.red;
                    drawableID = R.drawable.background_color_red;
                    break;
                case 4:
                    stringID = R.string.yellow;
                    drawableID = R.drawable.background_color_yellow;
                    break;
                case 5:
                    stringID = R.string.orange;
                    drawableID = R.drawable.background_color_orange;
                    break;
                case 6:
                    stringID = R.string.purple;
                    drawableID = R.drawable.background_color_purple;
                    break;
            }

            if (image != null) {
                image.setImageResource(drawableID);
            }

            setSummary(context.getString(stringID));
        } else {
            int customColor = prefs.getSavedBackgroundCustomColor();

            //this forces redrawing of the color preview
            setSummary("");

            //show as hex string, but without the opacity part at the beginning
            setSummary(String.format("#%06X", (0xFFFFFF & customColor)));

            if (image != null) {
                image.setImageResource(0);
                image.setBackgroundColor(customColor);
            }
        }
    }
}
