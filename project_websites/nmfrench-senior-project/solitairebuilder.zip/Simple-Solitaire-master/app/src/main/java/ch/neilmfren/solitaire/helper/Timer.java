package ch.neilmfren.solitaire.helper;

import ch.neilmfren.solitaire.handler.HandlerTimer;
import ch.neilmfren.solitaire.ui.GameManager;

import static ch.neilmfren.solitaire.SharedData.*;
import static ch.neilmfren.solitaire.helper.Preferences.DEFAULT_WINNING_TIME;



public class Timer {

    public HandlerTimer handlerTimer;                                                               //handler to show the current time

    private long currentTime;                                                                       //current system time, will be "frozen" if a game has been won
    private long startTime;                                                                         //time where the game was started
    private boolean running;                                                                        //indicates if the timer currently runs
    private long winningTime;

    public Timer(GameManager gm) {
        handlerTimer = new HandlerTimer(gm);
    }


    public long getCurrentTime() {
        return winningTime != 0 ? winningTime : currentTime;
    }

    //sets the time in seconds!
    public void setCurrentTime(long time) {
        currentTime = time;
    }


    public void save() {
        if (stopUiUpdates){
            return;
        }

        running = false;
        if (!gameLogic.hasWon()) {
            prefs.saveEndTime(System.currentTimeMillis());
            prefs.saveStartTime(startTime);
        } else {
            prefs.saveWinningTime(winningTime);
        }
    }


    public void load() {
        running = true;

        startTime = prefs.getSavedStartTime() + System.currentTimeMillis() - prefs.getSavedEndTime();

        winningTime = prefs.getSavedWinningTime();

        handlerTimer.sendEmptyMessage(0);
    }


    public void reset() {
        running = true;

        prefs.saveStartTime(System.currentTimeMillis());
        prefs.saveEndTime(System.currentTimeMillis());
        prefs.saveWinningTime(DEFAULT_WINNING_TIME);

        winningTime = 0;

        startTime = System.currentTimeMillis();
        handlerTimer.sendEmptyMessage(0);
    }

    public boolean isRunning() {
        return running;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setWinningTime() {
        winningTime = currentTime;
    }

    public void setStartTime(long time){
        startTime = time;
    }
}
