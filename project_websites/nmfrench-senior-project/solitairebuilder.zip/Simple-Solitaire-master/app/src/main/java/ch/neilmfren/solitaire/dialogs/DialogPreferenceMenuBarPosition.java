package ch.neilmfren.solitaire.dialogs;

import android.content.Context;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.View;
import android.widget.RadioButton;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogPreference;

import static ch.neilmfren.solitaire.SharedData.*;



public class DialogPreferenceMenuBarPosition extends CustomDialogPreference {

    RadioButton top, bottom, left, right;

    private static String BOTTOM = "bottom";
    private static String TOP = "top";
    private static String LEFT = "left";
    private static String RIGHT = "right";

    public DialogPreferenceMenuBarPosition(Context context, AttributeSet attrs) {
        super(context, attrs);
        setDialogLayoutResource(R.layout.dialog_settings_menu_bar_position);
        setDialogIcon(null);
    }

    @Override
    protected void onBindDialogView(View view) {
        top = (RadioButton) view.findViewById(R.id.dialog_button_portrait_top);
        bottom = (RadioButton) view.findViewById(R.id.dialog_button_portrait_bottom);
        left = (RadioButton) view.findViewById(R.id.dialog_button_landscape_left);
        right = (RadioButton) view.findViewById(R.id.dialog_button_landscape_right);

        if (prefs.getSavedMenuBarPosPortrait().equals(BOTTOM)) {
            bottom.setChecked(true);
        } else {
            top.setChecked(true);
        }

        if (prefs.getSavedMenuBarPosLandscape().equals(RIGHT)) {
            right.setChecked(true);
        } else {
            left.setChecked(true);
        }

        super.onBindDialogView(view);
    }


    @Override
    protected void onDialogClosed(boolean positiveResult) {
        super.onDialogClosed(positiveResult);

        if (positiveResult) {
            prefs.saveMenuBarPosPortrait(bottom.isChecked() ? BOTTOM : TOP);
            prefs.saveMenuBarPosLandscape(right.isChecked() ? RIGHT : LEFT);
        }
    }
}
