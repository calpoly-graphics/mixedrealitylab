package ch.neilmfren.solitaire.dialogs;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomDialogFragment;

import static ch.neilmfren.solitaire.SharedData.currentGame;



public class DialogMixCards extends CustomDialogFragment {
    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.dialog_mix_cards_title)
            .setMessage(R.string.dialog_mix_cards_text)
            .setPositiveButton(R.string.game_confirm, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    currentGame.mixCards();
                }
            })
            .setNegativeButton(R.string.game_cancel, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    // User cancelled the dialog
                }
            });

        return applyFlags(builder.create());
    }
}