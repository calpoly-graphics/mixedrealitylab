package ch.neilmfren.solitaire.ui.statistics;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.astuetz.PagerSlidingTabStrip;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.classes.CustomAppCompatActivity;
import ch.neilmfren.solitaire.dialogs.DialogHighScoreDelete;

import static ch.neilmfren.solitaire.SharedData.*;

public class StatisticsActivity extends CustomAppCompatActivity {

    private HideWinPercentage callback;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        writeToFirebase();

        setContentView(R.layout.activty_statistics);

        ActionBar actionBar = getSupportActionBar();

        if (actionBar!=null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        PagerSlidingTabStrip tabs = (PagerSlidingTabStrip) findViewById(R.id.tabs);
        tabs.setAllCaps(false);

        ViewPager pager = (ViewPager) findViewById(R.id.pager);
        TabsPagerAdapter adapter = new TabsPagerAdapter(getSupportFragmentManager(), this);

        pager.setAdapter(adapter);
        tabs.setViewPager(pager);
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_statistics, menu);
        menu.getItem(1).setChecked(prefs.getSavedStatisticsHideWinPercentage());

        return true;
    }

    public void writeToFirebase() {

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item_delete:
                DialogFragment deleteDialog = new DialogHighScoreDelete();
                deleteDialog.show(getSupportFragmentManager(), "high_score_delete");
                break;
            case R.id.item_hide:
                boolean checked = !prefs.getSavedStatisticsHideWinPercentage();

                prefs.saveStatisticsHideWinPercentage(checked);
                item.setChecked(checked);
                callback.sendNewState(checked);

                break;
            case android.R.id.home:
                finish();
                break;
        }

        return true;
    }

    public void setCallback(HideWinPercentage callback){
        this.callback = callback;
    }

    public interface HideWinPercentage{
        void sendNewState(boolean state);
    }


    public void deleteHighScores() {
        scores.deleteScores();
        gameLogic.deleteStatistics();
        currentGame.deleteAdditionalStatisticsData();
        showToast(getString(R.string.statistics_button_deleted_all_entries),this);

        finish();
        startActivity(getIntent());
    }
}
