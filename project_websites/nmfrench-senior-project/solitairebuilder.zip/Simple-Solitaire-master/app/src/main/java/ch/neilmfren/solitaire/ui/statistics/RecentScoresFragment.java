package ch.neilmfren.solitaire.ui.statistics;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

import ch.neilmfren.solitaire.R;
import ch.neilmfren.solitaire.helper.Scores;
import ch.neilmfren.solitaire.helper.User;

import static ch.neilmfren.solitaire.SharedData.currentGame;
import static ch.neilmfren.solitaire.SharedData.lg;
import static ch.neilmfren.solitaire.SharedData.scores;



public class RecentScoresFragment extends Fragment{

    private String dollar;
    private FirebaseDatabase db;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_statistics_tab3, container, false);

        db = FirebaseDatabase.getInstance();

        //if the app got killed while the statistics are open and then the user restarts the app,
        //my helper classes aren't initialized so they can't be used. In this case, simply
        //close the statistics
        try {
            loadData();
        } catch (NullPointerException e) {
            getActivity().finish();
            return view;
        }

        final TableLayout tableLayout = (TableLayout) view.findViewById(R.id.statisticsTableHighScores);
        final TextView textNoEntries = (TextView) view.findViewById(R.id.statisticsTextNoEntries);

        DatabaseReference dbRef = db.getReference("highscores").child(lg.getGameName());

        textNoEntries.setText("Loading...");


        dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                ArrayList<User> users = new ArrayList<>();
                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                    User u = ds.getValue(User.class);
                    users.add(u);
                    Log.d("HIGHSCORES", u.getUsername() + " " + u.getScore() + " " + u.getTime() + " " + u.getDate());
                }

                Collections.sort(users, new Comparator<User>() {
                    @Override
                    public int compare(User user, User t1) {
                        return Long.compare(t1.getScore(), user.getScore());
                    }
                });

                if(users.size() > 0) {
                    textNoEntries.setVisibility(View.GONE);
                } else {
                    textNoEntries.setText("No entries, go play some games!");
                }


              for(int i = 0; i < (Scores.MAX_SAVED_SCORES < users.size() ? Scores.MAX_SAVED_SCORES : users.size()); i++) {
                    if(users.get(i) != null) {
                        TableRow row = (TableRow) LayoutInflater.from(getContext()).inflate(R.layout.statistics_scores_row, null);

                        TextView textView1 = (TextView) row.findViewById(R.id.row_cell_1);
                        TextView textView2 = (TextView) row.findViewById(R.id.row_cell_2);
                        TextView textView3 = (TextView) row.findViewById(R.id.row_cell_3);
                        TextView textView4 = (TextView) row.findViewById(R.id.row_cell_4);


                        Log.d("HIGHSCORES", users.get(i).getUsername());
                        textView1.setText(String.format(Locale.getDefault(), "%s", users.get(i).getUsername()));
                        long time = users.get(i).getTime();
                        textView2.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d",time / 3600, (time % 3600) / 60, (time % 60)));
                        textView3.setText(DateFormat.getDateInstance(DateFormat.SHORT).format(users.get(i).getDate()));
                        textView4.setText(String.format(Locale.getDefault(), "%s", users.get(i).getScore()));
                        tableLayout.addView(row);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        return view;
    }


    private void loadData() {
        dollar = currentGame.isPointsInDollar() ? "$" : "";
    }
}